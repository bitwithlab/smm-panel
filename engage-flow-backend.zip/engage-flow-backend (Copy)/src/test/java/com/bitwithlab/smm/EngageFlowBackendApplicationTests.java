package com.bitwithlab.smm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngageFlowBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
