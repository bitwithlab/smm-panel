package com.bitwithlab.smm.support.messagelog;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageLogRepository extends JpaRepository<MessageLog, Long> {
    Page<MessageLog> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);
}
