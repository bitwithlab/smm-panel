package com.bitwithlab.smm.identity.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record LoginRequest(
        @NotBlank String emailOrPhone,
        @NotBlank @Size(min = 6, max = 100) String password,
        String deviceName
) {}
