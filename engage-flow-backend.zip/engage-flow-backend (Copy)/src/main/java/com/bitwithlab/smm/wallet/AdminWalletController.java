package com.bitwithlab.smm.wallet;

import com.bitwithlab.smm.common.dto.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/v1/admin/wallets")
@Tag(name = "Admin: Wallet")
public class AdminWalletController {

    private final WalletService service;
    public AdminWalletController(WalletService service) { this.service = service; }

    public record AdjustRequest(@NotBlank String userId, @NotNull @Positive BigDecimal amount, String note) {}

    @PostMapping("/credit")
    @Operation(summary = "Manual credit (e.g. apology bonus)")
    public ApiResponse<Void> credit(@Valid @RequestBody AdjustRequest req) {
        service.credit(req.userId(), req.amount(), WalletTransaction.Reason.ADJUSTMENT, "ADMIN", null, req.note());
        return ApiResponse.ok("Credited");
    }

    @PostMapping("/debit")
    @Operation(summary = "Manual debit (e.g. reverse mistaken bonus)")
    public ApiResponse<Void> debit(@Valid @RequestBody AdjustRequest req) {
        service.debit(req.userId(), req.amount(), WalletTransaction.Reason.ADJUSTMENT, "ADMIN", null, req.note());
        return ApiResponse.ok("Debited");
    }
}
