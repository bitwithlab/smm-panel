package com.bitwithlab.smm.catalog.pkg;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.catalog.pkg.dto.PackageDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/public/packages")
@Tag(name = "Catalog: Packages", description = "Public package catalog")
@SecurityRequirements
public class PackageController {

    private final PackageRepository repo;

    public PackageController(PackageRepository repo) { this.repo = repo; }

    @GetMapping
    @Operation(summary = "List active packages")
    public ApiResponse<List<PackageDto>> list() {
        return ApiResponse.ok(repo.findByActiveTrueOrderBySortOrderAsc().stream().map(PackageDto::of).toList());
    }
}
