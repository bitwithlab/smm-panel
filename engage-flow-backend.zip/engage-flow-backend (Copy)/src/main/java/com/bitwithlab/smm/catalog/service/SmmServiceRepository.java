package com.bitwithlab.smm.catalog.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SmmServiceRepository extends JpaRepository<SmmService, Integer> {

    List<SmmService> findByPlatformIdAndActiveTrueOrderByCategoryAscRatePer1000Asc(Short platformId);

    @Query("""
        select s from SmmService s
        where (:platformId is null or s.platformId = :platformId)
          and (:category is null or s.category = :category)
          and (:active is null or s.active = :active)
        """)
    Page<SmmService> search(@Param("platformId") Short platformId,
                            @Param("category") SmmService.Category category,
                            @Param("active") Boolean active,
                            Pageable pageable);
}
