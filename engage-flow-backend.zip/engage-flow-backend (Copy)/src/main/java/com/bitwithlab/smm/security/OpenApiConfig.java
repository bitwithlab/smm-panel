package com.bitwithlab.smm.security;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Value("${app.app-url}")
    private String appUrl;

    @Bean
    public OpenAPI openAPI() {
        final String scheme = "bearerAuth";
        return new OpenAPI()
                .info(new Info()
                        .title("Engage Flow API")
                        .description("SMM Panel — subscription packages, instant orders, wallet, payments, support.")
                        .version("v1")
                        .contact(new Contact().name("Engage Flow").email("support@engageflow.local"))
                        .license(new License().name("Proprietary")))
                .servers(List.of(new Server().url(appUrl).description("Active server")))
                .components(new Components()
                        .addSecuritySchemes(scheme, new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("Bearer access-token issued by /api/v1/auth/login")))
                .addSecurityItem(new SecurityRequirement().addList(scheme));
    }
}
