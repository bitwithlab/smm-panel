package com.bitwithlab.smm.identity.user;

import com.bitwithlab.smm.audit.Audited;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.identity.auth.dto.UserDto;
import com.bitwithlab.smm.identity.session.LoginSessionRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/admin/users")
@Tag(name = "Admin: Users")
public class AdminUserController {

    private final UserRepository repo;
    private final LoginSessionRepository sessions;

    public AdminUserController(UserRepository repo, LoginSessionRepository sessions) {
        this.repo = repo; this.sessions = sessions;
    }

    public record StatusUpdate(User.Status status, User.Role role) {}

    @GetMapping
    @Operation(summary = "Search users (q=name/email/phone substring; status; role)")
    public ApiResponse<PageResponse<UserDto>> list(@RequestParam(required = false) String q,
                                                   @RequestParam(required = false) User.Status status,
                                                   @RequestParam(required = false) User.Role role,
                                                   @RequestParam(defaultValue = "0") int page,
                                                   @RequestParam(defaultValue = "20") int size) {
        var p = repo.search(q, status, role,
                PageRequest.of(page, Math.min(size, 100), Sort.by("createdAt").descending()));
        return ApiResponse.ok(PageResponse.of(p, UserDto::of));
    }

    @GetMapping("/{id}")
    public ApiResponse<UserDto> get(@PathVariable String id) {
        return ApiResponse.ok(UserDto.of(repo.findById(id).orElseThrow(() -> ApiException.notFound("User", id))));
    }

    @PatchMapping("/{id}")
    @Audited(action = "USER_UPDATED", entityType = "User")
    @Transactional
    @Operation(summary = "Update status/role; if SUSPENDED/BANNED → revoke all sessions")
    public ApiResponse<UserDto> update(@PathVariable String id, @RequestBody StatusUpdate req) {
        User u = repo.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
        if (req.status() != null) {
            u.setStatus(req.status());
            if (req.status() == User.Status.SUSPENDED || req.status() == User.Status.BANNED) {
                sessions.revokeAllForUser(id, Instant.now());
            }
        }
        if (req.role() != null) u.setRole(req.role());
        repo.save(u);
        return ApiResponse.ok("Updated", UserDto.of(u));
    }

    @PostMapping("/{id}/force-verify")
    @Audited(action = "USER_FORCE_VERIFIED", entityType = "User")
    @Operation(summary = "Force-mark account ACTIVE & email verified (admin override)")
    public ApiResponse<UserDto> forceVerify(@PathVariable String id) {
        User u = repo.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
        u.setStatus(User.Status.ACTIVE);
        if (u.getEmailVerifiedAt() == null) u.setEmailVerifiedAt(Instant.now());
        repo.save(u);
        return ApiResponse.ok("Verified", UserDto.of(u));
    }

    @DeleteMapping("/{id}")
    @Audited(action = "USER_SOFT_DELETED", entityType = "User")
    @Operation(summary = "Soft delete (sets deleted_at; keeps financial history)")
    public ApiResponse<Void> softDelete(@PathVariable String id) {
        User u = repo.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
        u.setDeletedAt(Instant.now());
        u.setStatus(User.Status.SUSPENDED);
        repo.save(u);
        sessions.revokeAllForUser(id, Instant.now());
        return ApiResponse.ok("Soft-deleted");
    }
}
