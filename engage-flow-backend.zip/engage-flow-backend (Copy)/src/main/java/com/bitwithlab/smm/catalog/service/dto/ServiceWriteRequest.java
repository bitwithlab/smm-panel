package com.bitwithlab.smm.catalog.service.dto;

import com.bitwithlab.smm.catalog.service.SmmService;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public record ServiceWriteRequest(
        Short platformId,
        @Size(max = 120) String name,
        SmmService.Category category,
        @Min(1) Integer minQuantity,
        @Min(1) Integer maxQuantity,
        @DecimalMin("0.0") BigDecimal ratePer1000,
        @DecimalMin("0.0") BigDecimal providerCostPer1000,
        Integer providerId,
        @Size(max = 64) String providerServiceId,
        Boolean active
) {}
