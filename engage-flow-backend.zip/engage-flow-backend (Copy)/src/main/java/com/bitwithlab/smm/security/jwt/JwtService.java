package com.bitwithlab.smm.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Service
public class JwtService {

    public static final String CLAIM_TYPE = "typ";
    public static final String CLAIM_ROLE = "role";
    public static final String CLAIM_DEVICE = "did";
    public static final String CLAIM_SESSION = "sid";
    public static final String TYPE_ACCESS = "ACCESS";
    public static final String TYPE_REFRESH = "REFRESH";

    private final JwtProperties props;
    private final SecretKey key;

    public JwtService(JwtProperties props) {
        this.props = props;
        byte[] bytes = props.secret().getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 64) {
            byte[] padded = new byte[64];
            System.arraycopy(bytes, 0, padded, 0, bytes.length);
            for (int i = bytes.length; i < 64; i++) padded[i] = (byte) i;
            bytes = padded;
        }
        this.key = Keys.hmacShaKeyFor(bytes);
    }

    public TokenPair issuePair(String userId, String role, String deviceId, String sessionId) {
        String access = build(userId, TYPE_ACCESS, props.accessTokenTtl(),
                Map.of(CLAIM_ROLE, role, CLAIM_DEVICE, deviceId, CLAIM_SESSION, sessionId));
        String refresh = build(userId, TYPE_REFRESH, props.refreshTokenTtl(),
                Map.of(CLAIM_DEVICE, deviceId, CLAIM_SESSION, sessionId));
        return new TokenPair(access, refresh, props.accessTokenTtl().toSeconds(), props.refreshTokenTtl().toSeconds());
    }

    public String issueAccess(String userId, String role, String deviceId, String sessionId) {
        return build(userId, TYPE_ACCESS, props.accessTokenTtl(),
                Map.of(CLAIM_ROLE, role, CLAIM_DEVICE, deviceId, CLAIM_SESSION, sessionId));
    }

    public Claims parse(String token) {
        Jws<Claims> jws = Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
        return jws.getPayload();
    }

    private String build(String userId, String type, Duration ttl, Map<String, Object> extra) {
        Instant now = Instant.now();
        var b = Jwts.builder()
                .id(UUID.randomUUID().toString())
                .subject(userId)
                .issuer(props.issuer())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(ttl)))
                .claim(CLAIM_TYPE, type);
        extra.forEach(b::claim);
        return b.signWith(key).compact();
    }

    public record TokenPair(String accessToken, String refreshToken, long accessTtlSeconds, long refreshTtlSeconds) {}
}
