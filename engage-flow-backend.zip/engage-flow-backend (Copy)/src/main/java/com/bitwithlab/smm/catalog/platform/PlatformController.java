package com.bitwithlab.smm.catalog.platform;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Tag(name = "Catalog: Platforms")
public class PlatformController {

    private final PlatformRepository repo;
    public PlatformController(PlatformRepository repo) { this.repo = repo; }

    public record PlatformDto(Short id, String code, String name, String iconUrl, boolean active) {
        public static PlatformDto of(Platform p) { return new PlatformDto(p.getId(), p.getCode(), p.getName(), p.getIconUrl(), p.isActive()); }
    }
    public record PlatformWriteRequest(
            Short id,
            @NotBlank @Size(max = 32) String code,
            @NotBlank @Size(max = 64) String name,
            @Size(max = 500) String iconUrl,
            Boolean active
    ) {}

    // ---- Public ----
    @GetMapping("/api/v1/public/platforms")
    @Operation(summary = "List active platforms")
    @SecurityRequirements
    public ApiResponse<List<PlatformDto>> publicList() {
        return ApiResponse.ok(repo.findByActiveTrueOrderByIdAsc().stream().map(PlatformDto::of).toList());
    }

    // ---- Admin ----
    @GetMapping("/api/v1/admin/platforms")
    @Operation(summary = "List all platforms (incl. inactive)")
    public ApiResponse<List<PlatformDto>> adminList() {
        return ApiResponse.ok(repo.findAll().stream().map(PlatformDto::of).toList());
    }

    @PostMapping("/api/v1/admin/platforms")
    @Operation(summary = "Create a platform")
    public ApiResponse<PlatformDto> create(@Valid @RequestBody PlatformWriteRequest req) {
        if (req.id() == null) throw ApiException.badRequest("id is required");
        if (repo.existsById(req.id())) throw ApiException.conflict("Platform id exists");
        if (repo.findByCode(req.code()).isPresent()) throw ApiException.conflict("Platform code exists");
        Platform p = new Platform();
        p.setId(req.id());
        p.setCode(req.code().toUpperCase());
        p.setName(req.name());
        p.setIconUrl(req.iconUrl());
        p.setActive(req.active() == null || req.active());
        return ApiResponse.ok(PlatformDto.of(repo.save(p)));
    }

    @PatchMapping("/api/v1/admin/platforms/{id}")
    @Operation(summary = "Update a platform")
    public ApiResponse<PlatformDto> update(@PathVariable Short id, @RequestBody PlatformWriteRequest req) {
        Platform p = repo.findById(id).orElseThrow(() -> ApiException.notFound("Platform", id));
        if (req.name() != null) p.setName(req.name());
        if (req.iconUrl() != null) p.setIconUrl(req.iconUrl());
        if (req.active() != null) p.setActive(req.active());
        return ApiResponse.ok(PlatformDto.of(repo.save(p)));
    }
}
