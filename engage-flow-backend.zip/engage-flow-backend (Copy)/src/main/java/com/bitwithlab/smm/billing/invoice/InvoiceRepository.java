package com.bitwithlab.smm.billing.invoice;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface InvoiceRepository extends JpaRepository<Invoice, String> {

    Page<Invoice> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);

    @Query("""
        select i from Invoice i
        where (:userId is null or i.userId = :userId)
          and (:status is null or i.status = :status)
        order by i.createdAt desc
        """)
    Page<Invoice> search(@Param("userId") String userId,
                         @Param("status") Invoice.Status status,
                         Pageable pageable);

    @Query(value = "select count(*) from invoices where YEAR(created_at) = :year", nativeQuery = true)
    long countByYear(@Param("year") int year);
}
