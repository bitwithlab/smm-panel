package com.bitwithlab.smm.wallet;

import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.IdGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class WalletService {

    private final WalletRepository wallets;
    private final WalletTransactionRepository txns;

    public WalletService(WalletRepository wallets, WalletTransactionRepository txns) {
        this.wallets = wallets; this.txns = txns;
    }

    @Transactional
    public Wallet ensureWallet(String userId) {
        return wallets.findByUserId(userId).orElseGet(() -> {
            Wallet w = new Wallet();
            w.setId(IdGenerator.uuid());
            w.setUserId(userId);
            return wallets.save(w);
        });
    }

    @Transactional(readOnly = true)
    public Wallet get(String userId) {
        return wallets.findByUserId(userId).orElseThrow(() -> ApiException.notFound("Wallet", userId));
    }

    @Transactional
    public WalletTransaction credit(String userId, BigDecimal amount, WalletTransaction.Reason reason,
                                    String refType, String refId, String note) {
        return apply(userId, WalletTransaction.Direction.CREDIT, amount, reason, refType, refId, note);
    }

    @Transactional
    public WalletTransaction debit(String userId, BigDecimal amount, WalletTransaction.Reason reason,
                                   String refType, String refId, String note) {
        return apply(userId, WalletTransaction.Direction.DEBIT, amount, reason, refType, refId, note);
    }

    private WalletTransaction apply(String userId, WalletTransaction.Direction direction, BigDecimal amount,
                                    WalletTransaction.Reason reason, String refType, String refId, String note) {
        if (amount == null || amount.signum() <= 0) throw ApiException.badRequest("Amount must be positive");
        Wallet w = wallets.findByUserIdForUpdate(userId).orElseThrow(() -> ApiException.notFound("Wallet", userId));

        BigDecimal newBal = direction == WalletTransaction.Direction.CREDIT
                ? w.getBalance().add(amount)
                : w.getBalance().subtract(amount);
        if (newBal.signum() < 0) throw new ApiException(ErrorCode.INSUFFICIENT_BALANCE, "Insufficient wallet balance");
        w.setBalance(newBal);
        wallets.save(w);

        WalletTransaction t = new WalletTransaction();
        t.setId(IdGenerator.uuid());
        t.setWalletId(w.getId());
        t.setUserId(userId);
        t.setDirection(direction);
        t.setAmount(amount);
        t.setBalanceAfter(newBal);
        t.setReason(reason);
        t.setRefType(refType);
        t.setRefId(refId);
        t.setNote(note);
        return txns.save(t);
    }
}
