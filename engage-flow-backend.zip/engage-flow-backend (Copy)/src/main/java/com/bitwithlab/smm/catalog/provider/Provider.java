package com.bitwithlab.smm.catalog.provider;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "providers")
public class Provider {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer id;
    @Column(nullable = false, length = 120) private String name;
    @Column(name = "api_url", nullable = false, length = 255) private String apiUrl;
    @Column(name = "api_key_encrypted", nullable = false, columnDefinition = "TEXT") private String apiKeyEncrypted;
    @Column(nullable = false, precision = 14, scale = 4) private BigDecimal balance = BigDecimal.ZERO;
    @Column(name = "is_active", nullable = false) private boolean active = true;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public Integer getId() { return id; } public void setId(Integer id) { this.id = id; }
    public String getName() { return name; } public void setName(String n) { this.name = n; }
    public String getApiUrl() { return apiUrl; } public void setApiUrl(String s) { this.apiUrl = s; }
    public String getApiKeyEncrypted() { return apiKeyEncrypted; } public void setApiKeyEncrypted(String s) { this.apiKeyEncrypted = s; }
    public BigDecimal getBalance() { return balance; } public void setBalance(BigDecimal b) { this.balance = b; }
    public boolean isActive() { return active; } public void setActive(boolean a) { this.active = a; }
    public Instant getCreatedAt() { return createdAt; }
}
