package com.bitwithlab.smm.identity.user.dto;

import com.bitwithlab.smm.identity.device.TrustedDevice;

import java.time.Instant;

public record DeviceDto(
        String id,
        String deviceName,
        String os,
        String browser,
        String lastIp,
        String lastCountry,
        String lastCity,
        Instant trustedAt,
        Instant lastSeenAt,
        boolean revoked
) {
    public static DeviceDto of(TrustedDevice d) {
        return new DeviceDto(d.getId(), d.getDeviceName(), d.getOs(), d.getBrowser(),
                d.getLastIp(), d.getLastCountry(), d.getLastCity(),
                d.getTrustedAt(), d.getLastSeenAt(), d.getRevokedAt() != null);
    }
}
