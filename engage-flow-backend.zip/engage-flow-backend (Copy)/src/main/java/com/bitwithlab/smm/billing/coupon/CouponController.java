package com.bitwithlab.smm.billing.coupon;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.IdGenerator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@RestController
@Tag(name = "Coupons")
public class CouponController {

    private final CouponRepository repo;
    public CouponController(CouponRepository repo) { this.repo = repo; }

    public record CouponDto(String id, String code, String discountType, BigDecimal discountValue,
                            Integer maxUses, int usedCount, Instant validFrom, Instant validUntil,
                            boolean active) {
        public static CouponDto of(Coupon c) {
            return new CouponDto(c.getId(), c.getCode(), c.getDiscountType().name(), c.getDiscountValue(),
                    c.getMaxUses(), c.getUsedCount(), c.getValidFrom(), c.getValidUntil(), c.isActive());
        }
    }
    public record CouponWriteRequest(@NotBlank String code, Coupon.DiscountType discountType, BigDecimal discountValue,
                                     Integer maxUses, Instant validFrom, Instant validUntil,
                                     String applicablePackages, Boolean active) {}
    public record ValidateRequest(@NotBlank String code) {}
    public record ValidateResponse(String code, String discountType, BigDecimal discountValue) {}

    // ----- Public -----
    @PostMapping("/api/v1/public/coupons/validate")
    @Operation(summary = "Validate a coupon code")
    @SecurityRequirements
    public ApiResponse<ValidateResponse> validate(@Valid @RequestBody ValidateRequest req) {
        Coupon c = repo.findByCodeIgnoreCase(req.code())
                .filter(Coupon::isUsable)
                .orElseThrow(() -> new ApiException(ErrorCode.COUPON_INVALID, "Invalid or expired coupon"));
        return ApiResponse.ok(new ValidateResponse(c.getCode(), c.getDiscountType().name(), c.getDiscountValue()));
    }

    // ----- Admin -----
    @GetMapping("/api/v1/admin/coupons")
    @Operation(summary = "List all coupons")
    public ApiResponse<List<CouponDto>> list() {
        return ApiResponse.ok(repo.findAll().stream().map(CouponDto::of).toList());
    }

    @PostMapping("/api/v1/admin/coupons")
    @Operation(summary = "Create coupon")
    public ApiResponse<CouponDto> create(@Valid @RequestBody CouponWriteRequest req) {
        if (req.discountType() == null || req.discountValue() == null || req.validFrom() == null || req.validUntil() == null)
            throw ApiException.badRequest("discountType/value/validity required");
        if (repo.findByCodeIgnoreCase(req.code()).isPresent())
            throw ApiException.conflict("Coupon code exists");
        Coupon c = new Coupon();
        c.setId(IdGenerator.uuid());
        c.setCode(req.code().toUpperCase());
        c.setDiscountType(req.discountType());
        c.setDiscountValue(req.discountValue());
        c.setMaxUses(req.maxUses());
        c.setValidFrom(req.validFrom());
        c.setValidUntil(req.validUntil());
        c.setApplicablePackages(req.applicablePackages());
        if (req.active() != null) c.setActive(req.active());
        return ApiResponse.ok(CouponDto.of(repo.save(c)));
    }

    @PatchMapping("/api/v1/admin/coupons/{id}")
    public ApiResponse<CouponDto> update(@PathVariable String id, @RequestBody CouponWriteRequest req) {
        Coupon c = repo.findById(id).orElseThrow(() -> ApiException.notFound("Coupon", id));
        if (req.discountType() != null) c.setDiscountType(req.discountType());
        if (req.discountValue() != null) c.setDiscountValue(req.discountValue());
        if (req.maxUses() != null) c.setMaxUses(req.maxUses());
        if (req.validFrom() != null) c.setValidFrom(req.validFrom());
        if (req.validUntil() != null) c.setValidUntil(req.validUntil());
        if (req.applicablePackages() != null) c.setApplicablePackages(req.applicablePackages());
        if (req.active() != null) c.setActive(req.active());
        return ApiResponse.ok(CouponDto.of(repo.save(c)));
    }

    @DeleteMapping("/api/v1/admin/coupons/{id}")
    public ApiResponse<Void> deactivate(@PathVariable String id) {
        Coupon c = repo.findById(id).orElseThrow(() -> ApiException.notFound("Coupon", id));
        c.setActive(false);
        repo.save(c);
        return ApiResponse.ok("Deactivated");
    }
}
