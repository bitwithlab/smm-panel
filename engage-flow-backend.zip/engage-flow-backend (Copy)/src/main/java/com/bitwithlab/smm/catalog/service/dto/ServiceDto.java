package com.bitwithlab.smm.catalog.service.dto;

import com.bitwithlab.smm.catalog.service.SmmService;

import java.math.BigDecimal;

public record ServiceDto(
        Integer id,
        Short platformId,
        String name,
        String category,
        Integer minQuantity,
        Integer maxQuantity,
        BigDecimal ratePer1000,
        boolean active
) {
    public static ServiceDto of(SmmService s) {
        return new ServiceDto(s.getId(), s.getPlatformId(), s.getName(), s.getCategory().name(),
                s.getMinQuantity(), s.getMaxQuantity(), s.getRatePer1000(), s.isActive());
    }
}
