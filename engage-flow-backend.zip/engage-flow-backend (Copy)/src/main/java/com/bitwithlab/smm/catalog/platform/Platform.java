package com.bitwithlab.smm.catalog.platform;

import jakarta.persistence.*;

@Entity
@Table(name = "platforms")
public class Platform {

    @Id private Short id;
    @Column(nullable = false, length = 32, unique = true) private String code;
    @Column(nullable = false, length = 64) private String name;
    @Column(name = "icon_url", length = 500) private String iconUrl;
    @Column(name = "is_active", nullable = false) private boolean active = true;

    public Short getId() { return id; } public void setId(Short id) { this.id = id; }
    public String getCode() { return code; } public void setCode(String c) { this.code = c; }
    public String getName() { return name; } public void setName(String n) { this.name = n; }
    public String getIconUrl() { return iconUrl; } public void setIconUrl(String s) { this.iconUrl = s; }
    public boolean isActive() { return active; } public void setActive(boolean a) { this.active = a; }
}
