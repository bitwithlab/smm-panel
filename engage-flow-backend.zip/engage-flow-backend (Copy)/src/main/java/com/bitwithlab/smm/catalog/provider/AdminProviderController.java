package com.bitwithlab.smm.catalog.provider;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.util.AesGcmCipher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/providers")
@Tag(name = "Admin: Providers", description = "Upstream SMM API providers")
public class AdminProviderController {

    private final ProviderRepository repo;
    private final AesGcmCipher cipher;

    public AdminProviderController(ProviderRepository repo, AesGcmCipher cipher) {
        this.repo = repo; this.cipher = cipher;
    }

    public record ProviderDto(Integer id, String name, String apiUrl, BigDecimal balance, boolean active, Instant createdAt) {
        public static ProviderDto of(Provider p) {
            return new ProviderDto(p.getId(), p.getName(), p.getApiUrl(), p.getBalance(), p.isActive(), p.getCreatedAt());
        }
    }
    public record ProviderCreate(@NotBlank @Size(max = 120) String name,
                                 @NotBlank @Size(max = 255) String apiUrl,
                                 @NotBlank String apiKey) {}
    public record ProviderUpdate(String name, String apiUrl, String apiKey, BigDecimal balance, Boolean active) {}

    @GetMapping
    @Operation(summary = "List providers")
    public ApiResponse<List<ProviderDto>> list() {
        return ApiResponse.ok(repo.findAll().stream().map(ProviderDto::of).toList());
    }

    @GetMapping("/{id}")
    public ApiResponse<ProviderDto> get(@PathVariable Integer id) {
        return ApiResponse.ok(ProviderDto.of(repo.findById(id).orElseThrow(() -> ApiException.notFound("Provider", id))));
    }

    @PostMapping
    @Operation(summary = "Create provider — apiKey stored AES-256-GCM encrypted")
    public ApiResponse<ProviderDto> create(@Valid @RequestBody ProviderCreate req) {
        Provider p = new Provider();
        p.setName(req.name());
        p.setApiUrl(req.apiUrl());
        p.setApiKeyEncrypted(cipher.encrypt(req.apiKey()));
        return ApiResponse.ok(ProviderDto.of(repo.save(p)));
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update provider")
    public ApiResponse<ProviderDto> update(@PathVariable Integer id, @RequestBody ProviderUpdate req) {
        Provider p = repo.findById(id).orElseThrow(() -> ApiException.notFound("Provider", id));
        if (req.name() != null) p.setName(req.name());
        if (req.apiUrl() != null) p.setApiUrl(req.apiUrl());
        if (req.apiKey() != null && !req.apiKey().isBlank()) p.setApiKeyEncrypted(cipher.encrypt(req.apiKey()));
        if (req.balance() != null) p.setBalance(req.balance());
        if (req.active() != null) p.setActive(req.active());
        return ApiResponse.ok(ProviderDto.of(repo.save(p)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deactivate provider (soft)")
    public ApiResponse<Void> deactivate(@PathVariable Integer id) {
        Provider p = repo.findById(id).orElseThrow(() -> ApiException.notFound("Provider", id));
        p.setActive(false);
        repo.save(p);
        return ApiResponse.ok("Deactivated");
    }
}
