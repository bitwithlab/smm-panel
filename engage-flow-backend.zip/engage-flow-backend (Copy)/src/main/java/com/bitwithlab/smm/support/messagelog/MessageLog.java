package com.bitwithlab.smm.support.messagelog;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "message_log")
public class MessageLog {

    public enum Channel { EMAIL, SMS, PUSH }
    public enum Status { QUEUED, SENT, DELIVERED, BOUNCED, FAILED }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "user_id", length = 36) private String userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 8) private Channel channel;
    @Column(name = "to_address", nullable = false, length = 190) private String toAddress;
    @Column(length = 64) private String template;
    @Column(length = 255) private String subject;
    @Column(length = 64) private String provider;
    @Column(name = "provider_msg_id", length = 120) private String providerMsgId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.QUEUED;
    @Column(columnDefinition = "TEXT") private String error;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public Long getId() { return id; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Channel getChannel() { return channel; } public void setChannel(Channel c) { this.channel = c; }
    public String getToAddress() { return toAddress; } public void setToAddress(String s) { this.toAddress = s; }
    public String getTemplate() { return template; } public void setTemplate(String t) { this.template = t; }
    public String getSubject() { return subject; } public void setSubject(String s) { this.subject = s; }
    public String getProvider() { return provider; } public void setProvider(String p) { this.provider = p; }
    public String getProviderMsgId() { return providerMsgId; } public void setProviderMsgId(String s) { this.providerMsgId = s; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public String getError() { return error; } public void setError(String e) { this.error = e; }
    public Instant getCreatedAt() { return createdAt; }
}
