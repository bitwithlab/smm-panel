package com.bitwithlab.smm.common.util;

import jakarta.servlet.http.HttpServletRequest;

public record ClientInfo(String ip, String userAgent, String deviceFingerprint) {

    public static ClientInfo from(HttpServletRequest req) {
        String ip = headerOr(req, "X-Forwarded-For", req.getRemoteAddr());
        if (ip != null && ip.contains(",")) ip = ip.split(",")[0].trim();
        String ua = req.getHeader("User-Agent");
        String fp = req.getHeader("X-Device-Fingerprint");
        return new ClientInfo(ip, ua, fp);
    }

    private static String headerOr(HttpServletRequest req, String name, String fallback) {
        String v = req.getHeader(name);
        return (v == null || v.isBlank()) ? fallback : v;
    }
}
