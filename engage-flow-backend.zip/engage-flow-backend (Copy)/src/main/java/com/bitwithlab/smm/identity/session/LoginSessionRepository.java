package com.bitwithlab.smm.identity.session;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface LoginSessionRepository extends JpaRepository<LoginSession, String> {
    Optional<LoginSession> findByRefreshTokenHash(String hash);
    List<LoginSession> findByUserIdAndRevokedAtIsNullOrderByIssuedAtDesc(String userId);

    @Modifying
    @Query("update LoginSession s set s.revokedAt = :ts where s.userId = :userId and s.revokedAt is null")
    int revokeAllForUser(@Param("userId") String userId, @Param("ts") Instant ts);
}
