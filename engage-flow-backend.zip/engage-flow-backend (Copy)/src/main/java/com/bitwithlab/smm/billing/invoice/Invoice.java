package com.bitwithlab.smm.billing.invoice;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "invoices")
public class Invoice {

    public enum Purpose { SUBSCRIPTION, WALLET_TOPUP }
    public enum Status { UNPAID, PAID, PARTIAL, REFUNDED, VOID }

    @Id @Column(length = 36) private String id;
    @Column(name = "invoice_number", nullable = false, length = 32, unique = true) private String invoiceNumber;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Purpose purpose;
    @Column(name = "subscription_id", length = 36) private String subscriptionId;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal subtotal;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal discount = BigDecimal.ZERO;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal tax = BigDecimal.ZERO;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal total;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.UNPAID;
    @Column(name = "due_at") private Instant dueAt;
    @Column(name = "paid_at") private Instant paidAt;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getInvoiceNumber() { return invoiceNumber; } public void setInvoiceNumber(String s) { this.invoiceNumber = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Purpose getPurpose() { return purpose; } public void setPurpose(Purpose p) { this.purpose = p; }
    public String getSubscriptionId() { return subscriptionId; } public void setSubscriptionId(String s) { this.subscriptionId = s; }
    public BigDecimal getSubtotal() { return subtotal; } public void setSubtotal(BigDecimal b) { this.subtotal = b; }
    public BigDecimal getDiscount() { return discount; } public void setDiscount(BigDecimal b) { this.discount = b; }
    public BigDecimal getTax() { return tax; } public void setTax(BigDecimal b) { this.tax = b; }
    public BigDecimal getTotal() { return total; } public void setTotal(BigDecimal b) { this.total = b; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public Instant getDueAt() { return dueAt; } public void setDueAt(Instant t) { this.dueAt = t; }
    public Instant getPaidAt() { return paidAt; } public void setPaidAt(Instant t) { this.paidAt = t; }
    public Instant getCreatedAt() { return createdAt; }
}
