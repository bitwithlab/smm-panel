package com.bitwithlab.smm.wallet;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "wallets")
public class Wallet {

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, unique = true, length = 36) private String userId;
    @Column(nullable = false, precision = 14, scale = 2) private BigDecimal balance = BigDecimal.ZERO;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;

    @PrePersist @PreUpdate void onSave() { updatedAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public BigDecimal getBalance() { return balance; } public void setBalance(BigDecimal b) { this.balance = b; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public Instant getUpdatedAt() { return updatedAt; }
}
