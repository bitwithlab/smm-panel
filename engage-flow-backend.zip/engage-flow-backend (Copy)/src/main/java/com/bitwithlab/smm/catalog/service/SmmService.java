package com.bitwithlab.smm.catalog.service;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "services")
public class SmmService {

    public enum Category { FOLLOWERS, LIKES, VIEWS, COMMENTS, SUBSCRIBERS, SHARES, OTHER }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer id;
    @Column(name = "platform_id", nullable = false) private Short platformId;
    @Column(nullable = false, length = 120) private String name;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Category category;
    @Column(name = "min_quantity", nullable = false) private Integer minQuantity = 50;
    @Column(name = "max_quantity", nullable = false) private Integer maxQuantity = 100_000;
    @Column(name = "rate_per_1000", nullable = false, precision = 10, scale = 4) private BigDecimal ratePer1000;
    @Column(name = "provider_id") private Integer providerId;
    @Column(name = "provider_service_id", length = 64) private String providerServiceId;
    @Column(name = "provider_cost_per_1000", precision = 10, scale = 4) private BigDecimal providerCostPer1000;
    @Column(name = "is_active", nullable = false) private boolean active = true;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); updatedAt = Instant.now(); }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }

    public Integer getId() { return id; } public void setId(Integer id) { this.id = id; }
    public Short getPlatformId() { return platformId; } public void setPlatformId(Short s) { this.platformId = s; }
    public String getName() { return name; } public void setName(String s) { this.name = s; }
    public Category getCategory() { return category; } public void setCategory(Category c) { this.category = c; }
    public Integer getMinQuantity() { return minQuantity; } public void setMinQuantity(Integer i) { this.minQuantity = i; }
    public Integer getMaxQuantity() { return maxQuantity; } public void setMaxQuantity(Integer i) { this.maxQuantity = i; }
    public BigDecimal getRatePer1000() { return ratePer1000; } public void setRatePer1000(BigDecimal b) { this.ratePer1000 = b; }
    public Integer getProviderId() { return providerId; } public void setProviderId(Integer i) { this.providerId = i; }
    public String getProviderServiceId() { return providerServiceId; } public void setProviderServiceId(String s) { this.providerServiceId = s; }
    public BigDecimal getProviderCostPer1000() { return providerCostPer1000; } public void setProviderCostPer1000(BigDecimal b) { this.providerCostPer1000 = b; }
    public boolean isActive() { return active; } public void setActive(boolean a) { this.active = a; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
