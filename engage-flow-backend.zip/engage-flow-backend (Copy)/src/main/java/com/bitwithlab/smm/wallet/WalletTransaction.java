package com.bitwithlab.smm.wallet;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "wallet_transactions")
public class WalletTransaction {

    public enum Direction { CREDIT, DEBIT }
    public enum Reason { TOPUP, ORDER, SUBSCRIPTION, REFUND, ADJUSTMENT, BONUS }

    @Id @Column(length = 36) private String id;
    @Column(name = "wallet_id", nullable = false, length = 36) private String walletId;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 8) private Direction direction;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;
    @Column(name = "balance_after", nullable = false, precision = 14, scale = 2) private BigDecimal balanceAfter;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Reason reason;
    @Column(name = "ref_type", length = 32) private String refType;
    @Column(name = "ref_id", length = 36) private String refId;
    @Column(columnDefinition = "TEXT") private String note;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getWalletId() { return walletId; } public void setWalletId(String s) { this.walletId = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Direction getDirection() { return direction; } public void setDirection(Direction d) { this.direction = d; }
    public BigDecimal getAmount() { return amount; } public void setAmount(BigDecimal a) { this.amount = a; }
    public BigDecimal getBalanceAfter() { return balanceAfter; } public void setBalanceAfter(BigDecimal a) { this.balanceAfter = a; }
    public Reason getReason() { return reason; } public void setReason(Reason r) { this.reason = r; }
    public String getRefType() { return refType; } public void setRefType(String s) { this.refType = s; }
    public String getRefId() { return refId; } public void setRefId(String s) { this.refId = s; }
    public String getNote() { return note; } public void setNote(String s) { this.note = s; }
    public Instant getCreatedAt() { return createdAt; }
}
