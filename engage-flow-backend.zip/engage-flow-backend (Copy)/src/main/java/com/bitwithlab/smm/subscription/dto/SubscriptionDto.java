package com.bitwithlab.smm.subscription.dto;

import com.bitwithlab.smm.subscription.Subscription;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record SubscriptionDto(
        String id,
        String userId,
        Short packageId,
        String billingCycle,
        BigDecimal price,
        String currency,
        Short maxPlatforms,
        Short maxAccountsPerPlatform,
        String status,
        Instant startsAt,
        Instant endsAt,
        boolean autoRenew,
        Instant createdAt,
        List<Short> platforms
) {
    public static SubscriptionDto of(Subscription s, List<Short> platforms) {
        return new SubscriptionDto(s.getId(), s.getUserId(), s.getPackageId(),
                s.getBillingCycle().name(), s.getPrice(), s.getCurrency(),
                s.getMaxPlatformsSnapshot(), s.getMaxAccountsSnapshot(),
                s.getStatus().name(), s.getStartsAt(), s.getEndsAt(),
                s.isAutoRenew(), s.getCreatedAt(), platforms);
    }
}
