package com.bitwithlab.smm.billing.invoice;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;

@RestController
@Tag(name = "Invoices")
public class InvoiceController {

    private final InvoiceRepository repo;
    public InvoiceController(InvoiceRepository repo) { this.repo = repo; }

    public record InvoiceDto(String id, String number, String purpose, String subscriptionId,
                             BigDecimal subtotal, BigDecimal discount, BigDecimal total,
                             String currency, String status, Instant dueAt, Instant paidAt, Instant createdAt) {
        public static InvoiceDto of(Invoice i) {
            return new InvoiceDto(i.getId(), i.getInvoiceNumber(), i.getPurpose().name(), i.getSubscriptionId(),
                    i.getSubtotal(), i.getDiscount(), i.getTotal(), i.getCurrency(), i.getStatus().name(),
                    i.getDueAt(), i.getPaidAt(), i.getCreatedAt());
        }
    }

    @GetMapping("/api/v1/me/invoices")
    @Operation(summary = "My invoices")
    public ApiResponse<PageResponse<InvoiceDto>> mine(@CurrentUser UserPrincipal me,
                                                      @RequestParam(defaultValue = "0") int page,
                                                      @RequestParam(defaultValue = "20") int size) {
        var p = repo.findByUserIdOrderByCreatedAtDesc(me.id(), PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, InvoiceDto::of));
    }

    @GetMapping("/api/v1/me/invoices/{id}")
    public ApiResponse<InvoiceDto> getMine(@CurrentUser UserPrincipal me, @PathVariable String id) {
        Invoice i = repo.findById(id).orElseThrow(() -> ApiException.notFound("Invoice", id));
        if (!i.getUserId().equals(me.id())) throw ApiException.forbidden("Not your invoice");
        return ApiResponse.ok(InvoiceDto.of(i));
    }

    @GetMapping("/api/v1/admin/invoices")
    @Operation(summary = "Admin: search invoices")
    public ApiResponse<PageResponse<InvoiceDto>> adminList(@RequestParam(required = false) String userId,
                                                           @RequestParam(required = false) Invoice.Status status,
                                                           @RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "20") int size) {
        var p = repo.search(userId, status, PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, InvoiceDto::of));
    }
}
