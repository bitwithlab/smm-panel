package com.bitwithlab.smm.subscription;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubscriptionPlatformRepository extends JpaRepository<SubscriptionPlatform, String> {
    List<SubscriptionPlatform> findBySubscriptionId(String subscriptionId);
    long countBySubscriptionId(String subscriptionId);
    Optional<SubscriptionPlatform> findBySubscriptionIdAndPlatformId(String subscriptionId, Short platformId);
}
