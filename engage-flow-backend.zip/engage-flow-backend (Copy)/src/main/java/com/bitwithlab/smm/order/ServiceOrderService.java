package com.bitwithlab.smm.order;

import com.bitwithlab.smm.catalog.service.SmmService;
import com.bitwithlab.smm.catalog.service.SmmServiceRepository;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import com.bitwithlab.smm.wallet.WalletService;
import com.bitwithlab.smm.wallet.WalletTransaction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;

@Service
public class ServiceOrderService {

    private final ServiceOrderRepository orders;
    private final SmmServiceRepository services;
    private final WalletService wallet;
    private final ProviderClient provider;
    private final NotificationService notifier;

    public ServiceOrderService(ServiceOrderRepository orders, SmmServiceRepository services,
                               WalletService wallet, ProviderClient provider,
                               NotificationService notifier) {
        this.orders = orders; this.services = services; this.wallet = wallet;
        this.provider = provider; this.notifier = notifier;
    }

    @Transactional
    public ServiceOrder place(String userId, Integer serviceId, String targetLink, int quantity,
                              String subscriptionId, String socialAccountId) {
        SmmService svc = services.findById(serviceId).orElseThrow(() -> ApiException.notFound("Service", serviceId));
        if (!svc.isActive()) throw new ApiException(ErrorCode.SERVICE_INACTIVE, "Service not available");
        if (quantity < svc.getMinQuantity() || quantity > svc.getMaxQuantity())
            throw ApiException.badRequest("Quantity out of range (%d-%d)".formatted(svc.getMinQuantity(), svc.getMaxQuantity()));

        BigDecimal charge = svc.getRatePer1000()
                .multiply(BigDecimal.valueOf(quantity))
                .divide(BigDecimal.valueOf(1000), 2, RoundingMode.HALF_UP);

        // Debit wallet first — fails if insufficient
        WalletTransaction tx = wallet.debit(userId, charge, WalletTransaction.Reason.ORDER, "SERVICE_ORDER", null,
                "Order: %s x %d".formatted(svc.getName(), quantity));

        ServiceOrder o = new ServiceOrder();
        o.setId(IdGenerator.uuid());
        o.setOrderNumber(IdGenerator.orderNumber(orders.countByYear(LocalDate.now().getYear()) + 1));
        o.setUserId(userId);
        o.setSubscriptionId(subscriptionId);
        o.setSocialAccountId(socialAccountId);
        o.setServiceId(serviceId);
        o.setTargetLink(targetLink);
        o.setQuantity(quantity);
        o.setRatePer1000(svc.getRatePer1000());
        o.setChargeAmount(charge);
        o.setProviderId(svc.getProviderId());
        o.setWalletTxnId(tx.getId());
        orders.save(o);

        // Place upstream (stub)
        var pr = provider.placeBackOrder(svc.getProviderId(), svc.getProviderServiceId(), quantity, targetLink);
        if (pr.ok()) {
            o.setProviderOrderId(pr.providerOrderId());
            o.setStartCount(pr.startCount());
            o.setStatus(ServiceOrder.Status.IN_PROGRESS);
        }
        orders.save(o);

        notifier.push(userId, Notification.Type.ORDER_UPDATE,
                "Order placed",
                "Order %s placed for %d units.".formatted(o.getOrderNumber(), quantity));
        return o;
    }

    @Transactional
    public ServiceOrder cancel(String userId, String orderId) {
        ServiceOrder o = ownedOrder(userId, orderId);
        if (o.getStatus() == ServiceOrder.Status.COMPLETED || o.getStatus() == ServiceOrder.Status.PARTIAL)
            throw ApiException.conflict("Cannot cancel: order already delivered");
        if (o.getStatus() == ServiceOrder.Status.CANCELLED || o.getStatus() == ServiceOrder.Status.REFUNDED)
            return o;
        // refund to wallet
        wallet.credit(userId, o.getChargeAmount(), WalletTransaction.Reason.REFUND, "SERVICE_ORDER", o.getId(), "Order cancellation refund");
        o.setStatus(ServiceOrder.Status.CANCELLED);
        return orders.save(o);
    }

    @Transactional
    public ServiceOrder syncStatus(String orderId) {
        ServiceOrder o = orders.findById(orderId).orElseThrow(() -> ApiException.notFound("Order", orderId));
        if (o.getProviderId() == null || o.getProviderOrderId() == null) return o;
        var st = provider.fetchStatus(o.getProviderId(), o.getProviderOrderId());
        if (st.error() != null) return o;
        try {
            ServiceOrder.Status mapped = switch (st.status()) {
                case "PENDING" -> ServiceOrder.Status.PENDING;
                case "IN_PROGRESS", "Processing", "In progress" -> ServiceOrder.Status.IN_PROGRESS;
                case "COMPLETED", "Completed" -> ServiceOrder.Status.COMPLETED;
                case "PARTIAL", "Partial" -> ServiceOrder.Status.PARTIAL;
                case "CANCELLED", "Canceled" -> ServiceOrder.Status.CANCELLED;
                default -> o.getStatus();
            };
            o.setStatus(mapped);
            if (st.remains() != null) o.setRemains(st.remains());
            if (mapped == ServiceOrder.Status.COMPLETED && o.getCompletedAt() == null) o.setCompletedAt(Instant.now());
            return orders.save(o);
        } catch (Exception e) { return o; }
    }

    @Transactional
    public ServiceOrder forceUpdate(String orderId, ServiceOrder.Status status, Integer remains) {
        ServiceOrder o = orders.findById(orderId).orElseThrow(() -> ApiException.notFound("Order", orderId));
        if (status != null) o.setStatus(status);
        if (remains != null) o.setRemains(remains);
        if (status == ServiceOrder.Status.COMPLETED && o.getCompletedAt() == null) o.setCompletedAt(Instant.now());
        return orders.save(o);
    }

    private ServiceOrder ownedOrder(String userId, String orderId) {
        ServiceOrder o = orders.findById(orderId).orElseThrow(() -> ApiException.notFound("Order", orderId));
        if (!o.getUserId().equals(userId)) throw ApiException.forbidden("Not your order");
        return o;
    }
}
