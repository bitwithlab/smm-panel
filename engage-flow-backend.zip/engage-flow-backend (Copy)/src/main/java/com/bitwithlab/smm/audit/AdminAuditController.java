package com.bitwithlab.smm.audit;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/admin/audit-logs")
@Tag(name = "Admin: Audit Log")
public class AdminAuditController {

    private final AuditLogRepository repo;
    public AdminAuditController(AuditLogRepository repo) { this.repo = repo; }

    public record AuditDto(Long id, String actorUserId, String action, String entityType,
                           String entityId, String ip, String metadata, Instant createdAt) {
        public static AuditDto of(AuditLog a) {
            return new AuditDto(a.getId(), a.getActorUserId(), a.getAction(), a.getEntityType(),
                    a.getEntityId(), a.getIp(), a.getMetadata(), a.getCreatedAt());
        }
    }

    @GetMapping
    @Operation(summary = "Search audit logs")
    public ApiResponse<PageResponse<AuditDto>> list(
            @RequestParam(required = false) String actorUserId,
            @RequestParam(required = false) String action,
            @RequestParam(required = false) String entityType,
            @RequestParam(required = false) String entityId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        var p = repo.search(actorUserId, action, entityType, entityId,
                PageRequest.of(page, Math.min(size, 200), Sort.by("id").descending()));
        return ApiResponse.ok(PageResponse.of(p, AuditDto::of));
    }
}
