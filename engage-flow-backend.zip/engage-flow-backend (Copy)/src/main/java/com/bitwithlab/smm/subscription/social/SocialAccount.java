package com.bitwithlab.smm.subscription.social;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "social_accounts")
public class SocialAccount {

    public enum Status { ACTIVE, REMOVED }

    @Id @Column(length = 36) private String id;
    @Column(name = "subscription_id", nullable = false, length = 36) private String subscriptionId;
    @Column(name = "platform_id", nullable = false) private Short platformId;
    @Column(nullable = false, length = 190) private String username;
    @Column(name = "profile_url", length = 500) private String profileUrl;
    @Column(name = "is_verified", nullable = false) private boolean verified;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.ACTIVE;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "removed_at") private Instant removedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getSubscriptionId() { return subscriptionId; } public void setSubscriptionId(String s) { this.subscriptionId = s; }
    public Short getPlatformId() { return platformId; } public void setPlatformId(Short s) { this.platformId = s; }
    public String getUsername() { return username; } public void setUsername(String s) { this.username = s; }
    public String getProfileUrl() { return profileUrl; } public void setProfileUrl(String s) { this.profileUrl = s; }
    public boolean isVerified() { return verified; } public void setVerified(boolean v) { this.verified = v; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getRemovedAt() { return removedAt; } public void setRemovedAt(Instant t) { this.removedAt = t; }
}
