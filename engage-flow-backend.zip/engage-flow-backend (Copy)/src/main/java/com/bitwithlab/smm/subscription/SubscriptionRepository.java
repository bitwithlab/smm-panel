package com.bitwithlab.smm.subscription;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SubscriptionRepository extends JpaRepository<Subscription, String> {

    List<Subscription> findByUserIdOrderByCreatedAtDesc(String userId);

    Optional<Subscription> findByUserIdAndStatus(String userId, Subscription.Status status);

    @Query("""
        select s from Subscription s
        where (:userId is null or s.userId = :userId)
          and (:status is null or s.status = :status)
        """)
    Page<Subscription> search(@Param("userId") String userId,
                              @Param("status") Subscription.Status status,
                              Pageable pageable);
}
