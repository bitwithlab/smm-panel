package com.bitwithlab.smm.subscription.dto;

import com.bitwithlab.smm.subscription.Subscription;
import jakarta.validation.constraints.NotNull;

public record CreateSubscriptionRequest(
        @NotNull Short packageId,
        @NotNull Subscription.BillingCycle billingCycle,
        String couponCode
) {}
