package com.bitwithlab.smm.catalog.pkg;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PackageRepository extends JpaRepository<Package, Short> {
    List<Package> findByActiveTrueOrderBySortOrderAsc();
}
