package com.bitwithlab.smm.catalog.pkg;

import com.bitwithlab.smm.catalog.pkg.dto.PackageDto;
import com.bitwithlab.smm.catalog.pkg.dto.PackageWriteRequest;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/packages")
@Tag(name = "Admin: Packages")
public class AdminPackageController {

    private final PackageRepository repo;

    public AdminPackageController(PackageRepository repo) { this.repo = repo; }

    @GetMapping
    @Operation(summary = "List all packages (incl. inactive)")
    public ApiResponse<List<PackageDto>> list() {
        return ApiResponse.ok(repo.findAll().stream().map(PackageDto::of).toList());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a package")
    public ApiResponse<PackageDto> get(@PathVariable Short id) {
        return ApiResponse.ok(PackageDto.of(repo.findById(id).orElseThrow(() -> ApiException.notFound("Package", id))));
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update package fields (only provided fields are changed)")
    public ApiResponse<PackageDto> update(@PathVariable Short id, @Valid @RequestBody PackageWriteRequest req) {
        Package p = repo.findById(id).orElseThrow(() -> ApiException.notFound("Package", id));
        if (req.name() != null) p.setName(req.name());
        if (req.description() != null) p.setDescription(req.description());
        if (req.maxPlatforms() != null) p.setMaxPlatforms(req.maxPlatforms());
        if (req.maxAccountsPerPlatform() != null) p.setMaxAccountsPerPlatform(req.maxAccountsPerPlatform());
        if (req.priceMonthly() != null) p.setPriceMonthly(req.priceMonthly());
        if (req.priceYearly() != null) p.setPriceYearly(req.priceYearly());
        if (req.currency() != null) p.setCurrency(req.currency());
        if (req.active() != null) p.setActive(req.active());
        if (req.sortOrder() != null) p.setSortOrder(req.sortOrder());
        return ApiResponse.ok(PackageDto.of(repo.save(p)));
    }
}
