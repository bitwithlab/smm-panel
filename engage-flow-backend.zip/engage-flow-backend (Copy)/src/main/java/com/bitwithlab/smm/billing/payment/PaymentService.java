package com.bitwithlab.smm.billing.payment;

import com.bitwithlab.smm.billing.invoice.Invoice;
import com.bitwithlab.smm.billing.invoice.InvoiceRepository;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.subscription.SubscriptionService;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import com.bitwithlab.smm.wallet.WalletService;
import com.bitwithlab.smm.wallet.WalletTransaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository payments;
    private final InvoiceRepository invoices;
    private final WalletService walletService;
    private final SubscriptionService subscriptionService;
    private final NotificationService notifier;
    private final String appUrl;

    public PaymentService(PaymentRepository payments, InvoiceRepository invoices,
                          WalletService walletService, SubscriptionService subscriptionService,
                          NotificationService notifier, @Value("${app.app-url}") String appUrl) {
        this.payments = payments; this.invoices = invoices;
        this.walletService = walletService; this.subscriptionService = subscriptionService;
        this.notifier = notifier; this.appUrl = appUrl;
    }

    @Transactional
    public InitiateResult initiate(String userId, String invoiceId, Payment.Method method,
                                   String idempotencyKey, String ip, String userAgent) {
        if (idempotencyKey != null) {
            var existing = payments.findByIdempotencyKey(idempotencyKey);
            if (existing.isPresent()) return new InitiateResult(existing.get(), redirectUrl(existing.get()));
        }
        Invoice inv = invoices.findById(invoiceId).orElseThrow(() -> ApiException.notFound("Invoice", invoiceId));
        if (!inv.getUserId().equals(userId)) throw ApiException.forbidden("Not your invoice");
        if (inv.getStatus() == Invoice.Status.PAID) throw new ApiException(ErrorCode.INVOICE_ALREADY_PAID, "Invoice already paid");

        Payment p = new Payment();
        p.setId(IdGenerator.uuid());
        p.setInvoiceId(invoiceId);
        p.setUserId(userId);
        p.setMethod(method);
        p.setAmount(inv.getTotal());
        p.setCurrency(inv.getCurrency());
        p.setStatus(Payment.Status.INITIATED);
        p.setIdempotencyKey(idempotencyKey);
        p.setIp(ip);
        p.setUserAgent(userAgent);
        payments.save(p);

        // TODO: integrate real gateway here based on method (bKash/Nagad/Card/...)
        log.info("Payment initiated id={} method={} amount={}", p.getId(), method, p.getAmount());
        return new InitiateResult(p, redirectUrl(p));
    }

    @Transactional
    public Payment markSuccess(String paymentId, String gatewayTxnId, String gatewayPaymentId, String gatewayResponse) {
        Payment p = payments.findById(paymentId).orElseThrow(() -> ApiException.notFound("Payment", paymentId));
        if (p.getStatus() == Payment.Status.SUCCESS) return p;
        p.setStatus(Payment.Status.SUCCESS);
        p.setGatewayTxnId(gatewayTxnId);
        p.setGatewayPaymentId(gatewayPaymentId);
        p.setGatewayResponse(gatewayResponse);
        p.setPaidAt(Instant.now());
        payments.save(p);

        Invoice inv = invoices.findById(p.getInvoiceId()).orElseThrow();
        inv.setStatus(Invoice.Status.PAID);
        inv.setPaidAt(Instant.now());
        invoices.save(inv);

        // dispatch by purpose
        if (inv.getPurpose() == Invoice.Purpose.SUBSCRIPTION && inv.getSubscriptionId() != null) {
            subscriptionService.activateAfterPayment(inv.getSubscriptionId());
        } else if (inv.getPurpose() == Invoice.Purpose.WALLET_TOPUP) {
            walletService.credit(inv.getUserId(), inv.getTotal(), WalletTransaction.Reason.TOPUP,
                    "PAYMENT", p.getId(), "Wallet top-up via " + p.getMethod());
        }

        notifier.push(p.getUserId(), Notification.Type.PAYMENT, "Payment received",
                "Payment of %s %s has been received.".formatted(p.getAmount(), p.getCurrency()));
        return p;
    }

    @Transactional
    public Payment markFailed(String paymentId, String gatewayResponse) {
        Payment p = payments.findById(paymentId).orElseThrow(() -> ApiException.notFound("Payment", paymentId));
        if (p.getStatus() == Payment.Status.SUCCESS) return p;
        p.setStatus(Payment.Status.FAILED);
        p.setGatewayResponse(gatewayResponse);
        return payments.save(p);
    }

    private String redirectUrl(Payment p) {
        return "%s/api/v1/payments/redirect/%s".formatted(appUrl, p.getId());
    }

    public record InitiateResult(Payment payment, String redirectUrl) {}
}
