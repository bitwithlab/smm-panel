package com.bitwithlab.smm.catalog.provider;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProviderRepository extends JpaRepository<Provider, Integer> {
    List<Provider> findByActiveTrueOrderByNameAsc();
}
