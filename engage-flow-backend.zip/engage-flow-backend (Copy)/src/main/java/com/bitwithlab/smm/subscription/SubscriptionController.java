package com.bitwithlab.smm.subscription;

import com.bitwithlab.smm.billing.invoice.Invoice;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import com.bitwithlab.smm.subscription.dto.CreateSubscriptionRequest;
import com.bitwithlab.smm.subscription.dto.SubscriptionDto;
import com.bitwithlab.smm.subscription.social.SocialAccount;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/v1/me/subscriptions")
@Tag(name = "Subscriptions")
public class SubscriptionController {

    private final SubscriptionService service;

    public SubscriptionController(SubscriptionService service) { this.service = service; }

    public record CheckoutResponse(SubscriptionDto subscription, InvoiceLite invoice) {
        public record InvoiceLite(String id, String invoiceNumber, BigDecimal total, String currency, String status, Instant dueAt) {
            public static InvoiceLite of(Invoice i) {
                return new InvoiceLite(i.getId(), i.getInvoiceNumber(), i.getTotal(), i.getCurrency(), i.getStatus().name(), i.getDueAt());
            }
        }
    }
    public record AddPlatformRequest(@NotNull Short platformId) {}
    public record AddSocialRequest(@NotNull Short platformId, @NotBlank String username, String profileUrl) {}
    public record SocialDto(String id, Short platformId, String username, String profileUrl, String status, Instant createdAt) {
        public static SocialDto of(SocialAccount a) {
            return new SocialDto(a.getId(), a.getPlatformId(), a.getUsername(), a.getProfileUrl(), a.getStatus().name(), a.getCreatedAt());
        }
    }

    @PostMapping
    @Operation(summary = "Subscribe to a package — returns invoice to be paid")
    public ApiResponse<CheckoutResponse> subscribe(@CurrentUser UserPrincipal me, @Valid @RequestBody CreateSubscriptionRequest req) {
        var r = service.subscribe(me.id(), req);
        return ApiResponse.ok("Checkout created — pay the invoice to activate",
                new CheckoutResponse(SubscriptionDto.of(r.subscription(), List.of()), CheckoutResponse.InvoiceLite.of(r.invoice())));
    }

    @GetMapping
    @Operation(summary = "List my subscriptions")
    public ApiResponse<List<SubscriptionDto>> listMine(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(service.listMine(me.id()).stream()
                .map(s -> SubscriptionDto.of(s, service.listPlatformIds(s.getId()))).toList());
    }

    @GetMapping("/{id}")
    public ApiResponse<SubscriptionDto> get(@CurrentUser UserPrincipal me, @PathVariable String id) {
        var s = service.get(me.id(), id);
        return ApiResponse.ok(SubscriptionDto.of(s, service.listPlatformIds(s.getId())));
    }

    @PostMapping("/{id}/cancel")
    @Operation(summary = "Cancel a subscription (no auto-renew)")
    public ApiResponse<SubscriptionDto> cancel(@CurrentUser UserPrincipal me, @PathVariable String id) {
        var s = service.cancel(me.id(), id);
        return ApiResponse.ok("Cancelled", SubscriptionDto.of(s, service.listPlatformIds(s.getId())));
    }

    @PostMapping("/{id}/platforms")
    @Operation(summary = "Add a platform to my subscription")
    public ApiResponse<Void> addPlatform(@CurrentUser UserPrincipal me, @PathVariable String id, @Valid @RequestBody AddPlatformRequest req) {
        service.addPlatform(me.id(), id, req.platformId());
        return ApiResponse.ok("Platform added");
    }

    @DeleteMapping("/{id}/platforms/{platformId}")
    @Operation(summary = "Remove a platform (also removes its social accounts)")
    public ApiResponse<Void> removePlatform(@CurrentUser UserPrincipal me, @PathVariable String id, @PathVariable Short platformId) {
        service.removePlatform(me.id(), id, platformId);
        return ApiResponse.ok("Platform removed");
    }

    @GetMapping("/{id}/social-accounts")
    public ApiResponse<List<SocialDto>> listSocials(@CurrentUser UserPrincipal me, @PathVariable String id) {
        return ApiResponse.ok(service.listSocials(me.id(), id).stream().map(SocialDto::of).toList());
    }

    @PostMapping("/{id}/social-accounts")
    @Operation(summary = "Add a social account to receive engagement")
    public ApiResponse<SocialDto> addSocial(@CurrentUser UserPrincipal me, @PathVariable String id, @Valid @RequestBody AddSocialRequest req) {
        var a = service.addSocialAccount(me.id(), id, req.platformId(), req.username(), req.profileUrl());
        return ApiResponse.ok("Social account added", SocialDto.of(a));
    }

    @DeleteMapping("/{id}/social-accounts/{accountId}")
    public ApiResponse<Void> removeSocial(@CurrentUser UserPrincipal me, @PathVariable String id, @PathVariable String accountId) {
        service.removeSocialAccount(me.id(), id, accountId);
        return ApiResponse.ok("Removed");
    }
}
