package com.bitwithlab.smm.identity.device;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TrustedDeviceRepository extends JpaRepository<TrustedDevice, String> {
    Optional<TrustedDevice> findByUserIdAndDeviceFingerprint(String userId, String fingerprint);
    List<TrustedDevice> findByUserIdAndRevokedAtIsNullOrderByLastSeenAtDesc(String userId);
}
