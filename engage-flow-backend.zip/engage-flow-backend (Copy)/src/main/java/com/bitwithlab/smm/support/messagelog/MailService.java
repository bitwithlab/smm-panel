package com.bitwithlab.smm.support.messagelog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MailService {

    private static final Logger log = LoggerFactory.getLogger(MailService.class);

    private final JavaMailSender sender;
    private final MessageLogRepository logRepo;
    private final String from;
    private final String fromName;

    public MailService(JavaMailSender sender,
                       MessageLogRepository logRepo,
                       @Value("${app.mail.from}") String from,
                       @Value("${app.mail.from-name}") String fromName) {
        this.sender = sender;
        this.logRepo = logRepo;
        this.from = from;
        this.fromName = fromName;
    }

    @Async
    @Transactional
    public void send(String userId, String to, String template, String subject, String body) {
        MessageLog m = new MessageLog();
        m.setUserId(userId);
        m.setChannel(MessageLog.Channel.EMAIL);
        m.setToAddress(to);
        m.setTemplate(template);
        m.setSubject(subject);
        m.setProvider("smtp");
        log.info("Otp is:{}",body);
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom("%s <%s>".formatted(fromName, from));
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(body);
            sender.send(msg);
            m.setStatus(MessageLog.Status.SENT);
        } catch (Exception ex) {
            log.warn("Mail send failed to={} template={} err={}", to, template, ex.getMessage());
            m.setStatus(MessageLog.Status.FAILED);
            m.setError(ex.getMessage());
        }
        logRepo.save(m);
    }
}
