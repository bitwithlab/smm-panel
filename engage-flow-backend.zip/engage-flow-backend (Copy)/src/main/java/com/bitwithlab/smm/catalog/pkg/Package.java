package com.bitwithlab.smm.catalog.pkg;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "packages")
public class Package {

    public enum Code { BASIC, STANDARD, ULTRA }

    @Id private Short id;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16, unique = true) private Code code;
    @Column(nullable = false, length = 64) private String name;
    @Column(columnDefinition = "TEXT") private String description;
    @Column(name = "max_platforms", nullable = false) private Short maxPlatforms;
    @Column(name = "max_accounts_per_platform", nullable = false) private Short maxAccountsPerPlatform;
    @Column(name = "price_monthly", nullable = false, precision = 12, scale = 2) private BigDecimal priceMonthly;
    @Column(name = "price_yearly", nullable = false, precision = 12, scale = 2) private BigDecimal priceYearly;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Column(name = "is_active", nullable = false) private boolean active = true;
    @Column(name = "sort_order", nullable = false) private Short sortOrder = 0;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); updatedAt = Instant.now(); }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }

    public Short getId() { return id; } public void setId(Short id) { this.id = id; }
    public Code getCode() { return code; } public void setCode(Code c) { this.code = c; }
    public String getName() { return name; } public void setName(String s) { this.name = s; }
    public String getDescription() { return description; } public void setDescription(String s) { this.description = s; }
    public Short getMaxPlatforms() { return maxPlatforms; } public void setMaxPlatforms(Short n) { this.maxPlatforms = n; }
    public Short getMaxAccountsPerPlatform() { return maxAccountsPerPlatform; } public void setMaxAccountsPerPlatform(Short n) { this.maxAccountsPerPlatform = n; }
    public BigDecimal getPriceMonthly() { return priceMonthly; } public void setPriceMonthly(BigDecimal p) { this.priceMonthly = p; }
    public BigDecimal getPriceYearly() { return priceYearly; } public void setPriceYearly(BigDecimal p) { this.priceYearly = p; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public boolean isActive() { return active; } public void setActive(boolean a) { this.active = a; }
    public Short getSortOrder() { return sortOrder; } public void setSortOrder(Short n) { this.sortOrder = n; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
