package com.bitwithlab.smm.support.ticket;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "ticket_messages")
public class TicketMessage {

    @Id @Column(length = 36) private String id;
    @Column(name = "ticket_id", nullable = false, length = 36) private String ticketId;
    @Column(name = "sender_id", nullable = false, length = 36) private String senderId;
    @Column(nullable = false, columnDefinition = "TEXT") private String message;
    @Column(columnDefinition = "json") private String attachments;
    @Column(name = "is_internal_note", nullable = false) private boolean internalNote;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getTicketId() { return ticketId; } public void setTicketId(String s) { this.ticketId = s; }
    public String getSenderId() { return senderId; } public void setSenderId(String s) { this.senderId = s; }
    public String getMessage() { return message; } public void setMessage(String s) { this.message = s; }
    public String getAttachments() { return attachments; } public void setAttachments(String s) { this.attachments = s; }
    public boolean isInternalNote() { return internalNote; } public void setInternalNote(boolean b) { this.internalNote = b; }
    public Instant getCreatedAt() { return createdAt; }
}
