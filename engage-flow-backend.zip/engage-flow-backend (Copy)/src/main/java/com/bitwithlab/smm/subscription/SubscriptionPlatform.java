package com.bitwithlab.smm.subscription;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "subscription_platforms")
public class SubscriptionPlatform {

    @Id @Column(length = 36) private String id;
    @Column(name = "subscription_id", nullable = false, length = 36) private String subscriptionId;
    @Column(name = "platform_id", nullable = false) private Short platformId;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getSubscriptionId() { return subscriptionId; } public void setSubscriptionId(String s) { this.subscriptionId = s; }
    public Short getPlatformId() { return platformId; } public void setPlatformId(Short s) { this.platformId = s; }
    public Instant getCreatedAt() { return createdAt; }
}
