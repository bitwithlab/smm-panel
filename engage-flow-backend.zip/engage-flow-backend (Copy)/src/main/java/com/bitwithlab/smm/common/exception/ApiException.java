package com.bitwithlab.smm.common.exception;

public class ApiException extends RuntimeException {
    private final ErrorCode code;
    private final transient Object details;

    public ApiException(ErrorCode code, String message) {
        super(message);
        this.code = code;
        this.details = null;
    }

    public ApiException(ErrorCode code, String message, Object details) {
        super(message);
        this.code = code;
        this.details = details;
    }

    public ErrorCode code() { return code; }
    public Object details() { return details; }

    public static ApiException notFound(String entity, Object id) {
        return new ApiException(ErrorCode.NOT_FOUND, "%s not found: %s".formatted(entity, id));
    }

    public static ApiException conflict(String message) {
        return new ApiException(ErrorCode.CONFLICT, message);
    }

    public static ApiException badRequest(String message) {
        return new ApiException(ErrorCode.BAD_REQUEST, message);
    }

    public static ApiException forbidden(String message) {
        return new ApiException(ErrorCode.FORBIDDEN, message);
    }
}
