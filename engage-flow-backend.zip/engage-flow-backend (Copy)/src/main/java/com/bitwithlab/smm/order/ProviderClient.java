package com.bitwithlab.smm.order;

import com.bitwithlab.smm.catalog.provider.Provider;
import com.bitwithlab.smm.catalog.provider.ProviderRepository;
import com.bitwithlab.smm.common.util.AesGcmCipher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Stub upstream-provider integration.
 * Replace placeBackOrder / fetchStatus with HTTP calls to your real SMM API reseller.
 */
@Component
public class ProviderClient {

    private static final Logger log = LoggerFactory.getLogger(ProviderClient.class);

    private final ProviderRepository providers;
    @SuppressWarnings("unused") // used once HTTP integration is added
    private final AesGcmCipher cipher;

    public ProviderClient(ProviderRepository providers, AesGcmCipher cipher) {
        this.providers = providers; this.cipher = cipher;
    }

    public PlaceResult placeBackOrder(Integer providerId, String providerServiceId, int quantity, String link) {
        if (providerId == null) return new PlaceResult(null, null, "no provider");
        Provider p = providers.findById(providerId).orElse(null);
        if (p == null || !p.isActive()) return new PlaceResult(null, null, "provider unavailable");
        // String apiKey = cipher.decrypt(p.getApiKeyEncrypted());
        // TODO: HTTP POST p.getApiUrl() with apiKey + service + link + quantity
        log.info("[stub] placing order on provider={} service={} qty={} link={}", p.getName(), providerServiceId, quantity, link);
        return new PlaceResult("STUB-" + System.currentTimeMillis(), null, null);
    }

    public StatusResult fetchStatus(Integer providerId, String providerOrderId) {
        // TODO: HTTP call to provider status endpoint
        return new StatusResult("IN_PROGRESS", null, null);
    }

    public record PlaceResult(String providerOrderId, Integer startCount, String error) {
        public boolean ok() { return error == null && providerOrderId != null; }
    }
    public record StatusResult(String status, Integer remains, String error) {}
}
