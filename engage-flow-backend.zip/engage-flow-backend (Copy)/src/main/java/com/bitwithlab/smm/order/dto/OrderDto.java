package com.bitwithlab.smm.order.dto;

import com.bitwithlab.smm.order.ServiceOrder;

import java.math.BigDecimal;
import java.time.Instant;

public record OrderDto(
        String id, String orderNumber, String userId, Integer serviceId,
        String targetLink, Integer quantity, BigDecimal ratePer1000, BigDecimal chargeAmount,
        String currency, Integer startCount, Integer remains, String status,
        String providerOrderId, Instant placedAt, Instant completedAt
) {
    public static OrderDto of(ServiceOrder o) {
        return new OrderDto(o.getId(), o.getOrderNumber(), o.getUserId(), o.getServiceId(),
                o.getTargetLink(), o.getQuantity(), o.getRatePer1000(), o.getChargeAmount(),
                o.getCurrency(), o.getStartCount(), o.getRemains(), o.getStatus().name(),
                o.getProviderOrderId(), o.getPlacedAt(), o.getCompletedAt());
    }
}
