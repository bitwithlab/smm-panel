package com.bitwithlab.smm.identity.user;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.identity.auth.dto.UserDto;
import com.bitwithlab.smm.identity.user.dto.*;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/me")
@Tag(name = "Profile", description = "Current user profile, sessions, devices")
public class UserController {

    private final UserService service;

    public UserController(UserService service) { this.service = service; }

    @GetMapping
    @Operation(summary = "Get current user")
    public ApiResponse<UserDto> me(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(UserDto.of(service.get(me.id())));
    }

    @PutMapping
    @Operation(summary = "Update profile fields")
    public ApiResponse<UserDto> update(@CurrentUser UserPrincipal me, @Valid @RequestBody UpdateProfileRequest req) {
        return ApiResponse.ok(UserDto.of(service.updateProfile(me.id(), req)));
    }

    @PostMapping("/change-password")
    @Operation(summary = "Change password (revokes all sessions)")
    public ApiResponse<Void> changePassword(@CurrentUser UserPrincipal me, @Valid @RequestBody ChangePasswordRequest req) {
        service.changePassword(me.id(), req);
        return ApiResponse.ok("Password changed. All sessions revoked.");
    }

    @GetMapping("/devices")
    @Operation(summary = "List trusted devices")
    public ApiResponse<List<DeviceDto>> devices(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(service.listDevices(me.id()).stream().map(DeviceDto::of).toList());
    }

    @DeleteMapping("/devices/{id}")
    @Operation(summary = "Revoke a device (also revokes its sessions)")
    public ApiResponse<Void> revokeDevice(@CurrentUser UserPrincipal me, @PathVariable String id) {
        service.revokeDevice(me.id(), id);
        return ApiResponse.ok("Device revoked");
    }

    @GetMapping("/sessions")
    @Operation(summary = "List active login sessions")
    public ApiResponse<List<SessionDto>> sessions(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(service.listSessions(me.id()).stream().map(s -> SessionDto.of(s, me.sessionId())).toList());
    }

    @DeleteMapping("/sessions/{id}")
    @Operation(summary = "Revoke a single session")
    public ApiResponse<Void> revokeSession(@CurrentUser UserPrincipal me, @PathVariable String id) {
        service.revokeSession(me.id(), id);
        return ApiResponse.ok("Session revoked");
    }

    @DeleteMapping("/sessions")
    @Operation(summary = "Revoke all sessions except current")
    public ApiResponse<Integer> revokeOthers(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok("Other sessions revoked", service.revokeOtherSessions(me.id(), me.sessionId()));
    }
}
