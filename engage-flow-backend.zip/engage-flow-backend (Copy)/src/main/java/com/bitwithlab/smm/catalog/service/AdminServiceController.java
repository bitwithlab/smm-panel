package com.bitwithlab.smm.catalog.service;

import com.bitwithlab.smm.catalog.service.dto.AdminServiceDto;
import com.bitwithlab.smm.catalog.service.dto.ServiceWriteRequest;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/services")
@Tag(name = "Admin: Services")
public class AdminServiceController {

    private final SmmServiceRepository repo;

    public AdminServiceController(SmmServiceRepository repo) { this.repo = repo; }

    @GetMapping
    @Operation(summary = "Search services (filter platform/category/active)")
    public ApiResponse<PageResponse<AdminServiceDto>> list(
            @RequestParam(required = false) Short platformId,
            @RequestParam(required = false) SmmService.Category category,
            @RequestParam(required = false) Boolean active,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var p = repo.search(platformId, category, active,
                PageRequest.of(page, Math.min(size, 100), Sort.by("id").descending()));
        return ApiResponse.ok(PageResponse.of(p, AdminServiceDto::of));
    }

    @GetMapping("/{id}")
    public ApiResponse<AdminServiceDto> get(@PathVariable Integer id) {
        return ApiResponse.ok(AdminServiceDto.of(repo.findById(id).orElseThrow(() -> ApiException.notFound("Service", id))));
    }

    @PostMapping
    @Operation(summary = "Create service")
    public ApiResponse<AdminServiceDto> create(@Valid @RequestBody ServiceWriteRequest req) {
        if (req.platformId() == null || req.name() == null || req.category() == null || req.ratePer1000() == null)
            throw ApiException.badRequest("platformId, name, category, ratePer1000 are required");
        SmmService s = new SmmService();
        s.setPlatformId(req.platformId());
        s.setName(req.name());
        s.setCategory(req.category());
        if (req.minQuantity() != null) s.setMinQuantity(req.minQuantity());
        if (req.maxQuantity() != null) s.setMaxQuantity(req.maxQuantity());
        s.setRatePer1000(req.ratePer1000());
        s.setProviderCostPer1000(req.providerCostPer1000());
        s.setProviderId(req.providerId());
        s.setProviderServiceId(req.providerServiceId());
        if (req.active() != null) s.setActive(req.active());
        return ApiResponse.ok(AdminServiceDto.of(repo.save(s)));
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Update service (only provided fields)")
    public ApiResponse<AdminServiceDto> update(@PathVariable Integer id, @RequestBody ServiceWriteRequest req) {
        SmmService s = repo.findById(id).orElseThrow(() -> ApiException.notFound("Service", id));
        if (req.platformId() != null) s.setPlatformId(req.platformId());
        if (req.name() != null) s.setName(req.name());
        if (req.category() != null) s.setCategory(req.category());
        if (req.minQuantity() != null) s.setMinQuantity(req.minQuantity());
        if (req.maxQuantity() != null) s.setMaxQuantity(req.maxQuantity());
        if (req.ratePer1000() != null) s.setRatePer1000(req.ratePer1000());
        if (req.providerCostPer1000() != null) s.setProviderCostPer1000(req.providerCostPer1000());
        if (req.providerId() != null) s.setProviderId(req.providerId());
        if (req.providerServiceId() != null) s.setProviderServiceId(req.providerServiceId());
        if (req.active() != null) s.setActive(req.active());
        return ApiResponse.ok(AdminServiceDto.of(repo.save(s)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deactivate service (soft)")
    public ApiResponse<Void> deactivate(@PathVariable Integer id) {
        SmmService s = repo.findById(id).orElseThrow(() -> ApiException.notFound("Service", id));
        s.setActive(false);
        repo.save(s);
        return ApiResponse.ok("Deactivated");
    }
}
