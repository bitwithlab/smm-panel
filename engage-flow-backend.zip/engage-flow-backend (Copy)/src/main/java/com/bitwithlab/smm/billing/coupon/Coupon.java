package com.bitwithlab.smm.billing.coupon;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "coupons")
public class Coupon {

    public enum DiscountType { PERCENT, FIXED }

    @Id @Column(length = 36) private String id;
    @Column(nullable = false, length = 32, unique = true) private String code;
    @Enumerated(EnumType.STRING) @Column(name = "discount_type", nullable = false, length = 8) private DiscountType discountType;
    @Column(name = "discount_value", nullable = false, precision = 10, scale = 2) private BigDecimal discountValue;
    @Column(name = "max_uses") private Integer maxUses;
    @Column(name = "used_count", nullable = false) private int usedCount;
    @Column(name = "valid_from", nullable = false) private Instant validFrom;
    @Column(name = "valid_until", nullable = false) private Instant validUntil;
    @Column(name = "applicable_packages", columnDefinition = "json") private String applicablePackages;
    @Column(name = "is_active", nullable = false) private boolean active = true;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public boolean isUsable() {
        Instant now = Instant.now();
        return active && now.isAfter(validFrom) && now.isBefore(validUntil)
                && (maxUses == null || usedCount < maxUses);
    }

    public BigDecimal apply(BigDecimal price) {
        if (discountType == DiscountType.PERCENT) {
            return price.multiply(BigDecimal.valueOf(100).subtract(discountValue))
                    .divide(BigDecimal.valueOf(100));
        }
        return price.subtract(discountValue).max(BigDecimal.ZERO);
    }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getCode() { return code; } public void setCode(String c) { this.code = c; }
    public DiscountType getDiscountType() { return discountType; } public void setDiscountType(DiscountType d) { this.discountType = d; }
    public BigDecimal getDiscountValue() { return discountValue; } public void setDiscountValue(BigDecimal v) { this.discountValue = v; }
    public Integer getMaxUses() { return maxUses; } public void setMaxUses(Integer i) { this.maxUses = i; }
    public int getUsedCount() { return usedCount; } public void setUsedCount(int n) { this.usedCount = n; }
    public Instant getValidFrom() { return validFrom; } public void setValidFrom(Instant t) { this.validFrom = t; }
    public Instant getValidUntil() { return validUntil; } public void setValidUntil(Instant t) { this.validUntil = t; }
    public String getApplicablePackages() { return applicablePackages; } public void setApplicablePackages(String s) { this.applicablePackages = s; }
    public boolean isActive() { return active; } public void setActive(boolean a) { this.active = a; }
    public Instant getCreatedAt() { return createdAt; }
}
