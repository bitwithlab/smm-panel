package com.bitwithlab.smm.identity.auth.dto;

import com.bitwithlab.smm.identity.user.User;

import java.time.Instant;

public record UserDto(
        String id,
        String name,
        String email,
        String phone,
        String role,
        String status,
        String profileImageUrl,
        Instant createdAt
) {
    public static UserDto of(User u) {
        return new UserDto(
                u.getId(), u.getName(), u.getEmail(), u.getPhone(),
                u.getRole().name(), u.getStatus().name(),
                u.getProfileImageUrl(), u.getCreatedAt()
        );
    }
}
