package com.bitwithlab.smm.billing.refund;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "refunds")
public class Refund {

    public enum Destination { WALLET, GATEWAY }
    public enum Status { REQUESTED, APPROVED, REJECTED, COMPLETED }

    @Id @Column(length = 36) private String id;
    @Column(name = "payment_id", length = 36) private String paymentId;
    @Column(name = "order_id", length = 36) private String orderId;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Destination destination = Destination.WALLET;
    @Column(columnDefinition = "TEXT") private String reason;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.REQUESTED;
    @Column(name = "processed_by", length = 36) private String processedBy;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "processed_at") private Instant processedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getPaymentId() { return paymentId; } public void setPaymentId(String s) { this.paymentId = s; }
    public String getOrderId() { return orderId; } public void setOrderId(String s) { this.orderId = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public BigDecimal getAmount() { return amount; } public void setAmount(BigDecimal b) { this.amount = b; }
    public Destination getDestination() { return destination; } public void setDestination(Destination d) { this.destination = d; }
    public String getReason() { return reason; } public void setReason(String s) { this.reason = s; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public String getProcessedBy() { return processedBy; } public void setProcessedBy(String s) { this.processedBy = s; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getProcessedAt() { return processedAt; } public void setProcessedAt(Instant t) { this.processedAt = t; }
}
