package com.bitwithlab.smm.identity.auth.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Schema(description = "Sign-up payload")
public record RegisterRequest(
        @NotBlank @Size(min = 2, max = 120) String name,
        @NotBlank @Email @Size(max = 190) String email,
        @NotBlank @Pattern(regexp = "^\\+?[0-9]{10,15}$", message = "Invalid phone number") String phone,
        @NotBlank @Size(min = 8, max = 100) String password,
        @Schema(description = "Must be true; user has accepted ToS") boolean acceptTerms
) {}
