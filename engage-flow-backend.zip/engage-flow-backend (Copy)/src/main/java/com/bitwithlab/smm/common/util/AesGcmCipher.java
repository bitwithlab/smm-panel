package com.bitwithlab.smm.common.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * AES-256-GCM symmetric encryption — used for storing provider API keys at rest.
 * Format: base64(iv || ciphertext || tag)
 */
@Component
public class AesGcmCipher {
    private static final int IV_BYTES = 12;
    private static final int TAG_BITS = 128;
    private final SecretKeySpec key;
    private final SecureRandom random = new SecureRandom();

    public AesGcmCipher(@Value("${app.provider-key.encryption-key}") String base64Key) {
        byte[] raw = Base64.getDecoder().decode(base64Key.length() == 44 ? base64Key
                : Base64.getEncoder().encodeToString(padTo32(base64Key.getBytes())));
        if (raw.length != 32) {
            byte[] fixed = new byte[32];
            System.arraycopy(raw, 0, fixed, 0, Math.min(raw.length, 32));
            raw = fixed;
        }
        this.key = new SecretKeySpec(raw, "AES");
    }

    public String encrypt(String plaintext) {
        try {
            byte[] iv = new byte[IV_BYTES];
            random.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, iv));
            byte[] ct = c.doFinal(plaintext.getBytes());
            ByteBuffer bb = ByteBuffer.allocate(iv.length + ct.length);
            bb.put(iv).put(ct);
            return Base64.getEncoder().encodeToString(bb.array());
        } catch (Exception e) {
            throw new IllegalStateException("AES-GCM encrypt failure", e);
        }
    }

    public String decrypt(String b64) {
        try {
            byte[] all = Base64.getDecoder().decode(b64);
            byte[] iv = new byte[IV_BYTES];
            byte[] ct = new byte[all.length - IV_BYTES];
            System.arraycopy(all, 0, iv, 0, IV_BYTES);
            System.arraycopy(all, IV_BYTES, ct, 0, ct.length);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, iv));
            return new String(c.doFinal(ct));
        } catch (Exception e) {
            throw new IllegalStateException("AES-GCM decrypt failure", e);
        }
    }

    private static byte[] padTo32(byte[] in) {
        byte[] out = new byte[32];
        System.arraycopy(in, 0, out, 0, Math.min(in.length, 32));
        return out;
    }
}
