package com.bitwithlab.smm.identity.user.dto;

import com.bitwithlab.smm.identity.session.LoginSession;

import java.time.Instant;

public record SessionDto(
        String id,
        String deviceId,
        String ip,
        String userAgent,
        Instant issuedAt,
        Instant expiresAt,
        boolean current
) {
    public static SessionDto of(LoginSession s, String currentSessionId) {
        return new SessionDto(s.getId(), s.getDeviceId(), s.getIp(), s.getUserAgent(),
                s.getIssuedAt(), s.getExpiresAt(), s.getId().equals(currentSessionId));
    }
}
