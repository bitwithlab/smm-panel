package com.bitwithlab.smm.security.jwt;

import com.bitwithlab.smm.security.UserPrincipal;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwt;

    public JwtAuthFilter(JwtService jwt) { this.jwt = jwt; }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication() == null) {
            String token = header.substring(7);
            try {
                Claims c = jwt.parse(token);
                if (JwtService.TYPE_ACCESS.equals(c.get(JwtService.CLAIM_TYPE, String.class))) {
                    UserPrincipal principal = new UserPrincipal(
                            c.getSubject(),
                            null,
                            c.get(JwtService.CLAIM_ROLE, String.class),
                            "ACTIVE",
                            c.get(JwtService.CLAIM_SESSION, String.class),
                            c.get(JwtService.CLAIM_DEVICE, String.class)
                    );
                    var auth = new UsernamePasswordAuthenticationToken(principal, null, principal.getAuthorities());
                    auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            } catch (JwtException ignored) {
                // invalid/expired token => stays anonymous, AuthEntryPoint handles 401 if endpoint protected
            }
        }
        chain.doFilter(request, response);
    }
}
