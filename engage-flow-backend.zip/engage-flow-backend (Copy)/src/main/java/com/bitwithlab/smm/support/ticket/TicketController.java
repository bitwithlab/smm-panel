package com.bitwithlab.smm.support.ticket;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/v1/me/tickets")
@Tag(name = "Tickets")
public class TicketController {

    private final TicketRepository tickets;
    private final TicketMessageRepository messages;

    public TicketController(TicketRepository tickets, TicketMessageRepository messages) {
        this.tickets = tickets; this.messages = messages;
    }

    public record CreateTicketRequest(@NotBlank @Size(max = 255) String subject,
                                      @NotNull Ticket.Category category,
                                      Ticket.Priority priority,
                                      String relatedOrderId,
                                      @NotBlank String message) {}
    public record ReplyRequest(@NotBlank String message) {}
    public record TicketDto(String id, String ticketNumber, String userId, String subject,
                            String category, String priority, String status, String assignedTo,
                            String relatedOrderId, Instant createdAt, Instant updatedAt) {
        public static TicketDto of(Ticket t) {
            return new TicketDto(t.getId(), t.getTicketNumber(), t.getUserId(), t.getSubject(),
                    t.getCategory().name(), t.getPriority().name(), t.getStatus().name(),
                    t.getAssignedTo(), t.getRelatedOrderId(), t.getCreatedAt(), t.getUpdatedAt());
        }
    }
    public record MessageDto(String id, String ticketId, String senderId, String message,
                             boolean internalNote, Instant createdAt) {
        public static MessageDto of(TicketMessage m) {
            return new MessageDto(m.getId(), m.getTicketId(), m.getSenderId(), m.getMessage(),
                    m.isInternalNote(), m.getCreatedAt());
        }
    }

    @PostMapping
    @Transactional
    @Operation(summary = "Open a new ticket")
    public ApiResponse<TicketDto> create(@CurrentUser UserPrincipal me, @Valid @RequestBody CreateTicketRequest req) {
        Ticket t = new Ticket();
        t.setId(IdGenerator.uuid());
        t.setTicketNumber(IdGenerator.ticketNumber(tickets.countAll() + 1));
        t.setUserId(me.id());
        t.setSubject(req.subject());
        t.setCategory(req.category());
        if (req.priority() != null) t.setPriority(req.priority());
        t.setRelatedOrderId(req.relatedOrderId());
        tickets.save(t);

        TicketMessage m = new TicketMessage();
        m.setId(IdGenerator.uuid());
        m.setTicketId(t.getId());
        m.setSenderId(me.id());
        m.setMessage(req.message());
        messages.save(m);

        return ApiResponse.ok("Ticket created", TicketDto.of(t));
    }

    @GetMapping
    public ApiResponse<PageResponse<TicketDto>> mine(@CurrentUser UserPrincipal me,
                                                     @RequestParam(defaultValue = "0") int page,
                                                     @RequestParam(defaultValue = "20") int size) {
        var p = tickets.findByUserIdOrderByCreatedAtDesc(me.id(), PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, TicketDto::of));
    }

    @GetMapping("/{id}")
    public ApiResponse<TicketDto> get(@CurrentUser UserPrincipal me, @PathVariable String id) {
        Ticket t = ownedTicket(me.id(), id);
        return ApiResponse.ok(TicketDto.of(t));
    }

    @GetMapping("/{id}/messages")
    public ApiResponse<List<MessageDto>> threads(@CurrentUser UserPrincipal me, @PathVariable String id) {
        ownedTicket(me.id(), id);
        return ApiResponse.ok(messages.findByTicketIdOrderByCreatedAtAsc(id).stream()
                .filter(m -> !m.isInternalNote()).map(MessageDto::of).toList());
    }

    @PostMapping("/{id}/messages")
    @Transactional
    public ApiResponse<MessageDto> reply(@CurrentUser UserPrincipal me, @PathVariable String id,
                                         @Valid @RequestBody ReplyRequest req) {
        Ticket t = ownedTicket(me.id(), id);
        if (t.getStatus() == Ticket.Status.CLOSED) throw ApiException.conflict("Ticket is closed");
        TicketMessage m = new TicketMessage();
        m.setId(IdGenerator.uuid());
        m.setTicketId(id);
        m.setSenderId(me.id());
        m.setMessage(req.message());
        messages.save(m);
        if (t.getStatus() == Ticket.Status.WAITING_USER) {
            t.setStatus(Ticket.Status.IN_PROGRESS);
            tickets.save(t);
        }
        return ApiResponse.ok("Reply sent", MessageDto.of(m));
    }

    @PostMapping("/{id}/close")
    public ApiResponse<TicketDto> close(@CurrentUser UserPrincipal me, @PathVariable String id) {
        Ticket t = ownedTicket(me.id(), id);
        t.setStatus(Ticket.Status.CLOSED);
        t.setClosedAt(Instant.now());
        tickets.save(t);
        return ApiResponse.ok("Closed", TicketDto.of(t));
    }

    private Ticket ownedTicket(String userId, String id) {
        Ticket t = tickets.findById(id).orElseThrow(() -> ApiException.notFound("Ticket", id));
        if (!t.getUserId().equals(userId)) throw ApiException.forbidden("Not your ticket");
        return t;
    }
}
