package com.bitwithlab.smm.identity.device;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "trusted_devices")
public class TrustedDevice {

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(name = "device_fingerprint", nullable = false, length = 128) private String deviceFingerprint;
    @Column(name = "device_name", length = 120) private String deviceName;
    @Column(length = 64) private String os;
    @Column(length = 64) private String browser;
    @Column(name = "last_ip", length = 45) private String lastIp;
    @Column(name = "last_country", length = 64) private String lastCountry;
    @Column(name = "last_city", length = 120) private String lastCity;
    @Column(name = "trusted_at") private Instant trustedAt;
    @Column(name = "last_seen_at", nullable = false) private Instant lastSeenAt;
    @Column(name = "revoked_at") private Instant revokedAt;

    @PrePersist void onCreate() { if (lastSeenAt == null) lastSeenAt = Instant.now(); }

    public boolean isTrusted() { return trustedAt != null && revokedAt == null; }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String userId) { this.userId = userId; }
    public String getDeviceFingerprint() { return deviceFingerprint; } public void setDeviceFingerprint(String s) { this.deviceFingerprint = s; }
    public String getDeviceName() { return deviceName; } public void setDeviceName(String s) { this.deviceName = s; }
    public String getOs() { return os; } public void setOs(String os) { this.os = os; }
    public String getBrowser() { return browser; } public void setBrowser(String s) { this.browser = s; }
    public String getLastIp() { return lastIp; } public void setLastIp(String s) { this.lastIp = s; }
    public String getLastCountry() { return lastCountry; } public void setLastCountry(String s) { this.lastCountry = s; }
    public String getLastCity() { return lastCity; } public void setLastCity(String s) { this.lastCity = s; }
    public Instant getTrustedAt() { return trustedAt; } public void setTrustedAt(Instant t) { this.trustedAt = t; }
    public Instant getLastSeenAt() { return lastSeenAt; } public void setLastSeenAt(Instant t) { this.lastSeenAt = t; }
    public Instant getRevokedAt() { return revokedAt; } public void setRevokedAt(Instant t) { this.revokedAt = t; }
}
