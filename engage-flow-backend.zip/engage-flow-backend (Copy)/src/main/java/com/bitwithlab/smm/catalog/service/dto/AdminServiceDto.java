package com.bitwithlab.smm.catalog.service.dto;

import com.bitwithlab.smm.catalog.service.SmmService;

import java.math.BigDecimal;

public record AdminServiceDto(
        Integer id,
        Short platformId,
        String name,
        String category,
        Integer minQuantity,
        Integer maxQuantity,
        BigDecimal ratePer1000,
        BigDecimal providerCostPer1000,
        Integer providerId,
        String providerServiceId,
        boolean active
) {
    public static AdminServiceDto of(SmmService s) {
        return new AdminServiceDto(s.getId(), s.getPlatformId(), s.getName(), s.getCategory().name(),
                s.getMinQuantity(), s.getMaxQuantity(), s.getRatePer1000(), s.getProviderCostPer1000(),
                s.getProviderId(), s.getProviderServiceId(), s.isActive());
    }
}
