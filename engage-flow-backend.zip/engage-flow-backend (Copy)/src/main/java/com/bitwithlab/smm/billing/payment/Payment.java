package com.bitwithlab.smm.billing.payment;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "payments")
public class Payment {

    public enum Method { BKASH, NAGAD, ROCKET, CARD, BANK_TRANSFER, MANUAL }
    public enum Status { INITIATED, PENDING, SUCCESS, FAILED, REFUNDED }

    @Id @Column(length = 36) private String id;
    @Column(name = "invoice_id", nullable = false, length = 36) private String invoiceId;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Method method;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.INITIATED;
    @Column(name = "gateway_txn_id", length = 120) private String gatewayTxnId;
    @Column(name = "gateway_payment_id", length = 120) private String gatewayPaymentId;
    @Column(name = "gateway_response", columnDefinition = "json") private String gatewayResponse;
    @Column(name = "idempotency_key", length = 80, unique = true) private String idempotencyKey;
    @Column(length = 45) private String ip;
    @Column(name = "user_agent", length = 500) private String userAgent;
    @Column(name = "paid_at") private Instant paidAt;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); updatedAt = Instant.now(); }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getInvoiceId() { return invoiceId; } public void setInvoiceId(String s) { this.invoiceId = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Method getMethod() { return method; } public void setMethod(Method m) { this.method = m; }
    public BigDecimal getAmount() { return amount; } public void setAmount(BigDecimal b) { this.amount = b; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public String getGatewayTxnId() { return gatewayTxnId; } public void setGatewayTxnId(String s) { this.gatewayTxnId = s; }
    public String getGatewayPaymentId() { return gatewayPaymentId; } public void setGatewayPaymentId(String s) { this.gatewayPaymentId = s; }
    public String getGatewayResponse() { return gatewayResponse; } public void setGatewayResponse(String s) { this.gatewayResponse = s; }
    public String getIdempotencyKey() { return idempotencyKey; } public void setIdempotencyKey(String s) { this.idempotencyKey = s; }
    public String getIp() { return ip; } public void setIp(String s) { this.ip = s; }
    public String getUserAgent() { return userAgent; } public void setUserAgent(String s) { this.userAgent = s; }
    public Instant getPaidAt() { return paidAt; } public void setPaidAt(Instant t) { this.paidAt = t; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
