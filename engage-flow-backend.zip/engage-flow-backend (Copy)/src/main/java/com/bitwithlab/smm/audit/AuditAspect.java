package com.bitwithlab.smm.audit;

import com.bitwithlab.smm.common.util.ClientInfo;
import com.bitwithlab.smm.security.UserPrincipal;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
public class AuditAspect {

    private final AuditService audit;

    public AuditAspect(AuditService audit) { this.audit = audit; }

    @Around("@annotation(audited)")
    public Object around(ProceedingJoinPoint pjp, Audited audited) throws Throwable {
        Object result = pjp.proceed();
        try {
            String actor = null;
            var auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof UserPrincipal up) actor = up.id();

            String ip = null, ua = null, entityId = null;
            ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest req = attrs.getRequest();
                ClientInfo info = ClientInfo.from(req);
                ip = info.ip();
                ua = info.userAgent();
                entityId = req.getRequestURI(); // best-effort
            }
            audit.record(actor, audited.action(), audited.entityType(), entityId, ip, ua, null);
        } catch (Exception ignored) {}
        return result;
    }
}
