package com.bitwithlab.smm.billing.refund;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RefundRepository extends JpaRepository<Refund, String> {
    Page<Refund> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);
    Page<Refund> findByStatusOrderByCreatedAtDesc(Refund.Status status, Pageable pageable);
}
