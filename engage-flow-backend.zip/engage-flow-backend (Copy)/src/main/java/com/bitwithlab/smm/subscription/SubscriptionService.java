package com.bitwithlab.smm.subscription;

import com.bitwithlab.smm.billing.coupon.Coupon;
import com.bitwithlab.smm.billing.coupon.CouponRepository;
import com.bitwithlab.smm.billing.invoice.Invoice;
import com.bitwithlab.smm.billing.invoice.InvoiceRepository;
import com.bitwithlab.smm.catalog.pkg.Package;
import com.bitwithlab.smm.catalog.pkg.PackageRepository;
import com.bitwithlab.smm.catalog.platform.Platform;
import com.bitwithlab.smm.catalog.platform.PlatformRepository;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.subscription.dto.CreateSubscriptionRequest;
import com.bitwithlab.smm.subscription.social.SocialAccount;
import com.bitwithlab.smm.subscription.social.SocialAccountRepository;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class SubscriptionService {

    private final SubscriptionRepository subs;
    private final SubscriptionPlatformRepository subPlatforms;
    private final SocialAccountRepository socials;
    private final PackageRepository packages;
    private final PlatformRepository platforms;
    private final InvoiceRepository invoices;
    private final CouponRepository coupons;
    private final NotificationService notifier;

    public SubscriptionService(SubscriptionRepository subs,
                               SubscriptionPlatformRepository subPlatforms,
                               SocialAccountRepository socials,
                               PackageRepository packages,
                               PlatformRepository platforms,
                               InvoiceRepository invoices,
                               CouponRepository coupons,
                               NotificationService notifier) {
        this.subs = subs; this.subPlatforms = subPlatforms; this.socials = socials;
        this.packages = packages; this.platforms = platforms;
        this.invoices = invoices; this.coupons = coupons; this.notifier = notifier;
    }

    @Transactional
    public CheckoutResult subscribe(String userId, CreateSubscriptionRequest req) {
        Package pkg = packages.findById(req.packageId())
                .orElseThrow(() -> ApiException.notFound("Package", req.packageId()));
        if (!pkg.isActive()) throw new ApiException(ErrorCode.PACKAGE_INACTIVE, "Package not available");

        BigDecimal price = req.billingCycle() == Subscription.BillingCycle.YEARLY ? pkg.getPriceYearly() : pkg.getPriceMonthly();
        BigDecimal discount = BigDecimal.ZERO;
        Coupon coupon = null;
        if (req.couponCode() != null && !req.couponCode().isBlank()) {
            coupon = coupons.findByCodeIgnoreCase(req.couponCode())
                    .filter(Coupon::isUsable)
                    .orElseThrow(() -> new ApiException(ErrorCode.COUPON_INVALID, "Invalid coupon"));
            BigDecimal newPrice = coupon.apply(price);
            discount = price.subtract(newPrice);
            price = newPrice;
            coupon.setUsedCount(coupon.getUsedCount() + 1);
            coupons.save(coupon);
        }

        Subscription s = new Subscription();
        s.setId(IdGenerator.uuid());
        s.setUserId(userId);
        s.setPackageId(pkg.getId());
        s.setBillingCycle(req.billingCycle());
        s.setPrice(price);
        s.setCurrency(pkg.getCurrency());
        s.setMaxPlatformsSnapshot(pkg.getMaxPlatforms());
        s.setMaxAccountsSnapshot(pkg.getMaxAccountsPerPlatform());
        if (coupon != null) s.setCouponId(coupon.getId());
        subs.save(s);

        Invoice inv = new Invoice();
        inv.setId(IdGenerator.uuid());
        inv.setInvoiceNumber(IdGenerator.invoiceNumber(invoices.countByYear(Instant.now().atZone(java.time.ZoneId.of("Asia/Dhaka")).getYear()) + 1));
        inv.setUserId(userId);
        inv.setPurpose(Invoice.Purpose.SUBSCRIPTION);
        inv.setSubscriptionId(s.getId());
        inv.setSubtotal(price.add(discount));
        inv.setDiscount(discount);
        inv.setTotal(price);
        inv.setCurrency(pkg.getCurrency());
        inv.setDueAt(Instant.now().plus(7, ChronoUnit.DAYS));
        invoices.save(inv);

        notifier.push(userId, Notification.Type.PAYMENT,
                "Invoice created",
                "Invoice %s for %s %s is awaiting payment.".formatted(inv.getInvoiceNumber(), price, pkg.getCurrency()));

        return new CheckoutResult(s, inv);
    }

    @Transactional
    public void activateAfterPayment(String subscriptionId) {
        Subscription s = subs.findById(subscriptionId)
                .orElseThrow(() -> ApiException.notFound("Subscription", subscriptionId));
        if (s.getStatus() == Subscription.Status.ACTIVE) return;
        Instant now = Instant.now();
        s.setStatus(Subscription.Status.ACTIVE);
        s.setStartsAt(now);
        s.setEndsAt(s.getBillingCycle() == Subscription.BillingCycle.YEARLY
                ? now.plus(365, ChronoUnit.DAYS) : now.plus(30, ChronoUnit.DAYS));
        subs.save(s);
        notifier.push(s.getUserId(), Notification.Type.PAYMENT,
                "Subscription activated", "Your plan is now active until " + s.getEndsAt());
    }

    @Transactional
    public Subscription cancel(String userId, String subscriptionId) {
        Subscription s = ownedSub(userId, subscriptionId);
        if (s.getStatus() == Subscription.Status.CANCELLED) return s;
        s.setStatus(Subscription.Status.CANCELLED);
        s.setCancelledAt(Instant.now());
        s.setAutoRenew(false);
        return subs.save(s);
    }

    @Transactional
    public SubscriptionPlatform addPlatform(String userId, String subscriptionId, Short platformId) {
        Subscription s = ownedSub(userId, subscriptionId);
        if (s.getStatus() != Subscription.Status.ACTIVE)
            throw ApiException.conflict("Subscription is not active");
        Platform p = platforms.findById(platformId).orElseThrow(() -> ApiException.notFound("Platform", platformId));
        if (!p.isActive()) throw ApiException.conflict("Platform inactive");

        if (subPlatforms.findBySubscriptionIdAndPlatformId(subscriptionId, platformId).isPresent())
            throw ApiException.conflict("Platform already added");

        long count = subPlatforms.countBySubscriptionId(subscriptionId);
        if (count >= s.getMaxPlatformsSnapshot())
            throw new ApiException(ErrorCode.SUBSCRIPTION_LIMIT_EXCEEDED, "Platform limit reached");

        SubscriptionPlatform sp = new SubscriptionPlatform();
        sp.setId(IdGenerator.uuid());
        sp.setSubscriptionId(subscriptionId);
        sp.setPlatformId(platformId);
        return subPlatforms.save(sp);
    }

    @Transactional
    public void removePlatform(String userId, String subscriptionId, Short platformId) {
        ownedSub(userId, subscriptionId);
        SubscriptionPlatform sp = subPlatforms.findBySubscriptionIdAndPlatformId(subscriptionId, platformId)
                .orElseThrow(() -> ApiException.notFound("SubscriptionPlatform", platformId));
        // Auto-remove all socials on that platform
        socials.findBySubscriptionIdAndStatus(subscriptionId, SocialAccount.Status.ACTIVE).stream()
                .filter(a -> a.getPlatformId().equals(platformId))
                .forEach(a -> { a.setStatus(SocialAccount.Status.REMOVED); a.setRemovedAt(Instant.now()); socials.save(a); });
        subPlatforms.delete(sp);
    }

    @Transactional
    public SocialAccount addSocialAccount(String userId, String subscriptionId, Short platformId,
                                          String username, String profileUrl) {
        Subscription s = ownedSub(userId, subscriptionId);
        if (s.getStatus() != Subscription.Status.ACTIVE)
            throw ApiException.conflict("Subscription is not active");
        if (subPlatforms.findBySubscriptionIdAndPlatformId(subscriptionId, platformId).isEmpty())
            throw ApiException.conflict("Platform not added to subscription");

        long count = socials.countBySubscriptionIdAndPlatformIdAndStatus(subscriptionId, platformId, SocialAccount.Status.ACTIVE);
        if (count >= s.getMaxAccountsSnapshot())
            throw new ApiException(ErrorCode.SUBSCRIPTION_LIMIT_EXCEEDED, "Account limit reached for this platform");

        SocialAccount a = new SocialAccount();
        a.setId(IdGenerator.uuid());
        a.setSubscriptionId(subscriptionId);
        a.setPlatformId(platformId);
        a.setUsername(username);
        a.setProfileUrl(profileUrl);
        return socials.save(a);
    }

    @Transactional
    public void removeSocialAccount(String userId, String subscriptionId, String accountId) {
        ownedSub(userId, subscriptionId);
        SocialAccount a = socials.findById(accountId).orElseThrow(() -> ApiException.notFound("SocialAccount", accountId));
        if (!a.getSubscriptionId().equals(subscriptionId))
            throw ApiException.forbidden("Not in this subscription");
        a.setStatus(SocialAccount.Status.REMOVED);
        a.setRemovedAt(Instant.now());
        socials.save(a);
    }

    @Transactional(readOnly = true)
    public List<Subscription> listMine(String userId) {
        return subs.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Transactional(readOnly = true)
    public Subscription get(String userId, String subscriptionId) {
        return ownedSub(userId, subscriptionId);
    }

    @Transactional(readOnly = true)
    public List<Short> listPlatformIds(String subscriptionId) {
        return subPlatforms.findBySubscriptionId(subscriptionId).stream().map(SubscriptionPlatform::getPlatformId).toList();
    }

    @Transactional(readOnly = true)
    public List<SocialAccount> listSocials(String userId, String subscriptionId) {
        ownedSub(userId, subscriptionId);
        return socials.findBySubscriptionIdAndStatus(subscriptionId, SocialAccount.Status.ACTIVE);
    }

    private Subscription ownedSub(String userId, String subscriptionId) {
        Subscription s = subs.findById(subscriptionId).orElseThrow(() -> ApiException.notFound("Subscription", subscriptionId));
        if (!s.getUserId().equals(userId)) throw ApiException.forbidden("Not your subscription");
        return s;
    }

    public record CheckoutResult(Subscription subscription, Invoice invoice) {}
}
