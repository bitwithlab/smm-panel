package com.bitwithlab.smm.support.ticket;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "tickets")
public class Ticket {

    public enum Category { PAYMENT, SERVICE, ACCOUNT, REFUND, BUG, REPORT, OTHER }
    public enum Priority { LOW, NORMAL, HIGH, URGENT }
    public enum Status { OPEN, IN_PROGRESS, WAITING_USER, RESOLVED, CLOSED }

    @Id @Column(length = 36) private String id;
    @Column(name = "ticket_number", nullable = false, length = 20, unique = true) private String ticketNumber;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(nullable = false, length = 255) private String subject;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Category category;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 8) private Priority priority = Priority.NORMAL;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.OPEN;
    @Column(name = "assigned_to", length = 36) private String assignedTo;
    @Column(name = "related_order_id", length = 36) private String relatedOrderId;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;
    @Column(name = "closed_at") private Instant closedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); updatedAt = Instant.now(); }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getTicketNumber() { return ticketNumber; } public void setTicketNumber(String s) { this.ticketNumber = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public String getSubject() { return subject; } public void setSubject(String s) { this.subject = s; }
    public Category getCategory() { return category; } public void setCategory(Category c) { this.category = c; }
    public Priority getPriority() { return priority; } public void setPriority(Priority p) { this.priority = p; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public String getAssignedTo() { return assignedTo; } public void setAssignedTo(String s) { this.assignedTo = s; }
    public String getRelatedOrderId() { return relatedOrderId; } public void setRelatedOrderId(String s) { this.relatedOrderId = s; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public Instant getClosedAt() { return closedAt; } public void setClosedAt(Instant t) { this.closedAt = t; }
}
