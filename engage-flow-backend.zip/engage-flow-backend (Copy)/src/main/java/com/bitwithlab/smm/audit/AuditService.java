package com.bitwithlab.smm.audit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditLogRepository repo;
    private final ObjectMapper mapper;

    public AuditService(AuditLogRepository repo, ObjectMapper mapper) {
        this.repo = repo; this.mapper = mapper;
    }

    @Async
    @Transactional
    public void record(String actorUserId, String action, String entityType, String entityId,
                       String ip, String userAgent, Object metadata) {
        try {
            AuditLog a = new AuditLog();
            a.setActorUserId(actorUserId);
            a.setAction(action);
            a.setEntityType(entityType);
            a.setEntityId(entityId);
            a.setIp(ip);
            a.setUserAgent(userAgent);
            if (metadata != null) a.setMetadata(toJson(metadata));
            repo.save(a);
        } catch (Exception ex) {
            log.warn("Audit record failed: {}", ex.getMessage());
        }
    }

    private String toJson(Object o) {
        if (o instanceof String s) return s;
        try { return mapper.writeValueAsString(o); }
        catch (JsonProcessingException e) { return "{}"; }
    }
}
