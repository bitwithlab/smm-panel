package com.bitwithlab.smm.identity.otp;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "otp_codes")
public class OtpCode {

    public enum Purpose { SIGNUP_EMAIL, LOGIN_2FA, PASSWORD_RESET, PHONE_VERIFY, EMAIL_CHANGE }
    public enum Channel { EMAIL, SMS }

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(name = "code_hash", nullable = false, length = 255) private String codeHash;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 32) private Purpose purpose;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 8) private Channel channel;
    @Column(nullable = false, length = 190) private String destination;
    @Column(nullable = false) private int attempts;
    @Column(name = "expires_at", nullable = false) private Instant expiresAt;
    @Column(name = "consumed_at") private Instant consumedAt;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String userId) { this.userId = userId; }
    public String getCodeHash() { return codeHash; } public void setCodeHash(String codeHash) { this.codeHash = codeHash; }
    public Purpose getPurpose() { return purpose; } public void setPurpose(Purpose purpose) { this.purpose = purpose; }
    public Channel getChannel() { return channel; } public void setChannel(Channel channel) { this.channel = channel; }
    public String getDestination() { return destination; } public void setDestination(String destination) { this.destination = destination; }
    public int getAttempts() { return attempts; } public void setAttempts(int attempts) { this.attempts = attempts; }
    public Instant getExpiresAt() { return expiresAt; } public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }
    public Instant getConsumedAt() { return consumedAt; } public void setConsumedAt(Instant consumedAt) { this.consumedAt = consumedAt; }
    public Instant getCreatedAt() { return createdAt; }

    public boolean isExpired() { return expiresAt.isBefore(Instant.now()); }
    public boolean isConsumed() { return consumedAt != null; }
}
