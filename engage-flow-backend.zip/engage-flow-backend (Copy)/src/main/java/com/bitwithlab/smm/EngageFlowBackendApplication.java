package com.bitwithlab.smm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngageFlowBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(EngageFlowBackendApplication.class, args);
    }

}
