package com.bitwithlab.smm.common.exception;

import org.springframework.http.HttpStatus;

public enum ErrorCode {
    // Generic
    BAD_REQUEST(HttpStatus.BAD_REQUEST),
    VALIDATION_ERROR(HttpStatus.BAD_REQUEST),
    UNAUTHORIZED(HttpStatus.UNAUTHORIZED),
    FORBIDDEN(HttpStatus.FORBIDDEN),
    NOT_FOUND(HttpStatus.NOT_FOUND),
    CONFLICT(HttpStatus.CONFLICT),
    LOCKED(HttpStatus.LOCKED),
    TOO_MANY_REQUESTS(HttpStatus.TOO_MANY_REQUESTS),
    INTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR),

    // Auth
    INVALID_CREDENTIALS(HttpStatus.UNAUTHORIZED),
    ACCOUNT_LOCKED(HttpStatus.LOCKED),
    ACCOUNT_NOT_VERIFIED(HttpStatus.FORBIDDEN),
    ACCOUNT_SUSPENDED(HttpStatus.FORBIDDEN),
    INVALID_TOKEN(HttpStatus.UNAUTHORIZED),
    TOKEN_EXPIRED(HttpStatus.UNAUTHORIZED),
    OTP_REQUIRED(HttpStatus.UNAUTHORIZED),
    OTP_INVALID(HttpStatus.BAD_REQUEST),
    OTP_EXPIRED(HttpStatus.BAD_REQUEST),
    OTP_MAX_ATTEMPTS(HttpStatus.TOO_MANY_REQUESTS),

    // Domain
    EMAIL_ALREADY_EXISTS(HttpStatus.CONFLICT),
    PHONE_ALREADY_EXISTS(HttpStatus.CONFLICT),
    INSUFFICIENT_BALANCE(HttpStatus.PAYMENT_REQUIRED),
    SUBSCRIPTION_LIMIT_EXCEEDED(HttpStatus.CONFLICT),
    PACKAGE_INACTIVE(HttpStatus.CONFLICT),
    SERVICE_INACTIVE(HttpStatus.CONFLICT),
    PROVIDER_ERROR(HttpStatus.BAD_GATEWAY),
    PAYMENT_FAILED(HttpStatus.BAD_REQUEST),
    COUPON_INVALID(HttpStatus.BAD_REQUEST),
    INVOICE_ALREADY_PAID(HttpStatus.CONFLICT);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) { this.status = status; }
    public HttpStatus status() { return status; }
}
