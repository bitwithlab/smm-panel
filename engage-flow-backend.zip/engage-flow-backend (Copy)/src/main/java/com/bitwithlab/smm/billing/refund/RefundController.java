package com.bitwithlab.smm.billing.refund;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import com.bitwithlab.smm.wallet.WalletService;
import com.bitwithlab.smm.wallet.WalletTransaction;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.data.domain.PageRequest;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;

@RestController
@Tag(name = "Refunds")
public class RefundController {

    private final RefundRepository repo;
    private final WalletService wallet;
    private final NotificationService notifier;

    public RefundController(RefundRepository repo, WalletService wallet, NotificationService notifier) {
        this.repo = repo; this.wallet = wallet; this.notifier = notifier;
    }

    public record RefundRequest(String paymentId, String orderId,
                                @NotNull @Positive BigDecimal amount,
                                Refund.Destination destination, String reason) {}
    public record RefundDto(String id, String paymentId, String orderId, BigDecimal amount,
                            String destination, String reason, String status, Instant createdAt) {
        public static RefundDto of(Refund r) {
            return new RefundDto(r.getId(), r.getPaymentId(), r.getOrderId(), r.getAmount(),
                    r.getDestination().name(), r.getReason(), r.getStatus().name(), r.getCreatedAt());
        }
    }
    public record DecisionRequest(boolean approve, String adminNote) {}

    // ----- User -----
    @PostMapping("/api/v1/me/refunds")
    @Operation(summary = "Request a refund (admin will review)")
    public ApiResponse<RefundDto> request(@CurrentUser UserPrincipal me, @Valid @RequestBody RefundRequest req) {
        Refund r = new Refund();
        r.setId(IdGenerator.uuid());
        r.setUserId(me.id());
        r.setPaymentId(req.paymentId());
        r.setOrderId(req.orderId());
        r.setAmount(req.amount());
        r.setDestination(req.destination() == null ? Refund.Destination.WALLET : req.destination());
        r.setReason(req.reason());
        return ApiResponse.ok("Refund requested", RefundDto.of(repo.save(r)));
    }

    @GetMapping("/api/v1/me/refunds")
    public ApiResponse<PageResponse<RefundDto>> mine(@CurrentUser UserPrincipal me,
                                                     @RequestParam(defaultValue = "0") int page,
                                                     @RequestParam(defaultValue = "20") int size) {
        var p = repo.findByUserIdOrderByCreatedAtDesc(me.id(), PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, RefundDto::of));
    }

    // ----- Admin -----
    @GetMapping("/api/v1/admin/refunds")
    public ApiResponse<PageResponse<RefundDto>> adminList(@RequestParam(required = false) Refund.Status status,
                                                          @RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "20") int size) {
        var pg = PageRequest.of(page, Math.min(size, 100));
        var p = (status == null) ? repo.findAll(pg) : repo.findByStatusOrderByCreatedAtDesc(status, pg);
        return ApiResponse.ok(PageResponse.of(p, RefundDto::of));
    }

    @PostMapping("/api/v1/admin/refunds/{id}/decision")
    @Transactional
    @Operation(summary = "Approve (executes refund) or reject")
    public ApiResponse<RefundDto> decide(@CurrentUser UserPrincipal me,
                                         @PathVariable String id,
                                         @RequestBody DecisionRequest req) {
        Refund r = repo.findById(id).orElseThrow(() -> ApiException.notFound("Refund", id));
        if (r.getStatus() != Refund.Status.REQUESTED) throw ApiException.conflict("Already processed");

        r.setProcessedBy(me.id());
        r.setProcessedAt(Instant.now());

        if (!req.approve()) {
            r.setStatus(Refund.Status.REJECTED);
            repo.save(r);
            notifier.push(r.getUserId(), Notification.Type.PAYMENT, "Refund rejected", req.adminNote());
            return ApiResponse.ok("Rejected", RefundDto.of(r));
        }

        if (r.getDestination() == Refund.Destination.WALLET) {
            wallet.credit(r.getUserId(), r.getAmount(), WalletTransaction.Reason.REFUND, "REFUND", r.getId(), "Approved refund");
            r.setStatus(Refund.Status.COMPLETED);
        } else {
            // TODO: gateway refund call
            r.setStatus(Refund.Status.APPROVED);
        }
        repo.save(r);
        notifier.push(r.getUserId(), Notification.Type.PAYMENT, "Refund approved",
                "Refund of %s has been processed.".formatted(r.getAmount()));
        return ApiResponse.ok("Decision saved", RefundDto.of(r));
    }
}
