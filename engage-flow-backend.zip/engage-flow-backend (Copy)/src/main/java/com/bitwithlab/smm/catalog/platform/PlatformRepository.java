package com.bitwithlab.smm.catalog.platform;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PlatformRepository extends JpaRepository<Platform, Short> {
    List<Platform> findByActiveTrueOrderByIdAsc();
    Optional<Platform> findByCode(String code);
}
