package com.bitwithlab.smm.support.ticket;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TicketRepository extends JpaRepository<Ticket, String> {

    Page<Ticket> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);

    @Query("""
        select t from Ticket t
        where (:userId is null or t.userId = :userId)
          and (:status is null or t.status = :status)
          and (:assignedTo is null or t.assignedTo = :assignedTo)
        """)
    Page<Ticket> search(@Param("userId") String userId,
                        @Param("status") Ticket.Status status,
                        @Param("assignedTo") String assignedTo,
                        Pageable pageable);

    @Query(value = "select count(*) from tickets", nativeQuery = true)
    long countAll();
}
