package com.bitwithlab.smm.config;

import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.identity.user.User;
import com.bitwithlab.smm.identity.user.UserRepository;
import com.bitwithlab.smm.wallet.Wallet;
import com.bitwithlab.smm.wallet.WalletRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository users;
    private final WalletRepository wallets;
    private final PasswordEncoder encoder;
    private final String adminEmail;
    private final String adminPassword;
    private final String adminPhone;

    public DataInitializer(UserRepository users, WalletRepository wallets, PasswordEncoder encoder,
                           @Value("${app.admin.email:admin@engageflow.local}") String adminEmail,
                           @Value("${app.admin.password:ChangeMe@123}") String adminPassword,
                           @Value("${app.admin.phone:+8801700000000}") String adminPhone) {
        this.users = users; this.wallets = wallets; this.encoder = encoder;
        this.adminEmail = adminEmail; this.adminPassword = adminPassword; this.adminPhone = adminPhone;
    }

    @Override
    public void run(String... args) {
        if (users.existsByEmail(adminEmail)) return;
        User u = new User();
        u.setId(IdGenerator.uuid());
        u.setName("Administrator");
        u.setEmail(adminEmail);
        u.setPhone(adminPhone);
        u.setPasswordHash(encoder.encode(adminPassword));
        u.setRole(User.Role.ADMIN);
        u.setStatus(User.Status.ACTIVE);
        u.setEmailVerifiedAt(Instant.now());
        u.setTermsAcceptedAt(Instant.now());
        users.save(u);

        Wallet w = new Wallet();
        w.setId(IdGenerator.uuid());
        w.setUserId(u.getId());
        wallets.save(w);

        log.warn("Bootstrap admin created: {} (CHANGE THE DEFAULT PASSWORD IMMEDIATELY)", adminEmail);
    }
}
