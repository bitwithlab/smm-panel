package com.bitwithlab.smm.subscription;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "subscriptions")
public class Subscription {

    public enum BillingCycle { MONTHLY, YEARLY }
    public enum Status { PENDING_PAYMENT, ACTIVE, EXPIRED, CANCELLED, SUSPENDED }

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(name = "package_id", nullable = false) private Short packageId;
    @Enumerated(EnumType.STRING) @Column(name = "billing_cycle", nullable = false, length = 8) private BillingCycle billingCycle;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal price;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Column(name = "max_platforms_snapshot", nullable = false) private Short maxPlatformsSnapshot;
    @Column(name = "max_accounts_snapshot", nullable = false) private Short maxAccountsSnapshot;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.PENDING_PAYMENT;
    @Column(name = "starts_at") private Instant startsAt;
    @Column(name = "ends_at") private Instant endsAt;
    @Column(name = "cancelled_at") private Instant cancelledAt;
    @Column(name = "auto_renew", nullable = false) private boolean autoRenew;
    @Column(name = "coupon_id", length = 36) private String couponId;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); updatedAt = Instant.now(); }
    @PreUpdate void onUpdate() { updatedAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Short getPackageId() { return packageId; } public void setPackageId(Short s) { this.packageId = s; }
    public BillingCycle getBillingCycle() { return billingCycle; } public void setBillingCycle(BillingCycle b) { this.billingCycle = b; }
    public BigDecimal getPrice() { return price; } public void setPrice(BigDecimal b) { this.price = b; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public Short getMaxPlatformsSnapshot() { return maxPlatformsSnapshot; } public void setMaxPlatformsSnapshot(Short n) { this.maxPlatformsSnapshot = n; }
    public Short getMaxAccountsSnapshot() { return maxAccountsSnapshot; } public void setMaxAccountsSnapshot(Short n) { this.maxAccountsSnapshot = n; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public Instant getStartsAt() { return startsAt; } public void setStartsAt(Instant t) { this.startsAt = t; }
    public Instant getEndsAt() { return endsAt; } public void setEndsAt(Instant t) { this.endsAt = t; }
    public Instant getCancelledAt() { return cancelledAt; } public void setCancelledAt(Instant t) { this.cancelledAt = t; }
    public boolean isAutoRenew() { return autoRenew; } public void setAutoRenew(boolean b) { this.autoRenew = b; }
    public String getCouponId() { return couponId; } public void setCouponId(String s) { this.couponId = s; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
