package com.bitwithlab.smm.common.util;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.UUID;

public final class IdGenerator {
    private static final SecureRandom RNG = new SecureRandom();
    private IdGenerator() {}

    public static String uuid() { return UUID.randomUUID().toString(); }

    public static String invoiceNumber(long sequence) {
        return "INV-%d-%06d".formatted(LocalDate.now().getYear(), sequence);
    }

    public static String orderNumber(long sequence) {
        return "ORD-%d-%06d".formatted(LocalDate.now().getYear(), sequence);
    }

    public static String ticketNumber(long sequence) {
        return "TKT-%06d".formatted(sequence);
    }

    public static String numericOtp(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) sb.append(RNG.nextInt(10));
        return sb.toString();
    }

    public static String randomToken(int bytes) {
        byte[] b = new byte[bytes];
        RNG.nextBytes(b);
        return java.util.HexFormat.of().formatHex(b);
    }
}
