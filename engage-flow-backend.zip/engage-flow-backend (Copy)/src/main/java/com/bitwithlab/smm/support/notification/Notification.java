package com.bitwithlab.smm.support.notification;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "notifications")
public class Notification {

    public enum Type { ORDER_UPDATE, PAYMENT, SECURITY, SUBSCRIPTION_EXPIRY, TICKET_REPLY, SYSTEM }

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 32) private Type type;
    @Column(nullable = false, length = 255) private String title;
    @Column(columnDefinition = "TEXT") private String body;
    @Column(columnDefinition = "json") private String data;
    @Column(name = "read_at") private Instant readAt;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public Type getType() { return type; } public void setType(Type t) { this.type = t; }
    public String getTitle() { return title; } public void setTitle(String t) { this.title = t; }
    public String getBody() { return body; } public void setBody(String b) { this.body = b; }
    public String getData() { return data; } public void setData(String d) { this.data = d; }
    public Instant getReadAt() { return readAt; } public void setReadAt(Instant t) { this.readAt = t; }
    public Instant getCreatedAt() { return createdAt; }
}
