package com.bitwithlab.smm.audit;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "audit_logs")
public class AuditLog {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "actor_user_id", length = 36) private String actorUserId;
    @Column(nullable = false, length = 64) private String action;
    @Column(name = "entity_type", length = 64) private String entityType;
    @Column(name = "entity_id", length = 64) private String entityId;
    @Column(length = 45) private String ip;
    @Column(name = "user_agent", length = 500) private String userAgent;
    @Column(columnDefinition = "json") private String metadata;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public Long getId() { return id; }
    public String getActorUserId() { return actorUserId; } public void setActorUserId(String s) { this.actorUserId = s; }
    public String getAction() { return action; } public void setAction(String s) { this.action = s; }
    public String getEntityType() { return entityType; } public void setEntityType(String s) { this.entityType = s; }
    public String getEntityId() { return entityId; } public void setEntityId(String s) { this.entityId = s; }
    public String getIp() { return ip; } public void setIp(String s) { this.ip = s; }
    public String getUserAgent() { return userAgent; } public void setUserAgent(String s) { this.userAgent = s; }
    public String getMetadata() { return metadata; } public void setMetadata(String s) { this.metadata = s; }
    public Instant getCreatedAt() { return createdAt; }
}
