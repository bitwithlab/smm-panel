package com.bitwithlab.smm.identity.auth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record PasswordResetRequest(
        @NotBlank @Email String email
) {
    public record Confirm(
            @NotBlank @Email String email,
            @NotBlank @Size(min = 4, max = 8) String code,
            @NotBlank @Size(min = 8, max = 100) String newPassword
    ) {}
}
