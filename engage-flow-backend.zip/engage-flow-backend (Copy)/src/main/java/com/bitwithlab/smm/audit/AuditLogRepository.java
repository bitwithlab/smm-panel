package com.bitwithlab.smm.audit;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    @Query("""
        select a from AuditLog a
        where (:actorUserId is null or a.actorUserId = :actorUserId)
          and (:action is null or a.action = :action)
          and (:entityType is null or a.entityType = :entityType)
          and (:entityId is null or a.entityId = :entityId)
        """)
    Page<AuditLog> search(@Param("actorUserId") String actorUserId,
                          @Param("action") String action,
                          @Param("entityType") String entityType,
                          @Param("entityId") String entityId,
                          Pageable pageable);
}
