package com.bitwithlab.smm.catalog.pkg.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public record PackageWriteRequest(
        @Size(max = 64) String name,
        String description,
        @Min(1) @Max(50) Short maxPlatforms,
        @Min(1) @Max(50) Short maxAccountsPerPlatform,
        @DecimalMin("0.0") BigDecimal priceMonthly,
        @DecimalMin("0.0") BigDecimal priceYearly,
        @Size(min = 3, max = 3) String currency,
        Boolean active,
        Short sortOrder
) {}
