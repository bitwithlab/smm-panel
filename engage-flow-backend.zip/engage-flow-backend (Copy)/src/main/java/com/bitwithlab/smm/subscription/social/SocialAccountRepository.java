package com.bitwithlab.smm.subscription.social;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SocialAccountRepository extends JpaRepository<SocialAccount, String> {
    List<SocialAccount> findBySubscriptionIdAndStatus(String subscriptionId, SocialAccount.Status status);
    long countBySubscriptionIdAndPlatformIdAndStatus(String subscriptionId, Short platformId, SocialAccount.Status status);
}
