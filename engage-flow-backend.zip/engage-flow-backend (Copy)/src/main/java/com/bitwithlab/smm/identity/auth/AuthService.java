package com.bitwithlab.smm.identity.auth;

import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.ClientInfo;
import com.bitwithlab.smm.common.util.HashUtil;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.identity.attempt.LoginAttempt;
import com.bitwithlab.smm.identity.attempt.LoginAttemptRepository;
import com.bitwithlab.smm.identity.auth.dto.*;
import com.bitwithlab.smm.identity.device.TrustedDevice;
import com.bitwithlab.smm.identity.device.TrustedDeviceRepository;
import com.bitwithlab.smm.identity.otp.OtpCode;
import com.bitwithlab.smm.identity.otp.OtpService;
import com.bitwithlab.smm.identity.session.LoginSession;
import com.bitwithlab.smm.identity.session.LoginSessionRepository;
import com.bitwithlab.smm.identity.user.User;
import com.bitwithlab.smm.identity.user.UserRepository;
import com.bitwithlab.smm.security.jwt.JwtProperties;
import com.bitwithlab.smm.security.jwt.JwtService;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import com.bitwithlab.smm.wallet.Wallet;
import com.bitwithlab.smm.wallet.WalletRepository;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;

@Service
public class AuthService {

    private final UserRepository users;
    private final WalletRepository wallets;
    private final TrustedDeviceRepository devices;
    private final LoginSessionRepository sessions;
    private final LoginAttemptRepository attempts;
    private final OtpService otpService;
    private final NotificationService notifier;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final JwtProperties jwtProps;
    private final int maxFailed;
    private final Duration lockout;

    public AuthService(UserRepository users, WalletRepository wallets,
                       TrustedDeviceRepository devices, LoginSessionRepository sessions,
                       LoginAttemptRepository attempts, OtpService otpService,
                       NotificationService notifier, PasswordEncoder encoder,
                       JwtService jwt, JwtProperties jwtProps,
                       @Value("${app.security.max-failed-logins}") int maxFailed,
                       @Value("${app.security.lockout-duration}") Duration lockout) {
        this.users = users; this.wallets = wallets; this.devices = devices;
        this.sessions = sessions; this.attempts = attempts; this.otpService = otpService;
        this.notifier = notifier; this.encoder = encoder; this.jwt = jwt; this.jwtProps = jwtProps;
        this.maxFailed = maxFailed; this.lockout = lockout;
    }

    @Transactional
    public void register(RegisterRequest req) {
        if (!req.acceptTerms()) throw ApiException.badRequest("Terms must be accepted");
        if (users.existsByEmail(req.email())) throw new ApiException(ErrorCode.EMAIL_ALREADY_EXISTS, "Email already in use");
        if (users.existsByPhone(req.phone())) throw new ApiException(ErrorCode.PHONE_ALREADY_EXISTS, "Phone already in use");

        User u = new User();
        u.setId(IdGenerator.uuid());
        u.setName(req.name().trim());
        u.setEmail(req.email().toLowerCase().trim());
        u.setPhone(req.phone().trim());
        u.setPasswordHash(encoder.encode(req.password()));
        u.setRole(User.Role.USER);
        u.setStatus(User.Status.PENDING);
        u.setTermsAcceptedAt(Instant.now());
        users.save(u);

        Wallet w = new Wallet();
        w.setId(IdGenerator.uuid());
        w.setUserId(u.getId());
        wallets.save(w);

        otpService.issue(u.getId(), u.getEmail(), OtpCode.Purpose.SIGNUP_EMAIL);
    }

    @Transactional
    public void verifySignup(VerifyOtpRequest req) {
        User u = users.findByEmail(req.email().toLowerCase()).orElseThrow(() -> ApiException.notFound("User", req.email()));
        if (u.getStatus() == User.Status.ACTIVE) return;
        otpService.verify(u.getId(), OtpCode.Purpose.SIGNUP_EMAIL, req.code());
        u.setStatus(User.Status.ACTIVE);
        u.setEmailVerifiedAt(Instant.now());
        users.save(u);
        notifier.push(u.getId(), Notification.Type.SECURITY, "Account verified", "Your account is now active.");
    }

    @Transactional
    public AuthResponse login(LoginRequest req, ClientInfo info) {
        User u = users.findByEmail(req.emailOrPhone().toLowerCase())
                .or(() -> users.findByPhone(req.emailOrPhone()))
                .orElse(null);
        if (u == null) {
            recordAttempt(req.emailOrPhone(), null, info, LoginAttempt.Status.USER_NOT_FOUND);
            throw new ApiException(ErrorCode.INVALID_CREDENTIALS, "Invalid email/phone or password");
        }

        if (u.getDeletedAt() != null || u.getStatus() == User.Status.BANNED || u.getStatus() == User.Status.SUSPENDED) {
            recordAttempt(req.emailOrPhone(), u.getId(), info, LoginAttempt.Status.LOCKED);
            throw new ApiException(ErrorCode.ACCOUNT_SUSPENDED, "Account is not accessible");
        }
        if (u.isLocked()) {
            recordAttempt(req.emailOrPhone(), u.getId(), info, LoginAttempt.Status.LOCKED);
            throw new ApiException(ErrorCode.ACCOUNT_LOCKED, "Account temporarily locked. Try later.");
        }

        if (!encoder.matches(req.password(), u.getPasswordHash())) {
            int newCount = u.getFailedLoginCount() + 1;
            u.setFailedLoginCount(newCount);
            if (newCount >= maxFailed) u.setLockedUntil(Instant.now().plus(lockout));
            users.save(u);
            recordAttempt(req.emailOrPhone(), u.getId(), info, LoginAttempt.Status.BAD_PASSWORD);
            throw new ApiException(ErrorCode.INVALID_CREDENTIALS, "Invalid email/phone or password");
        }

        if (u.getStatus() == User.Status.PENDING) {
            otpService.issue(u.getId(), u.getEmail(), OtpCode.Purpose.SIGNUP_EMAIL);
            throw new ApiException(ErrorCode.ACCOUNT_NOT_VERIFIED, "Please verify your email. A new OTP has been sent.");
        }

        // Device check
        String fp = info.deviceFingerprint();
        TrustedDevice device = (fp != null) ? devices.findByUserIdAndDeviceFingerprint(u.getId(), fp).orElse(null) : null;

        if (device == null || !device.isTrusted()) {
            otpService.issue(u.getId(), u.getEmail(), OtpCode.Purpose.LOGIN_2FA);
            recordAttempt(req.emailOrPhone(), u.getId(), info, LoginAttempt.Status.OTP_REQUIRED);
            return AuthResponse.otpRequired(maskEmail(u.getEmail()));
        }

        device.setLastSeenAt(Instant.now());
        device.setLastIp(info.ip());
        devices.save(device);

        return issueTokens(u, device, info);
    }

    @Transactional
    public AuthResponse verifyLoginOtp(VerifyOtpRequest req, String deviceName, ClientInfo info) {
        User u = users.findByEmail(req.email().toLowerCase()).orElseThrow(() -> ApiException.notFound("User", req.email()));
        otpService.verify(u.getId(), OtpCode.Purpose.LOGIN_2FA, req.code());

        String fp = info.deviceFingerprint() == null ? HashUtil.sha256(info.userAgent() + "|" + info.ip()) : info.deviceFingerprint();
        TrustedDevice device = devices.findByUserIdAndDeviceFingerprint(u.getId(), fp).orElseGet(TrustedDevice::new);
        if (device.getId() == null) {
            device.setId(IdGenerator.uuid());
            device.setUserId(u.getId());
            device.setDeviceFingerprint(fp);
        }
        device.setDeviceName(deviceName);
        device.setLastIp(info.ip());
        device.setLastSeenAt(Instant.now());
        device.setTrustedAt(Instant.now());
        device.setRevokedAt(null);
        devices.save(device);

        notifier.push(u.getId(), Notification.Type.SECURITY,
                "New device verified",
                "A new device was authorized to access your account.");

        return issueTokens(u, device, info);
    }

    @Transactional
    public AuthResponse refresh(String refreshToken, ClientInfo info) {
        Claims c;
        try { c = jwt.parse(refreshToken); }
        catch (Exception e) { throw new ApiException(ErrorCode.INVALID_TOKEN, "Invalid refresh token"); }
        if (!JwtService.TYPE_REFRESH.equals(c.get(JwtService.CLAIM_TYPE, String.class))) {
            throw new ApiException(ErrorCode.INVALID_TOKEN, "Not a refresh token");
        }
        String hash = HashUtil.sha256(refreshToken);
        LoginSession old = sessions.findByRefreshTokenHash(hash)
                .orElseThrow(() -> new ApiException(ErrorCode.INVALID_TOKEN, "Refresh token not recognized"));
        if (!old.isActive()) {
            sessions.revokeAllForUser(old.getUserId(), Instant.now());
            throw new ApiException(ErrorCode.INVALID_TOKEN, "Refresh token reused or expired — all sessions revoked");
        }
        User u = users.findById(old.getUserId()).orElseThrow(() -> ApiException.notFound("User", old.getUserId()));

        // rotate
        old.setRevokedAt(Instant.now());
        TrustedDevice device = devices.findById(old.getDeviceId()).orElseThrow();
        AuthResponse pair = issueTokens(u, device, info);
        old.setReplacedBy(pair.tokens() == null ? null : extractSessionIdFromAccess(pair.tokens().accessToken()));
        sessions.save(old);
        return pair;
    }

    @Transactional
    public void logout(String userId, String sessionId) {
        sessions.findById(sessionId).ifPresent(s -> {
            if (s.getUserId().equals(userId) && s.getRevokedAt() == null) {
                s.setRevokedAt(Instant.now());
                sessions.save(s);
            }
        });
    }

    @Transactional
    public void requestPasswordReset(String email) {
        users.findByEmail(email.toLowerCase()).ifPresent(u ->
                otpService.issue(u.getId(), u.getEmail(), OtpCode.Purpose.PASSWORD_RESET));
        // Do not reveal whether email exists
    }

    @Transactional
    public void confirmPasswordReset(PasswordResetRequest.Confirm req) {
        User u = users.findByEmail(req.email().toLowerCase()).orElseThrow(() -> ApiException.notFound("User", req.email()));
        otpService.verify(u.getId(), OtpCode.Purpose.PASSWORD_RESET, req.code());
        u.setPasswordHash(encoder.encode(req.newPassword()));
        u.setFailedLoginCount(0);
        u.setLockedUntil(null);
        users.save(u);
        sessions.revokeAllForUser(u.getId(), Instant.now());
        notifier.push(u.getId(), Notification.Type.SECURITY, "Password changed",
                "Your password was changed. All sessions have been signed out.");
    }

    // -------------- helpers --------------

    private AuthResponse issueTokens(User u, TrustedDevice device, ClientInfo info) {
        String sessionId = IdGenerator.uuid();
        JwtService.TokenPair pair = jwt.issuePair(u.getId(), u.getRole().name(), device.getId(), sessionId);

        LoginSession s = new LoginSession();
        s.setId(sessionId);
        s.setUserId(u.getId());
        s.setDeviceId(device.getId());
        s.setRefreshTokenHash(HashUtil.sha256(pair.refreshToken()));
        s.setIp(info.ip());
        s.setUserAgent(info.userAgent());
        s.setExpiresAt(Instant.now().plus(jwtProps.refreshTokenTtl()));
        sessions.save(s);

        users.markLoginSuccess(u.getId(), Instant.now());
        recordAttempt(u.getEmail(), u.getId(), info, LoginAttempt.Status.SUCCESS);

        return AuthResponse.withTokens(
                AuthResponse.TokenPair.of(pair.accessToken(), pair.refreshToken(),
                        pair.accessTtlSeconds(), pair.refreshTtlSeconds()),
                UserDto.of(u));
    }

    private void recordAttempt(String emailOrPhone, String userId, ClientInfo info, LoginAttempt.Status status) {
        LoginAttempt a = new LoginAttempt();
        a.setEmailOrPhone(emailOrPhone);
        a.setUserId(userId);
        a.setIp(info.ip());
        a.setUserAgent(info.userAgent());
        a.setStatus(status);
        attempts.save(a);
    }

    private String extractSessionIdFromAccess(String access) {
        try { return jwt.parse(access).get(JwtService.CLAIM_SESSION, String.class); }
        catch (Exception e) { return null; }
    }

    private static String maskEmail(String email) {
        int at = email.indexOf('@');
        if (at < 2) return "***" + email.substring(at);
        return email.charAt(0) + "***" + email.substring(at - 1);
    }
}
