package com.bitwithlab.smm.support.notification;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/me/notifications")
@Tag(name = "Notifications")
public class NotificationController {

    private final NotificationRepository repo;

    public NotificationController(NotificationRepository repo) { this.repo = repo; }

    public record NotificationDto(String id, String type, String title, String body, Instant readAt, Instant createdAt) {
        public static NotificationDto of(Notification n) {
            return new NotificationDto(n.getId(), n.getType().name(), n.getTitle(), n.getBody(), n.getReadAt(), n.getCreatedAt());
        }
    }

    @GetMapping
    @Operation(summary = "List my notifications")
    public ApiResponse<PageResponse<NotificationDto>> list(@CurrentUser UserPrincipal me,
                                                           @RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "20") int size) {
        Pageable pg = PageRequest.of(page, Math.min(size, 100));
        Page<Notification> p = repo.findByUserIdOrderByCreatedAtDesc(me.id(), pg);
        return ApiResponse.ok(PageResponse.of(p, NotificationDto::of));
    }

    @GetMapping("/unread-count")
    @Operation(summary = "Count of unread notifications")
    public ApiResponse<Map<String, Long>> unread(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(Map.of("count", repo.countByUserIdAndReadAtIsNull(me.id())));
    }

    @PatchMapping("/{id}/read")
    @Operation(summary = "Mark one as read")
    public ApiResponse<Void> markRead(@CurrentUser UserPrincipal me, @PathVariable String id) {
        repo.findById(id).filter(n -> n.getUserId().equals(me.id()) && n.getReadAt() == null)
                .ifPresent(n -> { n.setReadAt(Instant.now()); repo.save(n); });
        return ApiResponse.ok("Marked read");
    }

    @PostMapping("/mark-all-read")
    @Operation(summary = "Mark all as read")
    public ApiResponse<Integer> markAllRead(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok("Done", repo.markAllRead(me.id(), Instant.now()));
    }
}
