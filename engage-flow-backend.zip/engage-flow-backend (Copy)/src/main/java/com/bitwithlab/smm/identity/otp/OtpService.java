package com.bitwithlab.smm.identity.otp;

import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.common.util.HashUtil;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.support.messagelog.MailService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;

@Service
public class OtpService {

    private final OtpCodeRepository repo;
    private final MailService mail;
    private final int length;
    private final Duration ttl;
    private final int maxAttempts;
    private final String hmacSecret;

    public OtpService(OtpCodeRepository repo,
                      MailService mail,
                      @Value("${app.otp.length}") int length,
                      @Value("${app.otp.ttl}") Duration ttl,
                      @Value("${app.otp.max-attempts}") int maxAttempts,
                      @Value("${app.otp.hmac-secret}") String hmacSecret) {
        this.repo = repo;
        this.mail = mail;
        this.length = length;
        this.ttl = ttl;
        this.maxAttempts = maxAttempts;
        this.hmacSecret = hmacSecret;
    }

    @Transactional
    public void issue(String userId, String email, OtpCode.Purpose purpose) {
        repo.invalidateAll(userId, purpose);
        String code = IdGenerator.numericOtp(length);

        OtpCode o = new OtpCode();
        o.setId(IdGenerator.uuid());
        o.setUserId(userId);
        o.setCodeHash(HashUtil.hmacSha256(hmacSecret, code));
        o.setPurpose(purpose);
        o.setChannel(OtpCode.Channel.EMAIL);
        o.setDestination(email);
        o.setExpiresAt(Instant.now().plus(ttl));
        repo.save(o);

        mail.send(userId, email, purpose.name(),
                subjectFor(purpose),
                bodyFor(purpose, code));
    }

    @Transactional
    public void verify(String userId, OtpCode.Purpose purpose, String code) {
        OtpCode o = repo.findActive(userId, purpose)
                .orElseThrow(() -> new ApiException(ErrorCode.OTP_INVALID, "No active OTP"));
        if (o.isExpired()) throw new ApiException(ErrorCode.OTP_EXPIRED, "OTP expired");
        if (o.getAttempts() >= maxAttempts) throw new ApiException(ErrorCode.OTP_MAX_ATTEMPTS, "Too many attempts");

        String hash = HashUtil.hmacSha256(hmacSecret, code);
        if (!hash.equals(o.getCodeHash())) {
            o.setAttempts(o.getAttempts() + 1);
            repo.save(o);
            throw new ApiException(ErrorCode.OTP_INVALID, "Invalid OTP");
        }
        o.setConsumedAt(Instant.now());
        repo.save(o);
    }

    private static String subjectFor(OtpCode.Purpose p) {
        return switch (p) {
            case SIGNUP_EMAIL  -> "Verify your Engage Flow account";
            case LOGIN_2FA     -> "Engage Flow login verification";
            case PASSWORD_RESET-> "Reset your Engage Flow password";
            case PHONE_VERIFY  -> "Verify your phone number";
            case EMAIL_CHANGE  -> "Confirm your new email";
        };
    }

    private static String bodyFor(OtpCode.Purpose p, String code) {
        String header = switch (p) {
            case SIGNUP_EMAIL   -> "Welcome to Engage Flow!";
            case LOGIN_2FA      -> "We noticed a login from a new device.";
            case PASSWORD_RESET -> "You requested a password reset.";
            case PHONE_VERIFY   -> "Phone verification code:";
            case EMAIL_CHANGE   -> "Confirm your new email:";
        };
        return """
               %s

               Your code is: %s

               This code expires in 10 minutes. Do not share it with anyone.
               If you did not request this, please ignore this email.
               """.formatted(header, code);
    }
}
