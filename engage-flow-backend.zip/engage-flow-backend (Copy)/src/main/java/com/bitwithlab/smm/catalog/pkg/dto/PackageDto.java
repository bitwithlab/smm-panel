package com.bitwithlab.smm.catalog.pkg.dto;

import com.bitwithlab.smm.catalog.pkg.Package;

import java.math.BigDecimal;

public record PackageDto(
        Short id,
        String code,
        String name,
        String description,
        Short maxPlatforms,
        Short maxAccountsPerPlatform,
        BigDecimal priceMonthly,
        BigDecimal priceYearly,
        String currency,
        boolean active,
        Short sortOrder
) {
    public static PackageDto of(Package p) {
        return new PackageDto(p.getId(), p.getCode().name(), p.getName(), p.getDescription(),
                p.getMaxPlatforms(), p.getMaxAccountsPerPlatform(),
                p.getPriceMonthly(), p.getPriceYearly(), p.getCurrency(),
                p.isActive(), p.getSortOrder());
    }
}
