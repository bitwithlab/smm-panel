package com.bitwithlab.smm.wallet;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;

@RestController
@RequestMapping("/api/v1/me/wallet")
@Tag(name = "Wallet")
public class WalletController {

    private final WalletService service;
    private final WalletTransactionRepository txns;

    public WalletController(WalletService service, WalletTransactionRepository txns) {
        this.service = service; this.txns = txns;
    }

    public record WalletDto(BigDecimal balance, String currency) {}
    public record TxnDto(String id, String direction, BigDecimal amount, BigDecimal balanceAfter,
                         String reason, String refType, String refId, String note, Instant createdAt) {
        public static TxnDto of(WalletTransaction t) {
            return new TxnDto(t.getId(), t.getDirection().name(), t.getAmount(), t.getBalanceAfter(),
                    t.getReason().name(), t.getRefType(), t.getRefId(), t.getNote(), t.getCreatedAt());
        }
    }

    @GetMapping
    @Operation(summary = "My wallet balance")
    public ApiResponse<WalletDto> me(@CurrentUser UserPrincipal me) {
        var w = service.get(me.id());
        return ApiResponse.ok(new WalletDto(w.getBalance(), w.getCurrency()));
    }

    @GetMapping("/transactions")
    @Operation(summary = "My wallet transaction history")
    public ApiResponse<PageResponse<TxnDto>> txns(@CurrentUser UserPrincipal me,
                                                  @RequestParam(defaultValue = "0") int page,
                                                  @RequestParam(defaultValue = "20") int size) {
        var p = txns.findByUserIdOrderByCreatedAtDesc(me.id(), PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, TxnDto::of));
    }
}
