package com.bitwithlab.smm.identity.session;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "login_sessions")
public class LoginSession {

    @Id @Column(length = 36) private String id;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(name = "device_id", nullable = false, length = 36) private String deviceId;
    @Column(name = "refresh_token_hash", nullable = false, length = 255, unique = true) private String refreshTokenHash;
    @Column(length = 45) private String ip;
    @Column(name = "user_agent", length = 500) private String userAgent;
    @Column(name = "issued_at", nullable = false) private Instant issuedAt;
    @Column(name = "expires_at", nullable = false) private Instant expiresAt;
    @Column(name = "revoked_at") private Instant revokedAt;
    @Column(name = "replaced_by", length = 36) private String replacedBy;

    @PrePersist void onCreate() { if (issuedAt == null) issuedAt = Instant.now(); }

    public boolean isActive() { return revokedAt == null && expiresAt.isAfter(Instant.now()); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public String getDeviceId() { return deviceId; } public void setDeviceId(String s) { this.deviceId = s; }
    public String getRefreshTokenHash() { return refreshTokenHash; } public void setRefreshTokenHash(String s) { this.refreshTokenHash = s; }
    public String getIp() { return ip; } public void setIp(String ip) { this.ip = ip; }
    public String getUserAgent() { return userAgent; } public void setUserAgent(String s) { this.userAgent = s; }
    public Instant getIssuedAt() { return issuedAt; } public void setIssuedAt(Instant t) { this.issuedAt = t; }
    public Instant getExpiresAt() { return expiresAt; } public void setExpiresAt(Instant t) { this.expiresAt = t; }
    public Instant getRevokedAt() { return revokedAt; } public void setRevokedAt(Instant t) { this.revokedAt = t; }
    public String getReplacedBy() { return replacedBy; } public void setReplacedBy(String s) { this.replacedBy = s; }
}
