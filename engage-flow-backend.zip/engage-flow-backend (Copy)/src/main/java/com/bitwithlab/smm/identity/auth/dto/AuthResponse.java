package com.bitwithlab.smm.identity.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Auth response — either tokens (when fully authenticated) or otp_required signal")
public record AuthResponse(
        @Schema(description = "TOKENS or OTP_REQUIRED") String result,
        TokenPair tokens,
        UserDto user,
        @Schema(description = "When result=OTP_REQUIRED, the email that received the OTP (masked)")
        String otpDestination
) {
    public static AuthResponse withTokens(TokenPair pair, UserDto user) {
        return new AuthResponse("TOKENS", pair, user, null);
    }
    public static AuthResponse otpRequired(String maskedEmail) {
        return new AuthResponse("OTP_REQUIRED", null, null, maskedEmail);
    }

    public record TokenPair(String accessToken, String refreshToken, long accessTtlSeconds, long refreshTtlSeconds, String tokenType) {
        public static TokenPair of(String access, String refresh, long aTtl, long rTtl) {
            return new TokenPair(access, refresh, aTtl, rTtl, "Bearer");
        }
    }
}
