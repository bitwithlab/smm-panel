package com.bitwithlab.smm.order;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ServiceOrderRepository extends JpaRepository<ServiceOrder, String> {

    Page<ServiceOrder> findByUserIdOrderByPlacedAtDesc(String userId, Pageable pageable);

    @Query("""
        select o from ServiceOrder o
        where (:userId  is null or o.userId  = :userId)
          and (:status  is null or o.status  = :status)
          and (:serviceId is null or o.serviceId = :serviceId)
        """)
    Page<ServiceOrder> search(@Param("userId") String userId,
                              @Param("status") ServiceOrder.Status status,
                              @Param("serviceId") Integer serviceId,
                              Pageable pageable);

    @Query(value = "select count(*) from service_orders where YEAR(placed_at) = :year", nativeQuery = true)
    long countByYear(@Param("year") int year);
}
