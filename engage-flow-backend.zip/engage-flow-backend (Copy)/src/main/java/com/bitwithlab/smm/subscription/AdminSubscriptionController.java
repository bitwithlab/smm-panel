package com.bitwithlab.smm.subscription;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.subscription.dto.SubscriptionDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/admin/subscriptions")
@Tag(name = "Admin: Subscriptions")
public class AdminSubscriptionController {

    private final SubscriptionRepository subs;
    private final SubscriptionService service;

    public AdminSubscriptionController(SubscriptionRepository subs, SubscriptionService service) {
        this.subs = subs; this.service = service;
    }

    public record StatusUpdate(Subscription.Status status, Instant endsAt, Boolean autoRenew) {}

    @GetMapping
    @Operation(summary = "Search subscriptions")
    public ApiResponse<PageResponse<SubscriptionDto>> list(
            @RequestParam(required = false) String userId,
            @RequestParam(required = false) Subscription.Status status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var p = subs.search(userId, status,
                PageRequest.of(page, Math.min(size, 100), Sort.by("createdAt").descending()));
        return ApiResponse.ok(PageResponse.of(p, s -> SubscriptionDto.of(s, service.listPlatformIds(s.getId()))));
    }

    @GetMapping("/{id}")
    public ApiResponse<SubscriptionDto> get(@PathVariable String id) {
        var s = subs.findById(id).orElseThrow(() -> ApiException.notFound("Subscription", id));
        return ApiResponse.ok(SubscriptionDto.of(s, service.listPlatformIds(id)));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Force-update subscription status / end date / auto-renew")
    public ApiResponse<SubscriptionDto> update(@PathVariable String id, @RequestBody StatusUpdate req) {
        var s = subs.findById(id).orElseThrow(() -> ApiException.notFound("Subscription", id));
        if (req.status() != null) s.setStatus(req.status());
        if (req.endsAt() != null) s.setEndsAt(req.endsAt());
        if (req.autoRenew() != null) s.setAutoRenew(req.autoRenew());
        subs.save(s);
        return ApiResponse.ok("Updated", SubscriptionDto.of(s, service.listPlatformIds(id)));
    }
}
