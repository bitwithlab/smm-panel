package com.bitwithlab.smm.support.notification;

import com.bitwithlab.smm.common.util.IdGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {

    private final NotificationRepository repo;

    public NotificationService(NotificationRepository repo) { this.repo = repo; }

    @Transactional
    public Notification push(String userId, Notification.Type type, String title, String body) {
        Notification n = new Notification();
        n.setId(IdGenerator.uuid());
        n.setUserId(userId);
        n.setType(type);
        n.setTitle(title);
        n.setBody(body);
        return repo.save(n);
    }
}
