package com.bitwithlab.smm.identity.user;

import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.exception.ErrorCode;
import com.bitwithlab.smm.identity.device.TrustedDevice;
import com.bitwithlab.smm.identity.device.TrustedDeviceRepository;
import com.bitwithlab.smm.identity.session.LoginSession;
import com.bitwithlab.smm.identity.session.LoginSessionRepository;
import com.bitwithlab.smm.identity.user.dto.ChangePasswordRequest;
import com.bitwithlab.smm.identity.user.dto.UpdateProfileRequest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class UserService {

    private final UserRepository users;
    private final TrustedDeviceRepository devices;
    private final LoginSessionRepository sessions;
    private final PasswordEncoder encoder;

    public UserService(UserRepository users, TrustedDeviceRepository devices,
                       LoginSessionRepository sessions, PasswordEncoder encoder) {
        this.users = users; this.devices = devices; this.sessions = sessions; this.encoder = encoder;
    }

    @Transactional(readOnly = true)
    public User get(String id) {
        return users.findById(id).orElseThrow(() -> ApiException.notFound("User", id));
    }

    @Transactional
    public User updateProfile(String id, UpdateProfileRequest req) {
        User u = get(id);
        if (req.name() != null && !req.name().isBlank()) u.setName(req.name().trim());
        if (req.profileImageUrl() != null) u.setProfileImageUrl(req.profileImageUrl());
        if (req.timezone() != null && !req.timezone().isBlank()) u.setTimezone(req.timezone());
        return users.save(u);
    }

    @Transactional
    public void changePassword(String id, ChangePasswordRequest req) {
        User u = get(id);
        if (!encoder.matches(req.currentPassword(), u.getPasswordHash())) {
            throw new ApiException(ErrorCode.INVALID_CREDENTIALS, "Current password is incorrect");
        }
        u.setPasswordHash(encoder.encode(req.newPassword()));
        users.save(u);
        sessions.revokeAllForUser(id, Instant.now());
    }

    @Transactional(readOnly = true)
    public List<TrustedDevice> listDevices(String userId) {
        return devices.findByUserIdAndRevokedAtIsNullOrderByLastSeenAtDesc(userId);
    }

    @Transactional
    public void revokeDevice(String userId, String deviceId) {
        TrustedDevice d = devices.findById(deviceId).orElseThrow(() -> ApiException.notFound("Device", deviceId));
        if (!d.getUserId().equals(userId)) throw ApiException.forbidden("Not your device");
        d.setRevokedAt(Instant.now());
        devices.save(d);
        // Revoke all sessions on that device — handled via direct query for simplicity
        sessions.findByUserIdAndRevokedAtIsNullOrderByIssuedAtDesc(userId).stream()
                .filter(s -> s.getDeviceId().equals(deviceId))
                .forEach(s -> { s.setRevokedAt(Instant.now()); sessions.save(s); });
    }

    @Transactional(readOnly = true)
    public List<LoginSession> listSessions(String userId) {
        return sessions.findByUserIdAndRevokedAtIsNullOrderByIssuedAtDesc(userId);
    }

    @Transactional
    public void revokeSession(String userId, String sessionId) {
        LoginSession s = sessions.findById(sessionId).orElseThrow(() -> ApiException.notFound("Session", sessionId));
        if (!s.getUserId().equals(userId)) throw ApiException.forbidden("Not your session");
        s.setRevokedAt(Instant.now());
        sessions.save(s);
    }

    @Transactional
    public int revokeOtherSessions(String userId, String currentSessionId) {
        int count = 0;
        for (LoginSession s : sessions.findByUserIdAndRevokedAtIsNullOrderByIssuedAtDesc(userId)) {
            if (!s.getId().equals(currentSessionId)) {
                s.setRevokedAt(Instant.now());
                sessions.save(s);
                count++;
            }
        }
        return count;
    }
}
