package com.bitwithlab.smm.admin;

import com.bitwithlab.smm.billing.invoice.InvoiceRepository;
import com.bitwithlab.smm.billing.payment.Payment;
import com.bitwithlab.smm.billing.payment.PaymentRepository;
import com.bitwithlab.smm.billing.refund.Refund;
import com.bitwithlab.smm.billing.refund.RefundRepository;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.identity.user.User;
import com.bitwithlab.smm.identity.user.UserRepository;
import com.bitwithlab.smm.order.ServiceOrder;
import com.bitwithlab.smm.order.ServiceOrderRepository;
import com.bitwithlab.smm.subscription.Subscription;
import com.bitwithlab.smm.subscription.SubscriptionRepository;
import com.bitwithlab.smm.support.ticket.Ticket;
import com.bitwithlab.smm.support.ticket.TicketRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/admin/dashboard")
@Tag(name = "Admin: Dashboard")
public class AdminDashboardController {

    private final UserRepository users;
    private final SubscriptionRepository subs;
    private final ServiceOrderRepository orders;
    private final PaymentRepository payments;
    private final InvoiceRepository invoices;
    private final RefundRepository refunds;
    private final TicketRepository tickets;

    public AdminDashboardController(UserRepository users, SubscriptionRepository subs,
                                    ServiceOrderRepository orders, PaymentRepository payments,
                                    InvoiceRepository invoices, RefundRepository refunds,
                                    TicketRepository tickets) {
        this.users = users; this.subs = subs; this.orders = orders;
        this.payments = payments; this.invoices = invoices;
        this.refunds = refunds; this.tickets = tickets;
    }

    @GetMapping("/stats")
    @Operation(summary = "High-level counters for admin overview")
    public ApiResponse<Map<String, Object>> stats() {
        Map<String, Object> data = new java.util.LinkedHashMap<>();
        data.put("users", Map.of(
                "total", users.count(),
                "active", users.search(null, User.Status.ACTIVE, null, PageRequest.of(0, 1)).getTotalElements(),
                "pending", users.search(null, User.Status.PENDING, null, PageRequest.of(0, 1)).getTotalElements()));
        data.put("subscriptions", Map.of(
                "total", subs.count(),
                "active", subs.search(null, Subscription.Status.ACTIVE, PageRequest.of(0, 1)).getTotalElements()));
        data.put("orders", Map.of(
                "total", orders.count(),
                "pending", orders.search(null, ServiceOrder.Status.PENDING, null, PageRequest.of(0, 1)).getTotalElements(),
                "in_progress", orders.search(null, ServiceOrder.Status.IN_PROGRESS, null, PageRequest.of(0, 1)).getTotalElements()));
        data.put("payments", Map.of(
                "total", payments.count(),
                "success", payments.search(null, Payment.Status.SUCCESS, null, PageRequest.of(0, 1)).getTotalElements(),
                "failed", payments.search(null, Payment.Status.FAILED, null, PageRequest.of(0, 1)).getTotalElements()));
        data.put("invoices", Map.of(
                "total", invoices.count()));
        data.put("refunds", Map.of(
                "pending", refunds.findByStatusOrderByCreatedAtDesc(Refund.Status.REQUESTED, PageRequest.of(0, 1)).getTotalElements()));
        data.put("tickets", Map.of(
                "open", tickets.search(null, Ticket.Status.OPEN, null, PageRequest.of(0, 1)).getTotalElements(),
                "in_progress", tickets.search(null, Ticket.Status.IN_PROGRESS, null, PageRequest.of(0, 1)).getTotalElements()));
        return ApiResponse.ok(data);
    }
}
