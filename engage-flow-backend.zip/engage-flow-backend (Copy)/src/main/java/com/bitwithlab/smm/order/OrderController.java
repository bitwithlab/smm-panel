package com.bitwithlab.smm.order;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.order.dto.OrderDto;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/me/orders")
@Tag(name = "Instant Orders")
public class OrderController {

    private final ServiceOrderService service;
    private final ServiceOrderRepository repo;

    public OrderController(ServiceOrderService service, ServiceOrderRepository repo) {
        this.service = service; this.repo = repo;
    }

    public record PlaceOrderRequest(@NotNull Integer serviceId,
                                    @NotBlank String targetLink,
                                    @NotNull @Min(1) Integer quantity,
                                    String subscriptionId,
                                    String socialAccountId) {}

    @PostMapping
    @Operation(summary = "Place an instant order — debits wallet, sends to provider")
    public ApiResponse<OrderDto> place(@CurrentUser UserPrincipal me, @Valid @RequestBody PlaceOrderRequest req) {
        var o = service.place(me.id(), req.serviceId(), req.targetLink(), req.quantity(),
                req.subscriptionId(), req.socialAccountId());
        return ApiResponse.ok("Order placed", OrderDto.of(o));
    }

    @GetMapping
    @Operation(summary = "List my orders")
    public ApiResponse<PageResponse<OrderDto>> list(@CurrentUser UserPrincipal me,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "20") int size) {
        var p = repo.findByUserIdOrderByPlacedAtDesc(me.id(), PageRequest.of(page, Math.min(size, 100)));
        return ApiResponse.ok(PageResponse.of(p, OrderDto::of));
    }

    @GetMapping("/{id}")
    public ApiResponse<OrderDto> get(@CurrentUser UserPrincipal me, @PathVariable String id) {
        var o = repo.findById(id).orElseThrow(() -> ApiException.notFound("Order", id));
        if (!o.getUserId().equals(me.id())) throw ApiException.forbidden("Not your order");
        return ApiResponse.ok(OrderDto.of(o));
    }

    @PostMapping("/{id}/cancel")
    @Operation(summary = "Cancel an order (refunds wallet if not yet delivered)")
    public ApiResponse<OrderDto> cancel(@CurrentUser UserPrincipal me, @PathVariable String id) {
        return ApiResponse.ok("Cancelled", OrderDto.of(service.cancel(me.id(), id)));
    }
}
