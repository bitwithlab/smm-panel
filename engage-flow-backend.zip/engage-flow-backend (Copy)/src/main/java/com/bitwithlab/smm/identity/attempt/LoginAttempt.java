package com.bitwithlab.smm.identity.attempt;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "login_attempts")
public class LoginAttempt {

    public enum Status { SUCCESS, BAD_PASSWORD, USER_NOT_FOUND, LOCKED, OTP_REQUIRED, OTP_FAILED }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "email_or_phone", nullable = false, length = 190) private String emailOrPhone;
    @Column(name = "user_id", length = 36) private String userId;
    @Column(length = 45) private String ip;
    @Column(name = "user_agent", length = 500) private String userAgent;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 32) private Status status;
    @Column(name = "created_at", nullable = false) private Instant createdAt;

    @PrePersist void onCreate() { if (createdAt == null) createdAt = Instant.now(); }

    public Long getId() { return id; }
    public String getEmailOrPhone() { return emailOrPhone; } public void setEmailOrPhone(String s) { this.emailOrPhone = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public String getIp() { return ip; } public void setIp(String ip) { this.ip = ip; }
    public String getUserAgent() { return userAgent; } public void setUserAgent(String s) { this.userAgent = s; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public Instant getCreatedAt() { return createdAt; }
}
