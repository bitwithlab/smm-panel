package com.bitwithlab.smm.identity.otp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface OtpCodeRepository extends JpaRepository<OtpCode, String> {

    @Query("""
        select o from OtpCode o
        where o.userId = :userId and o.purpose = :purpose and o.consumedAt is null
        order by o.createdAt desc
        """)
    Optional<OtpCode> findActive(@Param("userId") String userId, @Param("purpose") OtpCode.Purpose purpose);

    @Modifying
    @Query("update OtpCode o set o.consumedAt = CURRENT_TIMESTAMP where o.userId = :userId and o.purpose = :purpose and o.consumedAt is null")
    void invalidateAll(@Param("userId") String userId, @Param("purpose") OtpCode.Purpose purpose);
}
