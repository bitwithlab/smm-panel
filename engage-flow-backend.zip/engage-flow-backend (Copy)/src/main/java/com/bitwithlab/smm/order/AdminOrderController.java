package com.bitwithlab.smm.order;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.order.dto.OrderDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/orders")
@Tag(name = "Admin: Orders")
public class AdminOrderController {

    private final ServiceOrderRepository repo;
    private final ServiceOrderService service;

    public AdminOrderController(ServiceOrderRepository repo, ServiceOrderService service) {
        this.repo = repo; this.service = service;
    }

    public record StatusUpdate(ServiceOrder.Status status, Integer remains) {}

    @GetMapping
    @Operation(summary = "Search orders (filter user/status/service)")
    public ApiResponse<PageResponse<OrderDto>> list(@RequestParam(required = false) String userId,
                                                    @RequestParam(required = false) ServiceOrder.Status status,
                                                    @RequestParam(required = false) Integer serviceId,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "20") int size) {
        var p = repo.search(userId, status, serviceId,
                PageRequest.of(page, Math.min(size, 100), Sort.by("placedAt").descending()));
        return ApiResponse.ok(PageResponse.of(p, OrderDto::of));
    }

    @PostMapping("/{id}/sync")
    @Operation(summary = "Pull latest status from upstream provider")
    public ApiResponse<OrderDto> sync(@PathVariable String id) {
        return ApiResponse.ok("Synced", OrderDto.of(service.syncStatus(id)));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Force-update order status / remains")
    public ApiResponse<OrderDto> forceUpdate(@PathVariable String id, @RequestBody StatusUpdate req) {
        return ApiResponse.ok("Updated", OrderDto.of(service.forceUpdate(id, req.status(), req.remains())));
    }
}
