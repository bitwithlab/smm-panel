package com.bitwithlab.smm.support.ticket;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.dto.PageResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import com.bitwithlab.smm.support.notification.Notification;
import com.bitwithlab.smm.support.notification.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/tickets")
@Tag(name = "Admin: Tickets")
public class AdminTicketController {

    private final TicketRepository tickets;
    private final TicketMessageRepository messages;
    private final NotificationService notifier;

    public AdminTicketController(TicketRepository tickets, TicketMessageRepository messages, NotificationService notifier) {
        this.tickets = tickets; this.messages = messages; this.notifier = notifier;
    }

    public record AdminReply(@NotBlank String message, Boolean internalNote, Ticket.Status newStatus) {}
    public record AdminUpdate(Ticket.Status status, Ticket.Priority priority, String assignedTo) {}

    @GetMapping
    public ApiResponse<PageResponse<TicketController.TicketDto>> list(
            @RequestParam(required = false) String userId,
            @RequestParam(required = false) Ticket.Status status,
            @RequestParam(required = false) String assignedTo,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var p = tickets.search(userId, status, assignedTo,
                PageRequest.of(page, Math.min(size, 100), Sort.by("createdAt").descending()));
        return ApiResponse.ok(PageResponse.of(p, TicketController.TicketDto::of));
    }

    @GetMapping("/{id}/messages")
    @Operation(summary = "Full thread incl. internal notes")
    public ApiResponse<List<TicketController.MessageDto>> thread(@PathVariable String id) {
        return ApiResponse.ok(messages.findByTicketIdOrderByCreatedAtAsc(id).stream()
                .map(TicketController.MessageDto::of).toList());
    }

    @PostMapping("/{id}/reply")
    @Transactional
    public ApiResponse<TicketController.MessageDto> reply(@CurrentUser UserPrincipal me, @PathVariable String id,
                                                          @Valid @RequestBody AdminReply req) {
        Ticket t = tickets.findById(id).orElseThrow(() -> ApiException.notFound("Ticket", id));
        TicketMessage m = new TicketMessage();
        m.setId(IdGenerator.uuid());
        m.setTicketId(id);
        m.setSenderId(me.id());
        m.setMessage(req.message());
        m.setInternalNote(Boolean.TRUE.equals(req.internalNote()));
        messages.save(m);
        if (req.newStatus() != null) t.setStatus(req.newStatus());
        else if (!m.isInternalNote()) t.setStatus(Ticket.Status.WAITING_USER);
        if (t.getAssignedTo() == null) t.setAssignedTo(me.id());
        tickets.save(t);

        if (!m.isInternalNote()) {
            notifier.push(t.getUserId(), Notification.Type.TICKET_REPLY,
                    "Reply on ticket " + t.getTicketNumber(),
                    "Support has replied. Open the ticket to view the message.");
        }
        return ApiResponse.ok("Reply added", TicketController.MessageDto.of(m));
    }

    @PatchMapping("/{id}")
    public ApiResponse<TicketController.TicketDto> update(@PathVariable String id, @RequestBody AdminUpdate req) {
        Ticket t = tickets.findById(id).orElseThrow(() -> ApiException.notFound("Ticket", id));
        if (req.status() != null) {
            t.setStatus(req.status());
            if (req.status() == Ticket.Status.CLOSED) t.setClosedAt(Instant.now());
        }
        if (req.priority() != null) t.setPriority(req.priority());
        if (req.assignedTo() != null) t.setAssignedTo(req.assignedTo());
        tickets.save(t);
        return ApiResponse.ok("Updated", TicketController.TicketDto.of(t));
    }
}
