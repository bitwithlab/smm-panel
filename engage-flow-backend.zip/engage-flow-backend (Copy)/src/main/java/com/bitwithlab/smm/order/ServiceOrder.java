package com.bitwithlab.smm.order;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "service_orders")
public class ServiceOrder {

    public enum Status { PENDING, IN_PROGRESS, COMPLETED, PARTIAL, CANCELLED, FAILED, REFUNDED }

    @Id @Column(length = 36) private String id;
    @Column(name = "order_number", nullable = false, length = 20, unique = true) private String orderNumber;
    @Column(name = "user_id", nullable = false, length = 36) private String userId;
    @Column(name = "subscription_id", length = 36) private String subscriptionId;
    @Column(name = "social_account_id", length = 36) private String socialAccountId;
    @Column(name = "service_id", nullable = false) private Integer serviceId;
    @Column(name = "target_link", nullable = false, length = 500) private String targetLink;
    @Column(nullable = false) private Integer quantity;
    @Column(name = "rate_per_1000", nullable = false, precision = 10, scale = 4) private BigDecimal ratePer1000;
    @Column(name = "charge_amount", nullable = false, precision = 12, scale = 2) private BigDecimal chargeAmount;
    @Column(nullable = false, length = 3) private String currency = "BDT";
    @Column(name = "start_count") private Integer startCount;
    @Column private Integer remains;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 16) private Status status = Status.PENDING;
    @Column(name = "provider_id") private Integer providerId;
    @Column(name = "provider_order_id", length = 64) private String providerOrderId;
    @Column(name = "wallet_txn_id", length = 36) private String walletTxnId;
    @Column(name = "placed_at", nullable = false) private Instant placedAt;
    @Column(name = "completed_at") private Instant completedAt;

    @PrePersist void onCreate() { if (placedAt == null) placedAt = Instant.now(); }

    public String getId() { return id; } public void setId(String id) { this.id = id; }
    public String getOrderNumber() { return orderNumber; } public void setOrderNumber(String s) { this.orderNumber = s; }
    public String getUserId() { return userId; } public void setUserId(String s) { this.userId = s; }
    public String getSubscriptionId() { return subscriptionId; } public void setSubscriptionId(String s) { this.subscriptionId = s; }
    public String getSocialAccountId() { return socialAccountId; } public void setSocialAccountId(String s) { this.socialAccountId = s; }
    public Integer getServiceId() { return serviceId; } public void setServiceId(Integer i) { this.serviceId = i; }
    public String getTargetLink() { return targetLink; } public void setTargetLink(String s) { this.targetLink = s; }
    public Integer getQuantity() { return quantity; } public void setQuantity(Integer q) { this.quantity = q; }
    public BigDecimal getRatePer1000() { return ratePer1000; } public void setRatePer1000(BigDecimal b) { this.ratePer1000 = b; }
    public BigDecimal getChargeAmount() { return chargeAmount; } public void setChargeAmount(BigDecimal b) { this.chargeAmount = b; }
    public String getCurrency() { return currency; } public void setCurrency(String c) { this.currency = c; }
    public Integer getStartCount() { return startCount; } public void setStartCount(Integer i) { this.startCount = i; }
    public Integer getRemains() { return remains; } public void setRemains(Integer i) { this.remains = i; }
    public Status getStatus() { return status; } public void setStatus(Status s) { this.status = s; }
    public Integer getProviderId() { return providerId; } public void setProviderId(Integer i) { this.providerId = i; }
    public String getProviderOrderId() { return providerOrderId; } public void setProviderOrderId(String s) { this.providerOrderId = s; }
    public String getWalletTxnId() { return walletTxnId; } public void setWalletTxnId(String s) { this.walletTxnId = s; }
    public Instant getPlacedAt() { return placedAt; }
    public Instant getCompletedAt() { return completedAt; } public void setCompletedAt(Instant t) { this.completedAt = t; }
}
