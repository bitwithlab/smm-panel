package com.bitwithlab.smm.billing.payment;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, String> {
    Optional<Payment> findByIdempotencyKey(String key);
    Optional<Payment> findByGatewayTxnId(String txnId);
    List<Payment> findByInvoiceIdOrderByCreatedAtDesc(String invoiceId);

    @Query("""
        select p from Payment p
        where (:userId is null or p.userId = :userId)
          and (:status is null or p.status = :status)
          and (:method is null or p.method = :method)
        """)
    Page<Payment> search(@Param("userId") String userId,
                         @Param("status") Payment.Status status,
                         @Param("method") Payment.Method method,
                         Pageable pageable);
}
