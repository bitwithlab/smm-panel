package com.bitwithlab.smm.identity.auth;

import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.util.ClientInfo;
import com.bitwithlab.smm.identity.auth.dto.*;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Auth", description = "Sign-up, login, OTP, refresh, password reset")
@SecurityRequirements // public — overrides global bearer requirement
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) { this.service = service; }

    @PostMapping("/register")
    @Operation(summary = "Register new user — sends signup OTP to email")
    public ApiResponse<Void> register(@Valid @RequestBody RegisterRequest req) {
        service.register(req);
        return ApiResponse.ok("Registration successful. Please verify your email.");
    }

    @PostMapping("/verify-signup")
    @Operation(summary = "Verify signup OTP — activates the account")
    public ApiResponse<Void> verifySignup(@Valid @RequestBody VerifyOtpRequest req) {
        service.verifySignup(req);
        return ApiResponse.ok("Account verified");
    }

    @PostMapping("/login")
    @Operation(summary = "Login with email/phone + password. Returns tokens OR otp_required if device is new.")
    public ApiResponse<AuthResponse> login(@Valid @RequestBody LoginRequest req, HttpServletRequest http) {
        return ApiResponse.ok(service.login(req, ClientInfo.from(http)));
    }

    @PostMapping("/verify-login-otp")
    @Operation(summary = "Verify login 2FA OTP and trust this device")
    public ApiResponse<AuthResponse> verifyLoginOtp(@Valid @RequestBody VerifyOtpRequest req,
                                                    @RequestHeader(value = "X-Device-Name", required = false) String deviceName,
                                                    HttpServletRequest http) {
        return ApiResponse.ok(service.verifyLoginOtp(req, deviceName, ClientInfo.from(http)));
    }

    @PostMapping("/refresh")
    @Operation(summary = "Rotate refresh token => new access + refresh pair")
    public ApiResponse<AuthResponse> refresh(@Valid @RequestBody RefreshRequest req, HttpServletRequest http) {
        return ApiResponse.ok(service.refresh(req.refreshToken(), ClientInfo.from(http)));
    }

    @PostMapping("/logout")
    @Operation(summary = "Revoke current session", security = @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth"))
    public ApiResponse<Void> logout(@CurrentUser UserPrincipal me) {
        service.logout(me.id(), me.sessionId());
        return ApiResponse.ok("Logged out");
    }

    @PostMapping("/password-reset/request")
    @Operation(summary = "Request password reset OTP")
    public ApiResponse<Void> requestReset(@Valid @RequestBody PasswordResetRequest req) {
        service.requestPasswordReset(req.email());
        return ApiResponse.ok("If that email exists, an OTP has been sent.");
    }

    @PostMapping("/password-reset/confirm")
    @Operation(summary = "Confirm password reset OTP and set new password")
    public ApiResponse<Void> confirmReset(@Valid @RequestBody PasswordResetRequest.Confirm req) {
        service.confirmPasswordReset(req);
        return ApiResponse.ok("Password updated. Please log in.");
    }
}
