package com.bitwithlab.smm.identity.user;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, String> {

    Optional<User> findByEmail(String email);
    Optional<User> findByPhone(String phone);
    boolean existsByEmail(String email);
    boolean existsByPhone(String phone);

    @Query("""
        select u from User u
        where (:q is null or :q = ''
               or lower(u.name)  like lower(concat('%', :q, '%'))
               or lower(u.email) like lower(concat('%', :q, '%'))
               or u.phone like concat('%', :q, '%'))
          and (:status is null or u.status = :status)
          and (:role   is null or u.role   = :role)
          and u.deletedAt is null
        """)
    Page<User> search(@Param("q") String q,
                      @Param("status") User.Status status,
                      @Param("role") User.Role role,
                      Pageable pageable);

    @Modifying
    @Query("update User u set u.lastLoginAt = :ts, u.failedLoginCount = 0 where u.id = :id")
    void markLoginSuccess(@Param("id") String id, @Param("ts") Instant ts);

    @Modifying
    @Query("update User u set u.failedLoginCount = u.failedLoginCount + 1, u.lockedUntil = :lockUntil where u.id = :id")
    void incrementFailed(@Param("id") String id, @Param("lockUntil") Instant lockUntil);
}
