package com.bitwithlab.smm.billing.payment;

import com.bitwithlab.smm.billing.invoice.Invoice;
import com.bitwithlab.smm.billing.invoice.InvoiceRepository;
import com.bitwithlab.smm.common.dto.ApiResponse;
import com.bitwithlab.smm.common.exception.ApiException;
import com.bitwithlab.smm.common.util.ClientInfo;
import com.bitwithlab.smm.common.util.IdGenerator;
import com.bitwithlab.smm.security.CurrentUser;
import com.bitwithlab.smm.security.UserPrincipal;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;

@RestController
@Tag(name = "Payments")
public class PaymentController {

    private final PaymentService service;
    private final PaymentRepository payments;
    private final InvoiceRepository invoices;

    public PaymentController(PaymentService service, PaymentRepository payments, InvoiceRepository invoices) {
        this.service = service; this.payments = payments; this.invoices = invoices;
    }

    public record InitiateRequest(@NotBlank String invoiceId, @NotNull Payment.Method method) {}
    public record InitiateResponse(String paymentId, String redirectUrl, String status) {}
    public record TopupRequest(@NotNull @Positive BigDecimal amount, @NotNull Payment.Method method) {}
    public record PaymentDto(String id, String invoiceId, String method, BigDecimal amount,
                             String currency, String status, Instant paidAt, Instant createdAt) {
        public static PaymentDto of(Payment p) {
            return new PaymentDto(p.getId(), p.getInvoiceId(), p.getMethod().name(), p.getAmount(),
                    p.getCurrency(), p.getStatus().name(), p.getPaidAt(), p.getCreatedAt());
        }
    }
    public record WebhookPayload(String paymentId, String gatewayTxnId, String gatewayPaymentId,
                                 String status, String rawResponse) {}

    @PostMapping("/api/v1/me/payments/initiate")
    @Operation(summary = "Initiate gateway payment for an invoice")
    public ApiResponse<InitiateResponse> initiate(@CurrentUser UserPrincipal me,
                                                  @Valid @RequestBody InitiateRequest req,
                                                  @RequestHeader(value = "Idempotency-Key", required = false) String idemKey,
                                                  HttpServletRequest http) {
        var info = ClientInfo.from(http);
        var r = service.initiate(me.id(), req.invoiceId(), req.method(), idemKey, info.ip(), info.userAgent());
        return ApiResponse.ok(new InitiateResponse(r.payment().getId(), r.redirectUrl(), r.payment().getStatus().name()));
    }

    @PostMapping("/api/v1/me/payments/topup")
    @Operation(summary = "Top up wallet — creates invoice + initiates payment")
    public ApiResponse<InitiateResponse> topup(@CurrentUser UserPrincipal me, @Valid @RequestBody TopupRequest req,
                                               @RequestHeader(value = "Idempotency-Key", required = false) String idemKey,
                                               HttpServletRequest http) {
        Invoice inv = new Invoice();
        inv.setId(IdGenerator.uuid());
        inv.setInvoiceNumber(IdGenerator.invoiceNumber(invoices.countByYear(java.time.LocalDate.now().getYear()) + 1));
        inv.setUserId(me.id());
        inv.setPurpose(Invoice.Purpose.WALLET_TOPUP);
        inv.setSubtotal(req.amount());
        inv.setTotal(req.amount());
        invoices.save(inv);

        var info = ClientInfo.from(http);
        var r = service.initiate(me.id(), inv.getId(), req.method(), idemKey, info.ip(), info.userAgent());
        return ApiResponse.ok(new InitiateResponse(r.payment().getId(), r.redirectUrl(), r.payment().getStatus().name()));
    }

    @GetMapping("/api/v1/me/payments")
    @Operation(summary = "My payments")
    public ApiResponse<java.util.List<PaymentDto>> list(@CurrentUser UserPrincipal me) {
        return ApiResponse.ok(payments.search(me.id(), null, null,
                org.springframework.data.domain.PageRequest.of(0, 100,
                        org.springframework.data.domain.Sort.by("createdAt").descending()))
                .stream().map(PaymentDto::of).toList());
    }

    // ----- Public webhook (gateway → backend) -----
    @PostMapping("/api/v1/payments/webhook/{provider}")
    @Operation(summary = "Gateway webhook callback (public, signature verified per provider)")
    @SecurityRequirements
    public ApiResponse<Void> webhook(@PathVariable String provider, @RequestBody WebhookPayload payload) {
        // TODO: verify signature header per provider
        if (payload == null || payload.paymentId() == null)
            throw ApiException.badRequest("Missing paymentId");
        if ("SUCCESS".equalsIgnoreCase(payload.status())) {
            service.markSuccess(payload.paymentId(), payload.gatewayTxnId(), payload.gatewayPaymentId(), payload.rawResponse());
        } else {
            service.markFailed(payload.paymentId(), payload.rawResponse());
        }
        return ApiResponse.ok("Acknowledged");
    }

    // ----- Admin -----
    @PostMapping("/api/v1/admin/payments/{id}/mark-success")
    @Operation(summary = "Manual mark-success (e.g. bank transfer reconciliation)")
    public ApiResponse<PaymentDto> manualSuccess(@PathVariable String id, @RequestParam(required = false) String gatewayTxnId) {
        return ApiResponse.ok("Marked success", PaymentDto.of(service.markSuccess(id, gatewayTxnId, null, "manual")));
    }

    @GetMapping("/api/v1/admin/payments")
    @Operation(summary = "Search payments")
    public ApiResponse<com.bitwithlab.smm.common.dto.PageResponse<PaymentDto>> adminList(
            @RequestParam(required = false) String userId,
            @RequestParam(required = false) Payment.Status status,
            @RequestParam(required = false) Payment.Method method,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var p = payments.search(userId, status, method,
                org.springframework.data.domain.PageRequest.of(page, Math.min(size, 100),
                        org.springframework.data.domain.Sort.by("createdAt").descending()));
        return ApiResponse.ok(com.bitwithlab.smm.common.dto.PageResponse.of(p, PaymentDto::of));
    }
}
