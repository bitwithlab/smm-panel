package com.bitwithlab.smm.catalog.service;

import com.bitwithlab.smm.catalog.service.dto.ServiceDto;
import com.bitwithlab.smm.common.dto.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/public/services")
@Tag(name = "Catalog: Services", description = "Public service catalog (instant order pricing)")
@SecurityRequirements
public class ServiceController {

    private final SmmServiceRepository repo;

    public ServiceController(SmmServiceRepository repo) { this.repo = repo; }

    @GetMapping
    @Operation(summary = "List active services for a platform")
    public ApiResponse<List<ServiceDto>> byPlatform(@RequestParam Short platformId) {
        return ApiResponse.ok(repo.findByPlatformIdAndActiveTrueOrderByCategoryAscRatePer1000Asc(platformId)
                .stream().map(ServiceDto::of).toList());
    }
}
