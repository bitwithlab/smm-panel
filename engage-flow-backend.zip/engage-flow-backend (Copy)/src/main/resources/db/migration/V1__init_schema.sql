-- =============================================================
-- Engage Flow — Initial Schema (MySQL 8+)
-- UUIDs as CHAR(36) for readability; pgcrypto -> AES_ENCRYPT/DECRYPT in app layer
-- =============================================================

-- ----- Identity & Security ------------------------------------

CREATE TABLE users (
    id                   CHAR(36)        NOT NULL PRIMARY KEY,
    name                 VARCHAR(120)    NOT NULL,
    email                VARCHAR(190)    NOT NULL,
    phone                VARCHAR(20)     NOT NULL,
    password_hash        VARCHAR(255)    NOT NULL,
    role                 ENUM('USER','ADMIN','SUPPORT') NOT NULL DEFAULT 'USER',
    status               ENUM('PENDING','ACTIVE','SUSPENDED','BANNED') NOT NULL DEFAULT 'PENDING',
    email_verified_at    DATETIME(6)     NULL,
    phone_verified_at    DATETIME(6)     NULL,
    last_login_at        DATETIME(6)     NULL,
    failed_login_count   INT             NOT NULL DEFAULT 0,
    locked_until         DATETIME(6)     NULL,
    profile_image_url    VARCHAR(500)    NULL,
    timezone             VARCHAR(64)     NOT NULL DEFAULT 'Asia/Dhaka',
    terms_accepted_at    DATETIME(6)     NULL,
    created_at           DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at           DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at           DATETIME(6)     NULL,
    UNIQUE KEY uk_users_email (email),
    UNIQUE KEY uk_users_phone (phone),
    KEY ix_users_status (status),
    KEY ix_users_role (role),
    KEY ix_users_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE otp_codes (
    id           CHAR(36)     NOT NULL PRIMARY KEY,
    user_id      CHAR(36)     NOT NULL,
    code_hash    VARCHAR(255) NOT NULL,
    purpose      ENUM('SIGNUP_EMAIL','LOGIN_2FA','PASSWORD_RESET','PHONE_VERIFY','EMAIL_CHANGE') NOT NULL,
    channel      ENUM('EMAIL','SMS') NOT NULL,
    destination  VARCHAR(190) NOT NULL,
    attempts     INT          NOT NULL DEFAULT 0,
    expires_at   DATETIME(6)  NOT NULL,
    consumed_at  DATETIME(6)  NULL,
    created_at   DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_otp_user_purpose (user_id, purpose, consumed_at),
    KEY ix_otp_expires (expires_at),
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE trusted_devices (
    id                   CHAR(36)     NOT NULL PRIMARY KEY,
    user_id              CHAR(36)     NOT NULL,
    device_fingerprint   VARCHAR(128) NOT NULL,
    device_name          VARCHAR(120) NULL,
    os                   VARCHAR(64)  NULL,
    browser              VARCHAR(64)  NULL,
    last_ip              VARCHAR(45)  NULL,
    last_country         VARCHAR(64)  NULL,
    last_city            VARCHAR(120) NULL,
    trusted_at           DATETIME(6)  NULL,
    last_seen_at         DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    revoked_at           DATETIME(6)  NULL,
    UNIQUE KEY uk_device_user_fp (user_id, device_fingerprint),
    CONSTRAINT fk_device_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE login_sessions (
    id                   CHAR(36)     NOT NULL PRIMARY KEY,
    user_id              CHAR(36)     NOT NULL,
    device_id            CHAR(36)     NOT NULL,
    refresh_token_hash   VARCHAR(255) NOT NULL,
    ip                   VARCHAR(45)  NULL,
    user_agent           VARCHAR(500) NULL,
    issued_at            DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    expires_at           DATETIME(6)  NOT NULL,
    revoked_at           DATETIME(6)  NULL,
    replaced_by          CHAR(36)     NULL,
    UNIQUE KEY uk_session_token_hash (refresh_token_hash),
    KEY ix_session_user_revoked (user_id, revoked_at),
    KEY ix_session_expires (expires_at),
    CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_session_device FOREIGN KEY (device_id) REFERENCES trusted_devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE login_attempts (
    id              BIGINT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email_or_phone  VARCHAR(190)    NOT NULL,
    user_id         CHAR(36)        NULL,
    ip              VARCHAR(45)     NULL,
    user_agent      VARCHAR(500)    NULL,
    status          ENUM('SUCCESS','BAD_PASSWORD','USER_NOT_FOUND','LOCKED','OTP_REQUIRED','OTP_FAILED') NOT NULL,
    created_at      DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_attempt_email_time (email_or_phone, created_at),
    KEY ix_attempt_ip_time (ip, created_at),
    CONSTRAINT fk_attempt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----- Catalog ------------------------------------------------

CREATE TABLE packages (
    id                          SMALLINT        NOT NULL PRIMARY KEY,
    code                        ENUM('BASIC','STANDARD','ULTRA') NOT NULL,
    name                        VARCHAR(64)     NOT NULL,
    description                 TEXT            NULL,
    max_platforms               SMALLINT        NOT NULL,
    max_accounts_per_platform   SMALLINT        NOT NULL,
    price_monthly               DECIMAL(12,2)   NOT NULL,
    price_yearly                DECIMAL(12,2)   NOT NULL,
    currency                    CHAR(3)         NOT NULL DEFAULT 'BDT',
    is_active                   TINYINT(1)      NOT NULL DEFAULT 1,
    sort_order                  SMALLINT        NOT NULL DEFAULT 0,
    created_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_packages_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE platforms (
    id          SMALLINT       NOT NULL PRIMARY KEY,
    code        VARCHAR(32)    NOT NULL,
    name        VARCHAR(64)    NOT NULL,
    icon_url    VARCHAR(500)   NULL,
    is_active   TINYINT(1)     NOT NULL DEFAULT 1,
    UNIQUE KEY uk_platforms_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE providers (
    id                   INT            NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(120)   NOT NULL,
    api_url              VARCHAR(255)   NOT NULL,
    api_key_encrypted    TEXT           NOT NULL,
    balance              DECIMAL(14,4)  NOT NULL DEFAULT 0,
    is_active            TINYINT(1)     NOT NULL DEFAULT 1,
    created_at           DATETIME(6)    NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE services (
    id                          INT             NOT NULL AUTO_INCREMENT PRIMARY KEY,
    platform_id                 SMALLINT        NOT NULL,
    name                        VARCHAR(120)    NOT NULL,
    category                    ENUM('FOLLOWERS','LIKES','VIEWS','COMMENTS','SUBSCRIBERS','SHARES','OTHER') NOT NULL,
    min_quantity                INT             NOT NULL DEFAULT 50,
    max_quantity                INT             NOT NULL DEFAULT 100000,
    rate_per_1000               DECIMAL(10,4)   NOT NULL,
    provider_id                 INT             NULL,
    provider_service_id         VARCHAR(64)     NULL,
    provider_cost_per_1000      DECIMAL(10,4)   NULL,
    is_active                   TINYINT(1)      NOT NULL DEFAULT 1,
    created_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    KEY ix_services_platform_active (platform_id, is_active),
    CONSTRAINT fk_service_platform FOREIGN KEY (platform_id) REFERENCES platforms(id),
    CONSTRAINT fk_service_provider FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----- Subscription & Accounts --------------------------------

CREATE TABLE coupons (
    id                       CHAR(36)         NOT NULL PRIMARY KEY,
    code                     VARCHAR(32)      NOT NULL,
    discount_type            ENUM('PERCENT','FIXED') NOT NULL,
    discount_value           DECIMAL(10,2)    NOT NULL,
    max_uses                 INT              NULL,
    used_count               INT              NOT NULL DEFAULT 0,
    valid_from               DATETIME(6)      NOT NULL,
    valid_until              DATETIME(6)      NOT NULL,
    applicable_packages      JSON             NULL,
    is_active                TINYINT(1)       NOT NULL DEFAULT 1,
    created_at               DATETIME(6)      NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_coupons_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE subscriptions (
    id                            CHAR(36)        NOT NULL PRIMARY KEY,
    user_id                       CHAR(36)        NOT NULL,
    package_id                    SMALLINT        NOT NULL,
    billing_cycle                 ENUM('MONTHLY','YEARLY') NOT NULL,
    price                         DECIMAL(12,2)   NOT NULL,
    currency                      CHAR(3)         NOT NULL DEFAULT 'BDT',
    max_platforms_snapshot        SMALLINT        NOT NULL,
    max_accounts_snapshot         SMALLINT        NOT NULL,
    status                        ENUM('PENDING_PAYMENT','ACTIVE','EXPIRED','CANCELLED','SUSPENDED') NOT NULL DEFAULT 'PENDING_PAYMENT',
    starts_at                     DATETIME(6)     NULL,
    ends_at                       DATETIME(6)     NULL,
    cancelled_at                  DATETIME(6)     NULL,
    auto_renew                    TINYINT(1)      NOT NULL DEFAULT 0,
    coupon_id                     CHAR(36)        NULL,
    created_at                    DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at                    DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    KEY ix_sub_user_status (user_id, status),
    KEY ix_sub_ends_at (ends_at),
    CONSTRAINT fk_sub_user    FOREIGN KEY (user_id)    REFERENCES users(id),
    CONSTRAINT fk_sub_package FOREIGN KEY (package_id) REFERENCES packages(id),
    CONSTRAINT fk_sub_coupon  FOREIGN KEY (coupon_id)  REFERENCES coupons(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE subscription_platforms (
    id                CHAR(36)     NOT NULL PRIMARY KEY,
    subscription_id   CHAR(36)     NOT NULL,
    platform_id       SMALLINT     NOT NULL,
    created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_sub_platform (subscription_id, platform_id),
    CONSTRAINT fk_subplat_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
    CONSTRAINT fk_subplat_platform FOREIGN KEY (platform_id) REFERENCES platforms(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE social_accounts (
    id                CHAR(36)     NOT NULL PRIMARY KEY,
    subscription_id   CHAR(36)     NOT NULL,
    platform_id       SMALLINT     NOT NULL,
    username          VARCHAR(190) NOT NULL,
    profile_url       VARCHAR(500) NULL,
    is_verified       TINYINT(1)   NOT NULL DEFAULT 0,
    status            ENUM('ACTIVE','REMOVED') NOT NULL DEFAULT 'ACTIVE',
    created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    removed_at        DATETIME(6)  NULL,
    KEY ix_social_sub_platform (subscription_id, platform_id),
    CONSTRAINT fk_social_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
    CONSTRAINT fk_social_platform FOREIGN KEY (platform_id) REFERENCES platforms(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----- Wallet & Billing ---------------------------------------

CREATE TABLE wallets (
    id          CHAR(36)        NOT NULL PRIMARY KEY,
    user_id     CHAR(36)        NOT NULL,
    balance     DECIMAL(14,2)   NOT NULL DEFAULT 0,
    currency    CHAR(3)         NOT NULL DEFAULT 'BDT',
    updated_at  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_wallet_user (user_id),
    CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE wallet_transactions (
    id              CHAR(36)        NOT NULL PRIMARY KEY,
    wallet_id       CHAR(36)        NOT NULL,
    user_id         CHAR(36)        NOT NULL,
    direction       ENUM('CREDIT','DEBIT') NOT NULL,
    amount          DECIMAL(12,2)   NOT NULL,
    balance_after   DECIMAL(14,2)   NOT NULL,
    reason          ENUM('TOPUP','ORDER','SUBSCRIPTION','REFUND','ADJUSTMENT','BONUS') NOT NULL,
    ref_type        VARCHAR(32)     NULL,
    ref_id          CHAR(36)        NULL,
    note            TEXT            NULL,
    created_at      DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_wtx_user_time (user_id, created_at),
    KEY ix_wtx_wallet_time (wallet_id, created_at),
    KEY ix_wtx_ref (ref_type, ref_id),
    CONSTRAINT fk_wtx_wallet FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
    CONSTRAINT fk_wtx_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE invoices (
    id               CHAR(36)        NOT NULL PRIMARY KEY,
    invoice_number   VARCHAR(32)     NOT NULL,
    user_id          CHAR(36)        NOT NULL,
    purpose          ENUM('SUBSCRIPTION','WALLET_TOPUP') NOT NULL,
    subscription_id  CHAR(36)        NULL,
    subtotal         DECIMAL(12,2)   NOT NULL,
    discount         DECIMAL(12,2)   NOT NULL DEFAULT 0,
    tax              DECIMAL(12,2)   NOT NULL DEFAULT 0,
    total            DECIMAL(12,2)   NOT NULL,
    currency         CHAR(3)         NOT NULL DEFAULT 'BDT',
    status           ENUM('UNPAID','PAID','PARTIAL','REFUNDED','VOID') NOT NULL DEFAULT 'UNPAID',
    due_at           DATETIME(6)     NULL,
    paid_at          DATETIME(6)     NULL,
    created_at       DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_invoice_number (invoice_number),
    KEY ix_invoice_user_status (user_id, status),
    CONSTRAINT fk_invoice_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_invoice_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE payments (
    id                  CHAR(36)        NOT NULL PRIMARY KEY,
    invoice_id          CHAR(36)        NOT NULL,
    user_id             CHAR(36)        NOT NULL,
    method              ENUM('BKASH','NAGAD','ROCKET','CARD','BANK_TRANSFER','MANUAL') NOT NULL,
    amount              DECIMAL(12,2)   NOT NULL,
    currency            CHAR(3)         NOT NULL DEFAULT 'BDT',
    status              ENUM('INITIATED','PENDING','SUCCESS','FAILED','REFUNDED') NOT NULL DEFAULT 'INITIATED',
    gateway_txn_id      VARCHAR(120)    NULL,
    gateway_payment_id  VARCHAR(120)    NULL,
    gateway_response    JSON            NULL,
    idempotency_key     VARCHAR(80)     NULL,
    ip                  VARCHAR(45)     NULL,
    user_agent          VARCHAR(500)    NULL,
    paid_at             DATETIME(6)     NULL,
    created_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    UNIQUE KEY uk_payment_idem (idempotency_key),
    KEY ix_payment_gtxn (gateway_txn_id),
    KEY ix_payment_user_time (user_id, created_at),
    KEY ix_payment_invoice_status (invoice_id, status),
    CONSTRAINT fk_payment_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id),
    CONSTRAINT fk_payment_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE refunds (
    id            CHAR(36)        NOT NULL PRIMARY KEY,
    payment_id    CHAR(36)        NULL,
    order_id      CHAR(36)        NULL,
    user_id       CHAR(36)        NOT NULL,
    amount        DECIMAL(12,2)   NOT NULL,
    destination   ENUM('WALLET','GATEWAY') NOT NULL DEFAULT 'WALLET',
    reason        TEXT            NULL,
    status        ENUM('REQUESTED','APPROVED','REJECTED','COMPLETED') NOT NULL DEFAULT 'REQUESTED',
    processed_by  CHAR(36)        NULL,
    created_at    DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    processed_at  DATETIME(6)     NULL,
    KEY ix_refund_user_time (user_id, created_at),
    KEY ix_refund_status (status),
    CONSTRAINT fk_refund_payment FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE SET NULL,
    CONSTRAINT fk_refund_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_refund_admin FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----- Instant Orders -----------------------------------------

CREATE TABLE service_orders (
    id                  CHAR(36)        NOT NULL PRIMARY KEY,
    order_number        VARCHAR(20)     NOT NULL,
    user_id             CHAR(36)        NOT NULL,
    subscription_id     CHAR(36)        NULL,
    social_account_id   CHAR(36)        NULL,
    service_id          INT             NOT NULL,
    target_link         VARCHAR(500)    NOT NULL,
    quantity            INT             NOT NULL,
    rate_per_1000       DECIMAL(10,4)   NOT NULL,
    charge_amount       DECIMAL(12,2)   NOT NULL,
    currency            CHAR(3)         NOT NULL DEFAULT 'BDT',
    start_count         INT             NULL,
    remains             INT             NULL,
    status              ENUM('PENDING','IN_PROGRESS','COMPLETED','PARTIAL','CANCELLED','FAILED','REFUNDED') NOT NULL DEFAULT 'PENDING',
    provider_id         INT             NULL,
    provider_order_id   VARCHAR(64)     NULL,
    wallet_txn_id       CHAR(36)        NULL,
    placed_at           DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    completed_at        DATETIME(6)     NULL,
    UNIQUE KEY uk_order_number (order_number),
    KEY ix_order_user_status (user_id, status),
    KEY ix_order_status_time (status, placed_at),
    KEY ix_order_provider (provider_id, provider_order_id),
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_order_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE SET NULL,
    CONSTRAINT fk_order_social FOREIGN KEY (social_account_id) REFERENCES social_accounts(id) ON DELETE SET NULL,
    CONSTRAINT fk_order_service FOREIGN KEY (service_id) REFERENCES services(id),
    CONSTRAINT fk_order_provider FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE refunds
    ADD CONSTRAINT fk_refund_order FOREIGN KEY (order_id) REFERENCES service_orders(id) ON DELETE SET NULL;

-- ----- Support ------------------------------------------------

CREATE TABLE tickets (
    id                  CHAR(36)        NOT NULL PRIMARY KEY,
    ticket_number       VARCHAR(20)     NOT NULL,
    user_id             CHAR(36)        NOT NULL,
    subject             VARCHAR(255)    NOT NULL,
    category            ENUM('PAYMENT','SERVICE','ACCOUNT','REFUND','BUG','REPORT','OTHER') NOT NULL,
    priority            ENUM('LOW','NORMAL','HIGH','URGENT') NOT NULL DEFAULT 'NORMAL',
    status              ENUM('OPEN','IN_PROGRESS','WAITING_USER','RESOLVED','CLOSED') NOT NULL DEFAULT 'OPEN',
    assigned_to         CHAR(36)        NULL,
    related_order_id    CHAR(36)        NULL,
    created_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    closed_at           DATETIME(6)     NULL,
    UNIQUE KEY uk_ticket_number (ticket_number),
    KEY ix_ticket_user_status (user_id, status),
    KEY ix_ticket_assigned (assigned_to, status),
    KEY ix_ticket_status_priority (status, priority),
    CONSTRAINT fk_ticket_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_ticket_admin FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_ticket_order FOREIGN KEY (related_order_id) REFERENCES service_orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE ticket_messages (
    id                  CHAR(36)        NOT NULL PRIMARY KEY,
    ticket_id           CHAR(36)        NOT NULL,
    sender_id           CHAR(36)        NOT NULL,
    message             TEXT            NOT NULL,
    attachments         JSON            NULL,
    is_internal_note    TINYINT(1)      NOT NULL DEFAULT 0,
    created_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_tmsg_ticket_time (ticket_id, created_at),
    CONSTRAINT fk_tmsg_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_tmsg_sender FOREIGN KEY (sender_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE notifications (
    id          CHAR(36)        NOT NULL PRIMARY KEY,
    user_id     CHAR(36)        NOT NULL,
    type        ENUM('ORDER_UPDATE','PAYMENT','SECURITY','SUBSCRIPTION_EXPIRY','TICKET_REPLY','SYSTEM') NOT NULL,
    title       VARCHAR(255)    NOT NULL,
    body        TEXT            NULL,
    data        JSON            NULL,
    read_at     DATETIME(6)     NULL,
    created_at  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_notif_user_read_time (user_id, read_at, created_at),
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE message_log (
    id                BIGINT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id           CHAR(36)        NULL,
    channel           ENUM('EMAIL','SMS','PUSH') NOT NULL,
    to_address        VARCHAR(190)    NOT NULL,
    template          VARCHAR(64)     NULL,
    subject           VARCHAR(255)    NULL,
    provider          VARCHAR(64)     NULL,
    provider_msg_id   VARCHAR(120)    NULL,
    status            ENUM('QUEUED','SENT','DELIVERED','BOUNCED','FAILED') NOT NULL DEFAULT 'QUEUED',
    error             TEXT            NULL,
    created_at        DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_mlog_user_time (user_id, created_at),
    KEY ix_mlog_status_time (status, created_at),
    CONSTRAINT fk_mlog_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----- System / Audit -----------------------------------------

CREATE TABLE audit_logs (
    id              BIGINT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    actor_user_id   CHAR(36)        NULL,
    action          VARCHAR(64)     NOT NULL,
    entity_type     VARCHAR(64)     NULL,
    entity_id       VARCHAR(64)     NULL,
    ip              VARCHAR(45)     NULL,
    user_agent      VARCHAR(500)    NULL,
    metadata        JSON            NULL,
    created_at      DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    KEY ix_audit_actor_time (actor_user_id, created_at),
    KEY ix_audit_entity (entity_type, entity_id),
    KEY ix_audit_action_time (action, created_at),
    CONSTRAINT fk_audit_user FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
