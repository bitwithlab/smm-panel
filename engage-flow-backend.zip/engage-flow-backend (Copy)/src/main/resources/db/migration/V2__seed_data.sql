-- Seed catalog rows
INSERT INTO packages (id, code, name, description, max_platforms, max_accounts_per_platform, price_monthly, price_yearly, currency, sort_order)
VALUES
  (1, 'BASIC',    'Basic',    'Single-platform plan: 3 accounts on 1 platform.',          1, 3, 299.00,  2990.00,  'BDT', 1),
  (2, 'STANDARD', 'Standard', 'Multi-platform plan: 3 accounts on each of 3 platforms.',  3, 3, 799.00,  7990.00,  'BDT', 2),
  (3, 'ULTRA',    'Ultra',    'Power plan: 5 accounts on each of 3 platforms.',           3, 5, 1499.00, 14990.00, 'BDT', 3);

INSERT INTO platforms (id, code, name) VALUES
  (1, 'FACEBOOK',  'Facebook'),
  (2, 'INSTAGRAM', 'Instagram'),
  (3, 'X',         'X (Twitter)'),
  (4, 'TIKTOK',    'TikTok'),
  (5, 'YOUTUBE',   'YouTube');
